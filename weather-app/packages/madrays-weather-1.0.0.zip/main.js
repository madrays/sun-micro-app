var ue = Object.defineProperty;
var fe = (o, t, e) => t in o ? ue(o, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : o[t] = e;
var st = (o, t, e) => fe(o, typeof t != "symbol" ? t + "" : t, e);
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const J = globalThis, $t = J.ShadowRoot && (J.ShadyCSS === void 0 || J.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Xt = Symbol(), At = /* @__PURE__ */ new WeakMap();
let ye = class {
  constructor(t, e, i) {
    if (this._$cssResult$ = !0, i !== Xt) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if ($t && t === void 0) {
      const i = e !== void 0 && e.length === 1;
      i && (t = At.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), i && At.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const me = (o) => new ye(typeof o == "string" ? o : o + "", void 0, Xt), $e = (o, t) => {
  if ($t) o.adoptedStyleSheets = t.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet);
  else for (const e of t) {
    const i = document.createElement("style"), s = J.litNonce;
    s !== void 0 && i.setAttribute("nonce", s), i.textContent = e.cssText, o.appendChild(i);
  }
}, _t = $t ? (o) => o : (o) => o instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const i of t.cssRules) e += i.cssText;
  return me(e);
})(o) : o;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: xe, defineProperty: ve, getOwnPropertyDescriptor: we, getOwnPropertyNames: be, getOwnPropertySymbols: Ae, getPrototypeOf: _e } = Object, w = globalThis, Ct = w.trustedTypes, Ce = Ct ? Ct.emptyScript : "", ot = w.reactiveElementPolyfillSupport, T = (o, t) => o, ut = { toAttribute(o, t) {
  switch (t) {
    case Boolean:
      o = o ? Ce : null;
      break;
    case Object:
    case Array:
      o = o == null ? o : JSON.stringify(o);
  }
  return o;
}, fromAttribute(o, t) {
  let e = o;
  switch (t) {
    case Boolean:
      e = o !== null;
      break;
    case Number:
      e = o === null ? null : Number(o);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(o);
      } catch {
        e = null;
      }
  }
  return e;
} }, Jt = (o, t) => !xe(o, t), St = { attribute: !0, type: String, converter: ut, reflect: !1, useDefault: !1, hasChanged: Jt };
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), w.litPropertyMetadata ?? (w.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let H = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ?? (this.l = [])).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = St) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const i = Symbol(), s = this.getPropertyDescriptor(t, i, e);
      s !== void 0 && ve(this.prototype, t, s);
    }
  }
  static getPropertyDescriptor(t, e, i) {
    const { get: s, set: n } = we(this.prototype, t) ?? { get() {
      return this[e];
    }, set(a) {
      this[e] = a;
    } };
    return { get: s, set(a) {
      const l = s == null ? void 0 : s.call(this);
      n == null || n.call(this, a), this.requestUpdate(t, l, i);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? St;
  }
  static _$Ei() {
    if (this.hasOwnProperty(T("elementProperties"))) return;
    const t = _e(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(T("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(T("properties"))) {
      const e = this.properties, i = [...be(e), ...Ae(e)];
      for (const s of i) this.createProperty(s, e[s]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [i, s] of e) this.elementProperties.set(i, s);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, i] of this.elementProperties) {
      const s = this._$Eu(e, i);
      s !== void 0 && this._$Eh.set(s, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const i = new Set(t.flat(1 / 0).reverse());
      for (const s of i) e.unshift(_t(s));
    } else t !== void 0 && e.push(_t(t));
    return e;
  }
  static _$Eu(t, e) {
    const i = e.attribute;
    return i === !1 ? void 0 : typeof i == "string" ? i : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var t;
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (t = this.constructor.l) == null || t.forEach((e) => e(this));
  }
  addController(t) {
    var e;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(t), this.renderRoot !== void 0 && this.isConnected && ((e = t.hostConnected) == null || e.call(t));
  }
  removeController(t) {
    var e;
    (e = this._$EO) == null || e.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const i of e.keys()) this.hasOwnProperty(i) && (t.set(i, this[i]), delete this[i]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return $e(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    var t;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (t = this._$EO) == null || t.forEach((e) => {
      var i;
      return (i = e.hostConnected) == null ? void 0 : i.call(e);
    });
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    var t;
    (t = this._$EO) == null || t.forEach((e) => {
      var i;
      return (i = e.hostDisconnected) == null ? void 0 : i.call(e);
    });
  }
  attributeChangedCallback(t, e, i) {
    this._$AK(t, i);
  }
  _$ET(t, e) {
    var n;
    const i = this.constructor.elementProperties.get(t), s = this.constructor._$Eu(t, i);
    if (s !== void 0 && i.reflect === !0) {
      const a = (((n = i.converter) == null ? void 0 : n.toAttribute) !== void 0 ? i.converter : ut).toAttribute(e, i.type);
      this._$Em = t, a == null ? this.removeAttribute(s) : this.setAttribute(s, a), this._$Em = null;
    }
  }
  _$AK(t, e) {
    var n, a;
    const i = this.constructor, s = i._$Eh.get(t);
    if (s !== void 0 && this._$Em !== s) {
      const l = i.getPropertyOptions(s), r = typeof l.converter == "function" ? { fromAttribute: l.converter } : ((n = l.converter) == null ? void 0 : n.fromAttribute) !== void 0 ? l.converter : ut;
      this._$Em = s;
      const h = r.fromAttribute(e, l.type);
      this[s] = h ?? ((a = this._$Ej) == null ? void 0 : a.get(s)) ?? h, this._$Em = null;
    }
  }
  requestUpdate(t, e, i, s = !1, n) {
    var a;
    if (t !== void 0) {
      const l = this.constructor;
      if (s === !1 && (n = this[t]), i ?? (i = l.getPropertyOptions(t)), !((i.hasChanged ?? Jt)(n, e) || i.useDefault && i.reflect && n === ((a = this._$Ej) == null ? void 0 : a.get(t)) && !this.hasAttribute(l._$Eu(t, i)))) return;
      this.C(t, e, i);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: i, reflect: s, wrapped: n }, a) {
    i && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(t) && (this._$Ej.set(t, a ?? e ?? this[t]), n !== !0 || a !== void 0) || (this._$AL.has(t) || (this.hasUpdated || i || (e = void 0), this._$AL.set(t, e)), s === !0 && this._$Em !== t && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var i;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [n, a] of this._$Ep) this[n] = a;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [n, a] of s) {
        const { wrapped: l } = a, r = this[n];
        l !== !0 || this._$AL.has(n) || r === void 0 || this.C(n, void 0, a, r);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), (i = this._$EO) == null || i.forEach((s) => {
        var n;
        return (n = s.hostUpdate) == null ? void 0 : n.call(s);
      }), this.update(e)) : this._$EM();
    } catch (s) {
      throw t = !1, this._$EM(), s;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    var e;
    (e = this._$EO) == null || e.forEach((i) => {
      var s;
      return (s = i.hostUpdated) == null ? void 0 : s.call(i);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((e) => this._$ET(e, this[e]))), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
H.elementStyles = [], H.shadowRootOptions = { mode: "open" }, H[T("elementProperties")] = /* @__PURE__ */ new Map(), H[T("finalized")] = /* @__PURE__ */ new Map(), ot == null || ot({ ReactiveElement: H }), (w.reactiveElementVersions ?? (w.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const R = globalThis, kt = (o) => o, Q = R.trustedTypes, Et = Q ? Q.createPolicy("lit-html", { createHTML: (o) => o }) : void 0, Yt = "$lit$", x = `lit$${Math.random().toFixed(9).slice(2)}$`, Gt = "?" + x, Se = `<${Gt}>`, M = document, q = () => M.createComment(""), V = (o) => o === null || typeof o != "object" && typeof o != "function", xt = Array.isArray, ke = (o) => xt(o) || typeof (o == null ? void 0 : o[Symbol.iterator]) == "function", at = `[ 	
\f\r]`, O = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Mt = /-->/g, Pt = />/g, A = RegExp(`>|${at}(?:([^\\s"'>=/]+)(${at}*=${at}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Ht = /'/g, Nt = /"/g, Qt = /^(?:script|style|textarea|title)$/i, Ee = (o) => (t, ...e) => ({ _$litType$: o, strings: t, values: e }), d = Ee(1), z = Symbol.for("lit-noChange"), f = Symbol.for("lit-nothing"), zt = /* @__PURE__ */ new WeakMap(), C = M.createTreeWalker(M, 129);
function te(o, t) {
  if (!xt(o) || !o.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Et !== void 0 ? Et.createHTML(t) : t;
}
const Me = (o, t) => {
  const e = o.length - 1, i = [];
  let s, n = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", a = O;
  for (let l = 0; l < e; l++) {
    const r = o[l];
    let h, p, c = -1, u = 0;
    for (; u < r.length && (a.lastIndex = u, p = a.exec(r), p !== null); ) u = a.lastIndex, a === O ? p[1] === "!--" ? a = Mt : p[1] !== void 0 ? a = Pt : p[2] !== void 0 ? (Qt.test(p[2]) && (s = RegExp("</" + p[2], "g")), a = A) : p[3] !== void 0 && (a = A) : a === A ? p[0] === ">" ? (a = s ?? O, c = -1) : p[1] === void 0 ? c = -2 : (c = a.lastIndex - p[2].length, h = p[1], a = p[3] === void 0 ? A : p[3] === '"' ? Nt : Ht) : a === Nt || a === Ht ? a = A : a === Mt || a === Pt ? a = O : (a = A, s = void 0);
    const g = a === A && o[l + 1].startsWith("/>") ? " " : "";
    n += a === O ? r + Se : c >= 0 ? (i.push(h), r.slice(0, c) + Yt + r.slice(c) + x + g) : r + x + (c === -2 ? l : g);
  }
  return [te(o, n + (o[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), i];
};
let ft = class ee {
  constructor({ strings: t, _$litType$: e }, i) {
    let s;
    this.parts = [];
    let n = 0, a = 0;
    const l = t.length - 1, r = this.parts, [h, p] = Me(t, e);
    if (this.el = ee.createElement(h, i), C.currentNode = this.el.content, e === 2 || e === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (s = C.nextNode()) !== null && r.length < l; ) {
      if (s.nodeType === 1) {
        if (s.hasAttributes()) for (const c of s.getAttributeNames()) if (c.endsWith(Yt)) {
          const u = p[a++], g = s.getAttribute(c).split(x), $ = /([.?@])?(.*)/.exec(u);
          r.push({ type: 1, index: n, name: $[2], strings: g, ctor: $[1] === "." ? He : $[1] === "?" ? Ne : $[1] === "@" ? ze : et }), s.removeAttribute(c);
        } else c.startsWith(x) && (r.push({ type: 6, index: n }), s.removeAttribute(c));
        if (Qt.test(s.tagName)) {
          const c = s.textContent.split(x), u = c.length - 1;
          if (u > 0) {
            s.textContent = Q ? Q.emptyScript : "";
            for (let g = 0; g < u; g++) s.append(c[g], q()), C.nextNode(), r.push({ type: 2, index: ++n });
            s.append(c[u], q());
          }
        }
      } else if (s.nodeType === 8) if (s.data === Gt) r.push({ type: 2, index: n });
      else {
        let c = -1;
        for (; (c = s.data.indexOf(x, c + 1)) !== -1; ) r.push({ type: 7, index: n }), c += x.length - 1;
      }
      n++;
    }
  }
  static createElement(t, e) {
    const i = M.createElement("template");
    return i.innerHTML = t, i;
  }
};
function K(o, t, e = o, i) {
  var a, l;
  if (t === z) return t;
  let s = i !== void 0 ? (a = e._$Co) == null ? void 0 : a[i] : e._$Cl;
  const n = V(t) ? void 0 : t._$litDirective$;
  return (s == null ? void 0 : s.constructor) !== n && ((l = s == null ? void 0 : s._$AO) == null || l.call(s, !1), n === void 0 ? s = void 0 : (s = new n(o), s._$AT(o, e, i)), i !== void 0 ? (e._$Co ?? (e._$Co = []))[i] = s : e._$Cl = s), s !== void 0 && (t = K(o, s._$AS(o, t.values), s, i)), t;
}
let Pe = class {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: i } = this._$AD, s = ((t == null ? void 0 : t.creationScope) ?? M).importNode(e, !0);
    C.currentNode = s;
    let n = C.nextNode(), a = 0, l = 0, r = i[0];
    for (; r !== void 0; ) {
      if (a === r.index) {
        let h;
        r.type === 2 ? h = new vt(n, n.nextSibling, this, t) : r.type === 1 ? h = new r.ctor(n, r.name, r.strings, this, t) : r.type === 6 && (h = new Ke(n, this, t)), this._$AV.push(h), r = i[++l];
      }
      a !== (r == null ? void 0 : r.index) && (n = C.nextNode(), a++);
    }
    return C.currentNode = M, s;
  }
  p(t) {
    let e = 0;
    for (const i of this._$AV) i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, e), e += i.strings.length - 2) : i._$AI(t[e])), e++;
  }
}, vt = class ie {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, e, i, s) {
    this.type = 2, this._$AH = f, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = i, this.options = s, this._$Cv = (s == null ? void 0 : s.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = K(this, t, e), V(t) ? t === f || t == null || t === "" ? (this._$AH !== f && this._$AR(), this._$AH = f) : t !== this._$AH && t !== z && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : ke(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== f && V(this._$AH) ? this._$AA.nextSibling.data = t : this.T(M.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var n;
    const { values: e, _$litType$: i } = t, s = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = ft.createElement(te(i.h, i.h[0]), this.options)), i);
    if (((n = this._$AH) == null ? void 0 : n._$AD) === s) this._$AH.p(e);
    else {
      const a = new Pe(s, this), l = a.u(this.options);
      a.p(e), this.T(l), this._$AH = a;
    }
  }
  _$AC(t) {
    let e = zt.get(t.strings);
    return e === void 0 && zt.set(t.strings, e = new ft(t)), e;
  }
  k(t) {
    xt(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, s = 0;
    for (const n of t) s === e.length ? e.push(i = new ie(this.O(q()), this.O(q()), this, this.options)) : i = e[s], i._$AI(n), s++;
    s < e.length && (this._$AR(i && i._$AB.nextSibling, s), e.length = s);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    var i;
    for ((i = this._$AP) == null ? void 0 : i.call(this, !1, !0, e); t !== this._$AB; ) {
      const s = kt(t).nextSibling;
      kt(t).remove(), t = s;
    }
  }
  setConnected(t) {
    var e;
    this._$AM === void 0 && (this._$Cv = t, (e = this._$AP) == null || e.call(this, t));
  }
}, et = class {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, i, s, n) {
    this.type = 1, this._$AH = f, this._$AN = void 0, this.element = t, this.name = e, this._$AM = s, this.options = n, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = f;
  }
  _$AI(t, e = this, i, s) {
    const n = this.strings;
    let a = !1;
    if (n === void 0) t = K(this, t, e, 0), a = !V(t) || t !== this._$AH && t !== z, a && (this._$AH = t);
    else {
      const l = t;
      let r, h;
      for (t = n[0], r = 0; r < n.length - 1; r++) h = K(this, l[i + r], e, r), h === z && (h = this._$AH[r]), a || (a = !V(h) || h !== this._$AH[r]), h === f ? t = f : t !== f && (t += (h ?? "") + n[r + 1]), this._$AH[r] = h;
    }
    a && !s && this.j(t);
  }
  j(t) {
    t === f ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}, He = class extends et {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === f ? void 0 : t;
  }
}, Ne = class extends et {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== f);
  }
}, ze = class extends et {
  constructor(t, e, i, s, n) {
    super(t, e, i, s, n), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = K(this, t, e, 0) ?? f) === z) return;
    const i = this._$AH, s = t === f && i !== f || t.capture !== i.capture || t.once !== i.once || t.passive !== i.passive, n = t !== f && (i === f || s);
    s && this.element.removeEventListener(this.name, this, i), n && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var e;
    typeof this._$AH == "function" ? this._$AH.call(((e = this.options) == null ? void 0 : e.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}, Ke = class {
  constructor(t, e, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    K(this, t);
  }
};
const nt = R.litHtmlPolyfillSupport;
nt == null || nt(ft, vt), (R.litHtmlVersions ?? (R.litHtmlVersions = [])).push("3.3.2");
const Be = (o, t, e) => {
  const i = (e == null ? void 0 : e.renderBefore) ?? t;
  let s = i._$litPart$;
  if (s === void 0) {
    const n = (e == null ? void 0 : e.renderBefore) ?? null;
    i._$litPart$ = s = new vt(t.insertBefore(q(), n), n, void 0, e ?? {});
  }
  return s._$AI(o), s;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const k = globalThis;
let Y = class extends H {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = Be(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return z;
  }
};
var Wt;
Y._$litElement$ = !0, Y.finalized = !0, (Wt = k.litElementHydrateSupport) == null || Wt.call(k, { LitElement: Y });
const rt = k.litElementPolyfillSupport;
rt == null || rt({ LitElement: Y });
(k.litElementVersions ?? (k.litElementVersions = [])).push("4.2.2");
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const G = globalThis, wt = G.ShadowRoot && (G.ShadyCSS === void 0 || G.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, se = Symbol(), Kt = /* @__PURE__ */ new WeakMap();
let Ue = class {
  constructor(o, t, e) {
    if (this._$cssResult$ = !0, e !== se) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = o, this.t = t;
  }
  get styleSheet() {
    let o = this.o;
    const t = this.t;
    if (wt && o === void 0) {
      const e = t !== void 0 && t.length === 1;
      e && (o = Kt.get(t)), o === void 0 && ((this.o = o = new CSSStyleSheet()).replaceSync(this.cssText), e && Kt.set(t, o));
    }
    return o;
  }
  toString() {
    return this.cssText;
  }
};
const Bt = wt ? (o) => o : (o) => o instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const i of t.cssRules) e += i.cssText;
  return ((i) => new Ue(typeof i == "string" ? i : i + "", void 0, se))(e);
})(o) : o, { is: Oe, defineProperty: Ie, getOwnPropertyDescriptor: Te, getOwnPropertyNames: Re, getOwnPropertySymbols: Le, getPrototypeOf: je } = Object, b = globalThis, Ut = b.trustedTypes, De = Ut ? Ut.emptyScript : "", lt = b.reactiveElementPolyfillSupport, L = (o, t) => o, yt = { toAttribute(o, t) {
  switch (t) {
    case Boolean:
      o = o ? De : null;
      break;
    case Object:
    case Array:
      o = o == null ? o : JSON.stringify(o);
  }
  return o;
}, fromAttribute(o, t) {
  let e = o;
  switch (t) {
    case Boolean:
      e = o !== null;
      break;
    case Number:
      e = o === null ? null : Number(o);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(o);
      } catch {
        e = null;
      }
  }
  return e;
} }, oe = (o, t) => !Oe(o, t), Ot = { attribute: !0, type: String, converter: yt, reflect: !1, useDefault: !1, hasChanged: oe };
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), b.litPropertyMetadata ?? (b.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let N = class extends HTMLElement {
  static addInitializer(o) {
    this._$Ei(), (this.l ?? (this.l = [])).push(o);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(o, t = Ot) {
    if (t.state && (t.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(o) && ((t = Object.create(t)).wrapped = !0), this.elementProperties.set(o, t), !t.noAccessor) {
      const e = Symbol(), i = this.getPropertyDescriptor(o, e, t);
      i !== void 0 && Ie(this.prototype, o, i);
    }
  }
  static getPropertyDescriptor(o, t, e) {
    const { get: i, set: s } = Te(this.prototype, o) ?? { get() {
      return this[t];
    }, set(n) {
      this[t] = n;
    } };
    return { get: i, set(n) {
      const a = i == null ? void 0 : i.call(this);
      s == null || s.call(this, n), this.requestUpdate(o, a, e);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(o) {
    return this.elementProperties.get(o) ?? Ot;
  }
  static _$Ei() {
    if (this.hasOwnProperty(L("elementProperties"))) return;
    const o = je(this);
    o.finalize(), o.l !== void 0 && (this.l = [...o.l]), this.elementProperties = new Map(o.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(L("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(L("properties"))) {
      const t = this.properties, e = [...Re(t), ...Le(t)];
      for (const i of e) this.createProperty(i, t[i]);
    }
    const o = this[Symbol.metadata];
    if (o !== null) {
      const t = litPropertyMetadata.get(o);
      if (t !== void 0) for (const [e, i] of t) this.elementProperties.set(e, i);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [t, e] of this.elementProperties) {
      const i = this._$Eu(t, e);
      i !== void 0 && this._$Eh.set(i, t);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(o) {
    const t = [];
    if (Array.isArray(o)) {
      const e = new Set(o.flat(1 / 0).reverse());
      for (const i of e) t.unshift(Bt(i));
    } else o !== void 0 && t.push(Bt(o));
    return t;
  }
  static _$Eu(o, t) {
    const e = t.attribute;
    return e === !1 ? void 0 : typeof e == "string" ? e : typeof o == "string" ? o.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var o;
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (o = this.constructor.l) == null || o.forEach((t) => t(this));
  }
  addController(o) {
    var t;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(o), this.renderRoot !== void 0 && this.isConnected && ((t = o.hostConnected) == null || t.call(o));
  }
  removeController(o) {
    var t;
    (t = this._$EO) == null || t.delete(o);
  }
  _$E_() {
    const o = /* @__PURE__ */ new Map(), t = this.constructor.elementProperties;
    for (const e of t.keys()) this.hasOwnProperty(e) && (o.set(e, this[e]), delete this[e]);
    o.size > 0 && (this._$Ep = o);
  }
  createRenderRoot() {
    const o = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return ((t, e) => {
      if (wt) t.adoptedStyleSheets = e.map((i) => i instanceof CSSStyleSheet ? i : i.styleSheet);
      else for (const i of e) {
        const s = document.createElement("style"), n = G.litNonce;
        n !== void 0 && s.setAttribute("nonce", n), s.textContent = i.cssText, t.appendChild(s);
      }
    })(o, this.constructor.elementStyles), o;
  }
  connectedCallback() {
    var o;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (o = this._$EO) == null || o.forEach((t) => {
      var e;
      return (e = t.hostConnected) == null ? void 0 : e.call(t);
    });
  }
  enableUpdating(o) {
  }
  disconnectedCallback() {
    var o;
    (o = this._$EO) == null || o.forEach((t) => {
      var e;
      return (e = t.hostDisconnected) == null ? void 0 : e.call(t);
    });
  }
  attributeChangedCallback(o, t, e) {
    this._$AK(o, e);
  }
  _$ET(o, t) {
    var s;
    const e = this.constructor.elementProperties.get(o), i = this.constructor._$Eu(o, e);
    if (i !== void 0 && e.reflect === !0) {
      const n = (((s = e.converter) == null ? void 0 : s.toAttribute) !== void 0 ? e.converter : yt).toAttribute(t, e.type);
      this._$Em = o, n == null ? this.removeAttribute(i) : this.setAttribute(i, n), this._$Em = null;
    }
  }
  _$AK(o, t) {
    var s, n;
    const e = this.constructor, i = e._$Eh.get(o);
    if (i !== void 0 && this._$Em !== i) {
      const a = e.getPropertyOptions(i), l = typeof a.converter == "function" ? { fromAttribute: a.converter } : ((s = a.converter) == null ? void 0 : s.fromAttribute) !== void 0 ? a.converter : yt;
      this._$Em = i;
      const r = l.fromAttribute(t, a.type);
      this[i] = r ?? ((n = this._$Ej) == null ? void 0 : n.get(i)) ?? r, this._$Em = null;
    }
  }
  requestUpdate(o, t, e, i = !1, s) {
    var n;
    if (o !== void 0) {
      const a = this.constructor;
      if (i === !1 && (s = this[o]), e ?? (e = a.getPropertyOptions(o)), !((e.hasChanged ?? oe)(s, t) || e.useDefault && e.reflect && s === ((n = this._$Ej) == null ? void 0 : n.get(o)) && !this.hasAttribute(a._$Eu(o, e)))) return;
      this.C(o, t, e);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(o, t, { useDefault: e, reflect: i, wrapped: s }, n) {
    e && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(o) && (this._$Ej.set(o, n ?? t ?? this[o]), s !== !0 || n !== void 0) || (this._$AL.has(o) || (this.hasUpdated || e || (t = void 0), this._$AL.set(o, t)), i === !0 && this._$Em !== o && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(o));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (t) {
      Promise.reject(t);
    }
    const o = this.scheduleUpdate();
    return o != null && await o, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var e;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [s, n] of this._$Ep) this[s] = n;
        this._$Ep = void 0;
      }
      const i = this.constructor.elementProperties;
      if (i.size > 0) for (const [s, n] of i) {
        const { wrapped: a } = n, l = this[s];
        a !== !0 || this._$AL.has(s) || l === void 0 || this.C(s, void 0, n, l);
      }
    }
    let o = !1;
    const t = this._$AL;
    try {
      o = this.shouldUpdate(t), o ? (this.willUpdate(t), (e = this._$EO) == null || e.forEach((i) => {
        var s;
        return (s = i.hostUpdate) == null ? void 0 : s.call(i);
      }), this.update(t)) : this._$EM();
    } catch (i) {
      throw o = !1, this._$EM(), i;
    }
    o && this._$AE(t);
  }
  willUpdate(o) {
  }
  _$AE(o) {
    var t;
    (t = this._$EO) == null || t.forEach((e) => {
      var i;
      return (i = e.hostUpdated) == null ? void 0 : i.call(e);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(o)), this.updated(o);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(o) {
    return !0;
  }
  update(o) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((t) => this._$ET(t, this[t]))), this._$EM();
  }
  updated(o) {
  }
  firstUpdated(o) {
  }
};
N.elementStyles = [], N.shadowRootOptions = { mode: "open" }, N[L("elementProperties")] = /* @__PURE__ */ new Map(), N[L("finalized")] = /* @__PURE__ */ new Map(), lt == null || lt({ ReactiveElement: N }), (b.reactiveElementVersions ?? (b.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const j = globalThis, It = (o) => o, tt = j.trustedTypes, Tt = tt ? tt.createPolicy("lit-html", { createHTML: (o) => o }) : void 0, ae = "$lit$", v = `lit$${Math.random().toFixed(9).slice(2)}$`, ne = "?" + v, qe = `<${ne}>`, P = document, F = () => P.createComment(""), W = (o) => o === null || typeof o != "object" && typeof o != "function", mt = Array.isArray, ct = `[ 	
\f\r]`, I = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Rt = /-->/g, Lt = />/g, _ = RegExp(`>|${ct}(?:([^\\s"'>=/]+)(${ct}*=${ct}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), jt = /'/g, Dt = /"/g, re = /^(?:script|style|textarea|title)$/i, bt = /* @__PURE__ */ ((o) => (t, ...e) => ({ _$litType$: o, strings: t, values: e }))(1), B = Symbol.for("lit-noChange"), y = Symbol.for("lit-nothing"), qt = /* @__PURE__ */ new WeakMap(), S = P.createTreeWalker(P, 129);
function le(o, t) {
  if (!mt(o) || !o.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Tt !== void 0 ? Tt.createHTML(t) : t;
}
const Ve = (o, t) => {
  const e = o.length - 1, i = [];
  let s, n = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", a = I;
  for (let l = 0; l < e; l++) {
    const r = o[l];
    let h, p, c = -1, u = 0;
    for (; u < r.length && (a.lastIndex = u, p = a.exec(r), p !== null); ) u = a.lastIndex, a === I ? p[1] === "!--" ? a = Rt : p[1] !== void 0 ? a = Lt : p[2] !== void 0 ? (re.test(p[2]) && (s = RegExp("</" + p[2], "g")), a = _) : p[3] !== void 0 && (a = _) : a === _ ? p[0] === ">" ? (a = s ?? I, c = -1) : p[1] === void 0 ? c = -2 : (c = a.lastIndex - p[2].length, h = p[1], a = p[3] === void 0 ? _ : p[3] === '"' ? Dt : jt) : a === Dt || a === jt ? a = _ : a === Rt || a === Lt ? a = I : (a = _, s = void 0);
    const g = a === _ && o[l + 1].startsWith("/>") ? " " : "";
    n += a === I ? r + qe : c >= 0 ? (i.push(h), r.slice(0, c) + ae + r.slice(c) + v + g) : r + v + (c === -2 ? l : g);
  }
  return [le(o, n + (o[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), i];
};
class Z {
  constructor({ strings: t, _$litType$: e }, i) {
    let s;
    this.parts = [];
    let n = 0, a = 0;
    const l = t.length - 1, r = this.parts, [h, p] = Ve(t, e);
    if (this.el = Z.createElement(h, i), S.currentNode = this.el.content, e === 2 || e === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (s = S.nextNode()) !== null && r.length < l; ) {
      if (s.nodeType === 1) {
        if (s.hasAttributes()) for (const c of s.getAttributeNames()) if (c.endsWith(ae)) {
          const u = p[a++], g = s.getAttribute(c).split(v), $ = /([.?@])?(.*)/.exec(u);
          r.push({ type: 1, index: n, name: $[2], strings: g, ctor: $[1] === "." ? We : $[1] === "?" ? Ze : $[1] === "@" ? Xe : it }), s.removeAttribute(c);
        } else c.startsWith(v) && (r.push({ type: 6, index: n }), s.removeAttribute(c));
        if (re.test(s.tagName)) {
          const c = s.textContent.split(v), u = c.length - 1;
          if (u > 0) {
            s.textContent = tt ? tt.emptyScript : "";
            for (let g = 0; g < u; g++) s.append(c[g], F()), S.nextNode(), r.push({ type: 2, index: ++n });
            s.append(c[u], F());
          }
        }
      } else if (s.nodeType === 8) if (s.data === ne) r.push({ type: 2, index: n });
      else {
        let c = -1;
        for (; (c = s.data.indexOf(v, c + 1)) !== -1; ) r.push({ type: 7, index: n }), c += v.length - 1;
      }
      n++;
    }
  }
  static createElement(t, e) {
    const i = P.createElement("template");
    return i.innerHTML = t, i;
  }
}
function U(o, t, e = o, i) {
  var a, l;
  if (t === B) return t;
  let s = i !== void 0 ? (a = e._$Co) == null ? void 0 : a[i] : e._$Cl;
  const n = W(t) ? void 0 : t._$litDirective$;
  return (s == null ? void 0 : s.constructor) !== n && ((l = s == null ? void 0 : s._$AO) == null || l.call(s, !1), n === void 0 ? s = void 0 : (s = new n(o), s._$AT(o, e, i)), i !== void 0 ? (e._$Co ?? (e._$Co = []))[i] = s : e._$Cl = s), s !== void 0 && (t = U(o, s._$AS(o, t.values), s, i)), t;
}
class Fe {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: i } = this._$AD, s = ((t == null ? void 0 : t.creationScope) ?? P).importNode(e, !0);
    S.currentNode = s;
    let n = S.nextNode(), a = 0, l = 0, r = i[0];
    for (; r !== void 0; ) {
      if (a === r.index) {
        let h;
        r.type === 2 ? h = new X(n, n.nextSibling, this, t) : r.type === 1 ? h = new r.ctor(n, r.name, r.strings, this, t) : r.type === 6 && (h = new Je(n, this, t)), this._$AV.push(h), r = i[++l];
      }
      a !== (r == null ? void 0 : r.index) && (n = S.nextNode(), a++);
    }
    return S.currentNode = P, s;
  }
  p(t) {
    let e = 0;
    for (const i of this._$AV) i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, e), e += i.strings.length - 2) : i._$AI(t[e])), e++;
  }
}
class X {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, e, i, s) {
    this.type = 2, this._$AH = y, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = i, this.options = s, this._$Cv = (s == null ? void 0 : s.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = U(this, t, e), W(t) ? t === y || t == null || t === "" ? (this._$AH !== y && this._$AR(), this._$AH = y) : t !== this._$AH && t !== B && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : ((i) => mt(i) || typeof (i == null ? void 0 : i[Symbol.iterator]) == "function")(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== y && W(this._$AH) ? this._$AA.nextSibling.data = t : this.T(P.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var n;
    const { values: e, _$litType$: i } = t, s = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = Z.createElement(le(i.h, i.h[0]), this.options)), i);
    if (((n = this._$AH) == null ? void 0 : n._$AD) === s) this._$AH.p(e);
    else {
      const a = new Fe(s, this), l = a.u(this.options);
      a.p(e), this.T(l), this._$AH = a;
    }
  }
  _$AC(t) {
    let e = qt.get(t.strings);
    return e === void 0 && qt.set(t.strings, e = new Z(t)), e;
  }
  k(t) {
    mt(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, s = 0;
    for (const n of t) s === e.length ? e.push(i = new X(this.O(F()), this.O(F()), this, this.options)) : i = e[s], i._$AI(n), s++;
    s < e.length && (this._$AR(i && i._$AB.nextSibling, s), e.length = s);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    var i;
    for ((i = this._$AP) == null ? void 0 : i.call(this, !1, !0, e); t !== this._$AB; ) {
      const s = It(t).nextSibling;
      It(t).remove(), t = s;
    }
  }
  setConnected(t) {
    var e;
    this._$AM === void 0 && (this._$Cv = t, (e = this._$AP) == null || e.call(this, t));
  }
}
class it {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, i, s, n) {
    this.type = 1, this._$AH = y, this._$AN = void 0, this.element = t, this.name = e, this._$AM = s, this.options = n, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = y;
  }
  _$AI(t, e = this, i, s) {
    const n = this.strings;
    let a = !1;
    if (n === void 0) t = U(this, t, e, 0), a = !W(t) || t !== this._$AH && t !== B, a && (this._$AH = t);
    else {
      const l = t;
      let r, h;
      for (t = n[0], r = 0; r < n.length - 1; r++) h = U(this, l[i + r], e, r), h === B && (h = this._$AH[r]), a || (a = !W(h) || h !== this._$AH[r]), h === y ? t = y : t !== y && (t += (h ?? "") + n[r + 1]), this._$AH[r] = h;
    }
    a && !s && this.j(t);
  }
  j(t) {
    t === y ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class We extends it {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === y ? void 0 : t;
  }
}
class Ze extends it {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== y);
  }
}
class Xe extends it {
  constructor(t, e, i, s, n) {
    super(t, e, i, s, n), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = U(this, t, e, 0) ?? y) === B) return;
    const i = this._$AH, s = t === y && i !== y || t.capture !== i.capture || t.once !== i.once || t.passive !== i.passive, n = t !== y && (i === y || s);
    s && this.element.removeEventListener(this.name, this, i), n && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var e;
    typeof this._$AH == "function" ? this._$AH.call(((e = this.options) == null ? void 0 : e.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class Je {
  constructor(t, e, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    U(this, t);
  }
}
const ht = j.litHtmlPolyfillSupport;
ht == null || ht(Z, X), (j.litHtmlVersions ?? (j.litHtmlVersions = [])).push("3.3.2");
const E = globalThis;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class D extends N {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = ((i, s, n) => {
      const a = (n == null ? void 0 : n.renderBefore) ?? s;
      let l = a._$litPart$;
      if (l === void 0) {
        const r = (n == null ? void 0 : n.renderBefore) ?? null;
        a._$litPart$ = l = new X(s.insertBefore(F(), r), r, void 0, n ?? {});
      }
      return l._$AI(i), l;
    })(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return B;
  }
}
var Zt;
D._$litElement$ = !0, D.finalized = !0, (Zt = E.litElementHydrateSupport) == null || Zt.call(E, { LitElement: D });
const dt = E.litElementPolyfillSupport;
dt == null || dt({ LitElement: D }), (E.litElementVersions ?? (E.litElementVersions = [])).push("4.2.2");
class ce extends D {
  constructor() {
    super(), this._initialized = !1, this._eventListeners = /* @__PURE__ */ new Map();
  }
  initializeMicroApp() {
    this._initialized || (this._setupEventListeners(), this._initialized = !0);
  }
  connectedCallback() {
    super.connectedCallback(), this.initializeMicroApp(), this.onConnected();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupEventListeners(), this.onDisconnected();
  }
  attributeChangedCallback(t, e, i) {
    super.attributeChangedCallback(t, e, i), this.onAttributeChanged(t, e, i);
  }
  _setupEventListeners() {
  }
  _cleanupEventListeners() {
    const t = Array.from(this._eventListeners.entries());
    for (const [e, i] of t) i.forEach((s) => {
      window.removeEventListener(e, s);
    });
    this._eventListeners.clear();
  }
  addEventListener(t, e, i) {
    super.addEventListener(t, e, i);
  }
  dispatchCustomEvent(t, e) {
    const i = new CustomEvent(t, { bubbles: !0, composed: !0, detail: e });
    this.dispatchEvent(i);
  }
  onConnected() {
  }
  onDisconnected() {
  }
  onAttributeChanged(t, e, i) {
  }
  render() {
    return bt``;
  }
}
class he extends ce {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, widgetInfo: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([i, s]) => s !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    var e;
    (e = super.firstUpdated) == null || e.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, i = this.spCtx;
      i.widgetInfo !== e.widgetInfo && this.onWidgetInfoChanged(i.widgetInfo, e.widgetInfo), i.darkMode !== e.darkMode && this.onDarkModeChanged(i.darkMode, e.darkMode), i.language !== e.language && this.onLanguageChanged(i.language, e.language), i.networkMode !== e.networkMode && this.onNetworkModeChanged(i.networkMode, e.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized();
  }
  onInitialized() {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
  }
  onNetworkModeChanged(t, e) {
  }
  onWidgetInfoChanged(t, e) {
  }
  render() {
    return bt``;
  }
}
he.properties = { spCtx: { type: Object, attribute: !1 } };
class de extends ce {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, background: "", widgetInfo: {}, customParam: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([i, s]) => s !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    var e;
    (e = super.firstUpdated) == null || e.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, i = this.spCtx;
      i.darkMode !== e.darkMode && this.onDarkModeChanged(i.darkMode, e.darkMode), i.language !== e.language && this.onLanguageChanged(i.language, e.language), i.networkMode !== e.networkMode && this.onNetworkModeChanged(i.networkMode, e.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized({ widgetInfo: this.spCtx.widgetInfo, customParam: this.spCtx.customParam });
  }
  onInitialized(t) {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
  }
  onNetworkModeChanged(t, e) {
  }
  render() {
    return bt``;
  }
}
de.properties = { spCtx: { type: Object, attribute: !1 } };
const Vt = {
  // 晴天 - 太阳
  sunny: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .sun-ray { animation: rotate 20s linear infinite; transform-origin: center; }
        @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      </style>
      <g class="sun-ray">
        <circle cx="32" cy="32" r="12" fill="#FFB800"/>
        <g stroke="#FFB800" stroke-width="2.5" stroke-linecap="round">
          <line x1="32" y1="6" x2="32" y2="14"/>
          <line x1="32" y1="50" x2="32" y2="58"/>
          <line x1="6" y1="32" x2="14" y2="32"/>
          <line x1="50" y1="32" x2="58" y2="32"/>
          <line x1="13.6" y1="13.6" x2="19.3" y2="19.3"/>
          <line x1="44.7" y1="44.7" x2="50.4" y2="50.4"/>
          <line x1="13.6" y1="50.4" x2="19.3" y2="44.7"/>
          <line x1="44.7" y1="19.3" x2="50.4" y2="13.6"/>
        </g>
      </g>
    </svg>
  `,
  // 晴夜 - 月亮
  clearNight: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M38 12C28.6 12 21 19.6 21 29C21 38.4 28.6 46 38 46C41.2 46 44.2 45.1 46.8 43.5C43.4 48.9 37.4 52.5 30.5 52.5C20.3 52.5 12 44.2 12 34C12 23.8 20.3 15.5 30.5 15.5C33.3 15.5 35.9 16.1 38.2 17.2C38.1 15.5 38 13.7 38 12Z" fill="#A0AEC0"/>
    </svg>
  `,
  // 多云
  cloudy: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .cloud-move { animation: float 4s ease-in-out infinite; }
        @keyframes float { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(3px); } }
      </style>
      <g class="cloud-move">
        <path d="M48 38H18C13.6 38 10 34.4 10 30C10 25.6 13.6 22 18 22C18.3 22 18.6 22 18.9 22.1C20.3 16.5 25.4 12.5 31.5 12.5C38.4 12.5 44.1 17.6 44.9 24.2C45.3 24.1 45.6 24 46 24C50.4 24 54 27.6 54 32C54 35.3 51.9 38 48 38Z" fill="#94A3B8"/>
      </g>
    </svg>
  `,
  // 少云/晴间多云
  partlyCloudy: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .sun-spin { animation: spin 20s linear infinite; transform-origin: 20px 18px; }
        .cloud-drift { animation: drift 4s ease-in-out infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes drift { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(2px); } }
      </style>
      <g class="sun-spin">
        <circle cx="20" cy="18" r="8" fill="#FFB800"/>
        <g stroke="#FFB800" stroke-width="2" stroke-linecap="round">
          <line x1="20" y1="4" x2="20" y2="8"/>
          <line x1="20" y1="28" x2="20" y2="32"/>
          <line x1="6" y1="18" x2="10" y2="18"/>
          <line x1="30" y1="18" x2="34" y2="18"/>
        </g>
      </g>
      <g class="cloud-drift">
        <path d="M50 44H22C17.6 44 14 40.4 14 36C14 31.6 17.6 28 22 28C22.3 28 22.6 28 22.9 28.1C24.3 22.5 29.4 18.5 35.5 18.5C42.4 18.5 48.1 23.6 48.9 30.2C49.3 30.1 49.6 30 50 30C54.4 30 58 33.6 58 38C58 41.3 55.9 44 50 44Z" fill="#94A3B8"/>
      </g>
    </svg>
  `,
  // 阴天
  overcast: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .cloud1 { animation: move1 5s ease-in-out infinite; }
        .cloud2 { animation: move2 4s ease-in-out infinite; }
        @keyframes move1 { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(2px); } }
        @keyframes move2 { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(-2px); } }
      </style>
      <g class="cloud1">
        <path d="M44 28H20C16.7 28 14 25.3 14 22C14 18.7 16.7 16 20 16C20.2 16 20.4 16 20.6 16.1C21.7 12 25.4 9 30 9C35.2 9 39.4 12.8 40 17.8C40.3 17.7 40.6 17.6 41 17.6C44.3 17.6 47 20.3 47 23.6C47 26.1 45.5 28 44 28Z" fill="#CBD5E1"/>
      </g>
      <g class="cloud2">
        <path d="M52 46H18C12.5 46 8 41.5 8 36C8 30.5 12.5 26 18 26C18.4 26 18.8 26 19.2 26.1C21 18.8 27.5 13.5 35.2 13.5C44 13.5 51.2 20 52.2 28.4C52.7 28.3 53.1 28.2 53.6 28.2C59.1 28.2 63.6 32.7 63.6 38.2C63.6 42.5 60.8 46 52 46Z" fill="#94A3B8"/>
      </g>
    </svg>
  `,
  // 小雨
  lightRain: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .rain-drop { animation: fall 1s ease-in infinite; }
        .rain-drop:nth-child(2) { animation-delay: 0.2s; }
        .rain-drop:nth-child(3) { animation-delay: 0.4s; }
        @keyframes fall { 0% { opacity: 0; transform: translateY(-4px); } 50% { opacity: 1; } 100% { opacity: 0; transform: translateY(8px); } }
      </style>
      <path d="M48 32H18C13.6 32 10 28.4 10 24C10 19.6 13.6 16 18 16C18.3 16 18.6 16 18.9 16.1C20.3 10.5 25.4 6.5 31.5 6.5C38.4 6.5 44.1 11.6 44.9 18.2C45.3 18.1 45.6 18 46 18C50.4 18 54 21.6 54 26C54 29.3 51.9 32 48 32Z" fill="#94A3B8"/>
      <g fill="#60A5FA">
        <circle class="rain-drop" cx="22" cy="42" r="2"/>
        <circle class="rain-drop" cx="32" cy="46" r="2"/>
        <circle class="rain-drop" cx="42" cy="42" r="2"/>
      </g>
    </svg>
  `,
  // 中雨/大雨
  rain: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .rain-line { animation: rainfall 0.8s linear infinite; }
        .rain-line:nth-child(2) { animation-delay: 0.15s; }
        .rain-line:nth-child(3) { animation-delay: 0.3s; }
        .rain-line:nth-child(4) { animation-delay: 0.45s; }
        .rain-line:nth-child(5) { animation-delay: 0.6s; }
        @keyframes rainfall { 0% { opacity: 0; transform: translateY(-6px); } 30% { opacity: 1; } 100% { opacity: 0; transform: translateY(10px); } }
      </style>
      <path d="M48 30H18C13.6 30 10 26.4 10 22C10 17.6 13.6 14 18 14C18.3 14 18.6 14 18.9 14.1C20.3 8.5 25.4 4.5 31.5 4.5C38.4 4.5 44.1 9.6 44.9 16.2C45.3 16.1 45.6 16 46 16C50.4 16 54 19.6 54 24C54 27.3 51.9 30 48 30Z" fill="#64748B"/>
      <g stroke="#3B82F6" stroke-width="2" stroke-linecap="round">
        <line class="rain-line" x1="18" y1="38" x2="18" y2="46"/>
        <line class="rain-line" x1="26" y1="40" x2="26" y2="50"/>
        <line class="rain-line" x1="34" y1="38" x2="34" y2="48"/>
        <line class="rain-line" x1="42" y1="40" x2="42" y2="50"/>
        <line class="rain-line" x1="50" y1="38" x2="50" y2="46"/>
      </g>
    </svg>
  `,
  // 雷阵雨
  thunderstorm: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .lightning { animation: flash 2s ease-in-out infinite; }
        @keyframes flash { 0%, 90%, 100% { opacity: 1; } 92%, 94% { opacity: 0.3; } }
      </style>
      <path d="M48 28H18C13.6 28 10 24.4 10 20C10 15.6 13.6 12 18 12C18.3 12 18.6 12 18.9 12.1C20.3 6.5 25.4 2.5 31.5 2.5C38.4 2.5 44.1 7.6 44.9 14.2C45.3 14.1 45.6 14 46 14C50.4 14 54 17.6 54 22C54 25.3 51.9 28 48 28Z" fill="#475569"/>
      <path class="lightning" d="M36 30L30 42H36L32 54L44 38H36L40 30H36Z" fill="#FBBF24"/>
      <g stroke="#3B82F6" stroke-width="2" stroke-linecap="round" opacity="0.7">
        <line x1="18" y1="36" x2="18" y2="42"/>
        <line x1="50" y1="36" x2="50" y2="42"/>
      </g>
    </svg>
  `,
  // 雪
  snow: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .snowflake { animation: snowfall 2s ease-in-out infinite; }
        .snowflake:nth-child(2) { animation-delay: 0.4s; }
        .snowflake:nth-child(3) { animation-delay: 0.8s; }
        .snowflake:nth-child(4) { animation-delay: 1.2s; }
        @keyframes snowfall { 0%, 100% { opacity: 0.3; transform: translateY(0); } 50% { opacity: 1; transform: translateY(4px); } }
      </style>
      <path d="M48 30H18C13.6 30 10 26.4 10 22C10 17.6 13.6 14 18 14C18.3 14 18.6 14 18.9 14.1C20.3 8.5 25.4 4.5 31.5 4.5C38.4 4.5 44.1 9.6 44.9 16.2C45.3 16.1 45.6 16 46 16C50.4 16 54 19.6 54 24C54 27.3 51.9 30 48 30Z" fill="#94A3B8"/>
      <g fill="#E2E8F0">
        <circle class="snowflake" cx="20" cy="42" r="3"/>
        <circle class="snowflake" cx="32" cy="48" r="3"/>
        <circle class="snowflake" cx="44" cy="42" r="3"/>
        <circle class="snowflake" cx="26" cy="54" r="2"/>
      </g>
    </svg>
  `,
  // 雾
  fog: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .fog-line { animation: fogmove 3s ease-in-out infinite; }
        .fog-line:nth-child(2) { animation-delay: 0.5s; }
        .fog-line:nth-child(3) { animation-delay: 1s; }
        .fog-line:nth-child(4) { animation-delay: 1.5s; }
        @keyframes fogmove { 0%, 100% { opacity: 0.4; transform: translateX(0); } 50% { opacity: 0.8; transform: translateX(4px); } }
      </style>
      <g stroke="#94A3B8" stroke-width="4" stroke-linecap="round">
        <line class="fog-line" x1="10" y1="20" x2="54" y2="20"/>
        <line class="fog-line" x1="14" y1="30" x2="50" y2="30"/>
        <line class="fog-line" x1="10" y1="40" x2="54" y2="40"/>
        <line class="fog-line" x1="14" y1="50" x2="50" y2="50"/>
      </g>
    </svg>
  `,
  // 霾/沙尘
  haze: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <style>
        .haze-dot { animation: hazefloat 2s ease-in-out infinite; }
        @keyframes hazefloat { 0%, 100% { opacity: 0.3; } 50% { opacity: 0.7; } }
      </style>
      <g fill="#D4A574" class="haze-dot">
        <circle cx="16" cy="20" r="4" style="animation-delay: 0s"/>
        <circle cx="32" cy="16" r="5" style="animation-delay: 0.3s"/>
        <circle cx="48" cy="22" r="4" style="animation-delay: 0.6s"/>
        <circle cx="24" cy="32" r="6" style="animation-delay: 0.2s"/>
        <circle cx="44" cy="36" r="5" style="animation-delay: 0.5s"/>
        <circle cx="18" cy="46" r="4" style="animation-delay: 0.4s"/>
        <circle cx="36" cy="48" r="5" style="animation-delay: 0.1s"/>
        <circle cx="52" cy="50" r="3" style="animation-delay: 0.7s"/>
      </g>
    </svg>
  `,
  // 未知
  unknown: d`
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="20" stroke="#94A3B8" stroke-width="3" fill="none"/>
      <text x="32" y="40" text-anchor="middle" fill="#94A3B8" font-size="24" font-weight="bold">?</text>
    </svg>
  `
}, Ye = {
  // 晴
  100: "sunny",
  150: "clearNight",
  // 多云
  101: "partlyCloudy",
  102: "partlyCloudy",
  103: "partlyCloudy",
  104: "overcast",
  151: "clearNight",
  152: "clearNight",
  153: "clearNight",
  // 雨
  300: "lightRain",
  301: "lightRain",
  302: "thunderstorm",
  303: "thunderstorm",
  304: "thunderstorm",
  305: "lightRain",
  306: "rain",
  307: "rain",
  308: "rain",
  309: "lightRain",
  310: "rain",
  311: "rain",
  312: "rain",
  313: "rain",
  314: "lightRain",
  315: "rain",
  316: "rain",
  317: "rain",
  318: "rain",
  350: "lightRain",
  351: "lightRain",
  399: "rain",
  // 雪
  400: "snow",
  401: "snow",
  402: "snow",
  403: "snow",
  404: "snow",
  405: "snow",
  406: "snow",
  407: "snow",
  408: "snow",
  409: "snow",
  410: "snow",
  456: "snow",
  457: "snow",
  499: "snow",
  // 雾霾沙尘
  500: "fog",
  501: "fog",
  502: "haze",
  503: "haze",
  504: "haze",
  507: "haze",
  508: "haze",
  509: "fog",
  510: "fog",
  511: "haze",
  512: "haze",
  513: "haze",
  514: "haze",
  515: "haze",
  // 其他
  900: "sunny",
  901: "snow",
  999: "unknown"
};
function m(o) {
  const t = Ye[o] || "unknown";
  return Vt[t] || Vt.unknown;
}
const Ge = {
  优: "#22C55E",
  良: "#EAB308",
  轻度污染: "#F97316",
  中度污染: "#EF4444",
  重度污染: "#A855F7",
  严重污染: "#7C2D12"
};
function pt(o) {
  return Ge[o] || "#6B7280";
}
function gt(o) {
  return {
    优: "rgba(34, 197, 94, 0.15)",
    良: "rgba(234, 179, 8, 0.15)",
    轻度污染: "rgba(249, 115, 22, 0.15)",
    中度污染: "rgba(239, 68, 68, 0.15)",
    重度污染: "rgba(168, 85, 247, 0.15)",
    严重污染: "rgba(124, 45, 18, 0.15)"
  }[o] || "rgba(107, 114, 128, 0.15)";
}
class pe extends he {
  constructor() {
    super(), this.weather = null, this.air = null, this.hourly = [], this.daily = [], this.loading = !0, this.error = "", this.config = {}, this._refreshTimer = null;
  }
  async onInitialized() {
    await this.loadConfig(), await this.fetchWeather(), this.startAutoRefresh();
  }
  async onWidgetInfoChanged(t, e) {
    this.requestUpdate();
    const i = t == null ? void 0 : t.config, s = e == null ? void 0 : e.config;
    i && JSON.stringify(i) !== JSON.stringify(s) && (this.config = i, await this.fetchWeather(), this.startAutoRefresh());
  }
  async loadConfig() {
    var t;
    this.config = ((t = this.spCtx.widgetInfo) == null ? void 0 : t.config) || {};
  }
  startAutoRefresh() {
    var e;
    this._refreshTimer && clearInterval(this._refreshTimer);
    const t = (((e = this.config) == null ? void 0 : e.refreshInterval) || 15) * 60 * 1e3;
    this._refreshTimer = setInterval(() => this.fetchWeather(), t);
  }
  onDisconnected() {
    this._refreshTimer && (clearInterval(this._refreshTimer), this._refreshTimer = null);
  }
  async fetchWeather() {
    this.loading = !0, this.error = "";
    const t = (e) => ({
      targetUrl: `https://{{host}}/v7/${e}?location={{location}}&key={{apiKey}}`,
      method: "GET",
      templateReplacements: [
        { placeholder: "{{apiKey}}", fields: ["targetUrl"], dataNode: "config.apiKey" },
        { placeholder: "{{host}}", fields: ["targetUrl"], dataNode: "config.apiHost" },
        { placeholder: "{{location}}", fields: ["targetUrl"], dataNode: "config.locationValue" }
      ]
    });
    try {
      const e = await this.spCtx.api.network.request(t("weather/now")), [i, s, n] = await Promise.all([
        this.spCtx.api.network.request(t("air/now")).catch(() => null),
        this.spCtx.api.network.request(t("weather/24h")),
        this.spCtx.api.network.request(t("weather/7d"))
      ]), a = (e == null ? void 0 : e.data) || e, l = (i == null ? void 0 : i.data) || i, r = (s == null ? void 0 : s.data) || s, h = (n == null ? void 0 : n.data) || n;
      if ((a == null ? void 0 : a.code) === "200")
        this.weather = a.now;
      else {
        const p = {
          400: "请求错误",
          401: "API Key 无效",
          402: "超过访问次数限制",
          403: "无访问权限",
          404: "查询的数据不存在",
          429: "请求过于频繁",
          500: "服务器错误"
        };
        throw new Error(p[a == null ? void 0 : a.code] || `API错误: ${(a == null ? void 0 : a.code) || "未知"}`);
      }
      (l == null ? void 0 : l.code) === "200" && (this.air = l.now), (r == null ? void 0 : r.code) === "200" && (this.hourly = r.hourly || []), (h == null ? void 0 : h.code) === "200" && (this.daily = h.daily || []);
    } catch (e) {
      const i = String((e == null ? void 0 : e.message) || "");
      i.includes("data node not found") || i.includes("failed to get data node") ? this.error = "请先在配置页保存（会写入加密占位所需数据）" : this.error = e.message || "获取天气失败", console.error("Weather fetch error:", e);
    } finally {
      this.loading = !1;
    }
  }
  onDarkModeChanged() {
    this.requestUpdate();
  }
  get cityName() {
    var t;
    return ((t = this.config) == null ? void 0 : t.cityName) || "未知";
  }
  get colors() {
    var e;
    const t = ((e = this.config) == null ? void 0 : e.textMode) !== "dark";
    return {
      text: t ? "#fff" : "#1a1a2e",
      textSub: t ? "rgba(255,255,255,0.75)" : "rgba(0,0,0,0.6)",
      glass: t ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.06)"
    };
  }
  // 基础样式 - 所有尺寸统一防溢出
  get baseStyle() {
    return `
      :host { display: block; width: 100%; height: 100%; overflow: hidden; }
      * { box-sizing: border-box; margin: 0; padding: 0; }
      .w {
        width: 100%; height: 100%;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        color: ${this.colors.text};
        display: flex; flex-direction: column;
        overflow: hidden;
        min-height: 0;
      }
    `;
  }
  render() {
    var i;
    const t = this.colors;
    if (!this.config || Object.keys(this.config).length === 0)
      return d`<style>${this.baseStyle}.w{align-items:center;justify-content:center;font-size:11px;color:${t.textSub}}</style><div class="w">请配置 API Key</div>`;
    if (this.loading)
      return d`<style>${this.baseStyle}.w{align-items:center;justify-content:center;font-size:11px;color:${t.textSub}}</style><div class="w">加载中...</div>`;
    if (this.error)
      return d`<style>${this.baseStyle}.w{align-items:center;justify-content:center;font-size:11px;color:#f87171}</style><div class="w">${this.error}</div>`;
    switch ((i = this.spCtx.widgetInfo) == null ? void 0 : i.gridSize) {
      case "1x1":
        return this.render1x1();
      case "1x2":
        return this.render1x2();
      case "1xfull":
        return this.render1xfull();
      case "2x1":
        return this.render2x1();
      case "2x2":
        return this.render2x2();
      case "2x4":
        return this.render2x4();
      default:
        return this.render2x2();
    }
  }
  // 1x1: 极简紧凑
  render1x1() {
    const t = this.weather;
    return d`
      <style>
        ${this.baseStyle}
        .w { align-items: center; justify-content: center; gap: 2px; padding: 4px; }
        .icon { width: 36px; height: 36px; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.15)); }
        .temp { font-size: 22px; font-weight: 700; letter-spacing: -1px; }
      </style>
      <div class="w">
        <div class="icon">${m(t.icon)}</div>
        <div class="temp">${t.temp}°</div>
      </div>
    `;
  }
  // 1x2: 横向卡片（1行x2列）- 紧凑防溢出
  render1x2() {
    const t = this.weather, e = this.colors, i = this.hourly.slice(0, 3);
    return d`
      <style>
        ${this.baseStyle}
        .w { flex-direction: row; padding: 6px 10px; align-items: center; }

        .now { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }
        .icon { width: 26px; height: 26px; }
        .temp { font-size: 20px; font-weight: 700; letter-spacing: -1px; }

        .sep { width: 1px; height: 26px; background: ${e.glass}; margin: 0 8px; flex-shrink: 0; }

        .hrs { display: flex; flex: 1; justify-content: space-around; min-width: 0; }
        .h { display: flex; flex-direction: column; align-items: center; gap: 0; }
        .h-t { font-size: 8px; color: ${e.textSub}; }
        .h-i { width: 16px; height: 16px; }
        .h-v { font-size: 9px; font-weight: 600; }
      </style>
      <div class="w">
        <div class="now">
          <div class="icon">${m(t.icon)}</div>
          <span class="temp">${t.temp}°</span>
        </div>
        <div class="sep"></div>
        <div class="hrs">
          ${i.map((s) => d`
            <div class="h">
              <span class="h-t">${s.fxTime.slice(11, 16)}</span>
              <div class="h-i">${m(s.icon)}</div>
              <span class="h-v">${s.temp}°</span>
            </div>
          `)}
        </div>
      </div>
    `;
  }
  // 1xfull: 横向长条 - 自适应填充 + 分割线 + 移动端适配
  render1xfull() {
    const t = this.weather, e = this.air, i = this.colors, s = this.hourly.slice(0, 6), n = this.daily.slice(0, 5);
    return d`
      <style>
        ${this.baseStyle}
        .w {
          flex-direction: row;
          padding: 6px 12px;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
        }

        /* 当前天气 */
        .now { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }
        .city-pill {
          padding: 3px 8px;
          background: linear-gradient(135deg, rgba(255,255,255,0.18), rgba(255,255,255,0.08));
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 10px;
          font-size: 10px;
          font-weight: 600;
          backdrop-filter: blur(4px);
          white-space: nowrap;
        }
        .icon { width: 24px; height: 24px; flex-shrink: 0; }
        .temp { font-size: 20px; font-weight: 700; letter-spacing: -1px; white-space: nowrap; }
        .aqi { padding: 2px 5px; border-radius: 8px; font-size: 8px; font-weight: 600; white-space: nowrap; }

        /* 分割线 */
        .sep { width: 1px; height: 24px; background: ${i.glass}; flex-shrink: 0; }

        /* 预报区块 - 自适应填充 */
        .forecast { display: flex; flex: 1; justify-content: space-around; min-width: 0; overflow: hidden; }
        .forecast.hourly { flex: 1.2; }
        .forecast.daily { flex: 1; }
        .f-item { display: flex; flex-direction: column; align-items: center; gap: 0; min-width: 0; }
        .f-t { font-size: 8px; color: ${i.textSub}; white-space: nowrap; }
        .f-i { width: 14px; height: 14px; flex-shrink: 0; }
        .f-v { font-size: 9px; font-weight: 600; white-space: nowrap; }
        .f-v span { opacity: 0.5; }

        /* 详情 */
        .detail { font-size: 9px; color: ${i.textSub}; flex-shrink: 0; white-space: nowrap; }
        .detail b { color: ${i.text}; font-weight: 600; }

        /* 移动端适配 - 小屏幕 */
        @media (max-width: 480px) {
          .w { padding: 4px 8px; gap: 6px; }
          .city-pill { display: none; }
          .aqi { display: none; }
          .forecast.daily { display: none; }
          .sep.daily-sep { display: none; }
          .detail { display: none; }
          .sep.detail-sep { display: none; }
          .f-item:nth-child(n+5) { display: none; }
        }

        /* 中等屏幕 */
        @media (min-width: 481px) and (max-width: 680px) {
          .w { padding: 5px 10px; gap: 8px; }
          .city-pill { padding: 2px 6px; font-size: 9px; }
          .detail { display: none; }
          .sep.detail-sep { display: none; }
          .f-item:nth-child(n+5) { display: none; }
          .forecast.daily .f-item:nth-child(n+4) { display: none; }
        }

        /* 较大屏幕 */
        @media (min-width: 681px) and (max-width: 900px) {
          .f-item:nth-child(n+6) { display: none; }
          .forecast.daily .f-item:nth-child(n+5) { display: none; }
        }
      </style>
      <div class="w">
        <div class="now">
          <span class="city-pill">${this.cityName}</span>
          <div class="icon">${m(t.icon)}</div>
          <span class="temp">${t.temp}°</span>
          ${e ? d`<span class="aqi" style="background:${gt(e.category)};color:${pt(e.category)}">${e.category}</span>` : ""}
        </div>

        <div class="sep"></div>

        <div class="forecast hourly">
          ${s.map((a) => d`
            <div class="f-item">
              <span class="f-t">${a.fxTime.slice(11, 16)}</span>
              <div class="f-i">${m(a.icon)}</div>
              <span class="f-v">${a.temp}°</span>
            </div>
          `)}
        </div>

        <div class="sep daily-sep"></div>

        <div class="forecast daily">
          ${n.map((a, l) => d`
            <div class="f-item">
              <span class="f-t">${l === 0 ? "今天" : l === 1 ? "明天" : a.fxDate.slice(5)}</span>
              <div class="f-i">${m(a.iconDay)}</div>
              <span class="f-v">${a.tempMax}°<span>/${a.tempMin}°</span></span>
            </div>
          `)}
        </div>

        <div class="sep detail-sep"></div>

        <span class="detail">体感<b>${t.feelsLike}°</b> 湿度<b>${t.humidity}%</b></span>
      </div>
    `;
  }
  // 2x1: 竖向卡片（2行x1列）
  render2x1() {
    const t = this.weather, e = this.colors, i = d`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"/></svg>`, s = d`<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>`;
    return d`
      <style>
        ${this.baseStyle}
        .w { padding: 8px; justify-content: center; align-items: center; gap: 3px; }
        .top { display: flex; align-items: center; gap: 6px; }
        .icon { width: 28px; height: 28px; }
        .temp { font-size: 24px; font-weight: 700; letter-spacing: -1px; }
        .desc { font-size: 12px; color: ${e.textSub}; }
        .meta { display: flex; flex-direction: column; align-items: center; gap: 1px; font-size: 11px; color: ${e.textSub}; }
        .meta-item { display: flex; align-items: center; gap: 3px; }
        .meta-item svg { opacity: 0.7; }
        .meta b { color: ${e.text}; font-weight: 600; }
      </style>
      <div class="w">
        <div class="top">
          <div class="icon">${m(t.icon)}</div>
          <span class="temp">${t.temp}°</span>
        </div>
        <span class="desc">${t.text}</span>
        <div class="meta">
          <span class="meta-item">${i}<b>${t.feelsLike}°</b></span>
          <span class="meta-item">${s}<b>${t.humidity}%</b></span>
        </div>
      </div>
    `;
  }
  // 2x2: 方形卡片 - 简洁 + 分割线
  render2x2() {
    const t = this.weather, e = this.air, i = this.colors, s = this.hourly.slice(0, 4);
    return d`
      <style>
        ${this.baseStyle}
        .w { padding: 10px 12px; justify-content: space-between; }

        .head { display: flex; justify-content: space-between; align-items: center; }
        .city-pill {
          padding: 3px 10px;
          background: linear-gradient(135deg, rgba(255,255,255,0.18), rgba(255,255,255,0.08));
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 12px;
          font-size: 11px;
          font-weight: 600;
          backdrop-filter: blur(4px);
        }
        .aqi { padding: 3px 8px; border-radius: 10px; font-size: 10px; font-weight: 600; }

        .main { display: flex; align-items: center; gap: 10px; }
        .icon { width: 48px; height: 48px; filter: drop-shadow(0 3px 6px rgba(0,0,0,0.2)); }
        .info { flex: 1; }
        .temp { font-size: 34px; font-weight: 700; line-height: 1; letter-spacing: -2px; }
        .desc { font-size: 11px; color: ${i.textSub}; margin-top: 2px; }

        .sep { width: 100%; height: 1px; background: ${i.glass}; }

        .hrs { display: flex; justify-content: space-between; }
        .h { display: flex; flex-direction: column; align-items: center; gap: 1px; }
        .h-t { font-size: 9px; color: ${i.textSub}; }
        .h-i { width: 16px; height: 16px; }
        .h-v { font-size: 10px; font-weight: 600; }

        .meta { display: flex; justify-content: space-between; font-size: 10px; color: ${i.textSub}; }
        .meta b { color: ${i.text}; font-weight: 600; }
      </style>
      <div class="w">
        <div class="head">
          <span class="city-pill">${this.cityName}</span>
          ${e ? d`<span class="aqi" style="background:${gt(e.category)};color:${pt(e.category)}">${e.category} ${e.aqi}</span>` : ""}
        </div>

        <div class="main">
          <div class="icon">${m(t.icon)}</div>
          <div class="info">
            <div class="temp">${t.temp}°</div>
            <div class="desc">${t.text} · 体感${t.feelsLike}°</div>
          </div>
        </div>

        <div class="sep"></div>

        <div class="hrs">
          ${s.map((n) => d`
            <div class="h">
              <span class="h-t">${n.fxTime.slice(11, 16)}</span>
              <div class="h-i">${m(n.icon)}</div>
              <span class="h-v">${n.temp}°</span>
            </div>
          `)}
        </div>

        <div class="sep"></div>

        <div class="meta">
          <span>${t.windDir} <b>${t.windScale}级</b></span>
          <span>湿度 <b>${t.humidity}%</b></span>
          <span>能见度 <b>${t.vis}km</b></span>
        </div>
      </div>
    `;
  }
  // 2x4: 精致布局 - 美化胶囊城市 + 图标 + 温度
  render2x4() {
    const t = this.weather, e = this.air, i = this.colors, s = this.hourly.slice(0, 5), n = this.daily.slice(0, 3);
    return d`
      <style>
        ${this.baseStyle}
        .w {
          padding: 6px;
          display: flex;
          flex-direction: column;
          gap: 4px;
          height: 100%;
          min-height: 0;
        }

        /* 头部 */
        .head {
          display: flex;
          align-items: center;
          gap: 6px;
          flex-shrink: 0;
        }
        .city-pill {
          padding: 3px 8px;
          background: linear-gradient(135deg, rgba(255,255,255,0.18), rgba(255,255,255,0.08));
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 12px;
          font-size: 10px;
          font-weight: 600;
          white-space: nowrap;
          backdrop-filter: blur(4px);
        }
        .icon { width: 24px; height: 24px; flex-shrink: 0; }
        .temp { font-size: 20px; font-weight: 700; letter-spacing: -1px; }
        .spacer { flex: 1; }
        .aqi {
          padding: 2px 6px;
          border-radius: 8px;
          font-size: 9px;
          font-weight: 600;
        }

        /* 预报卡片 - 紧凑 */
        .card {
          background: ${i.glass};
          border-radius: 8px;
          padding: 4px 6px;
          display: flex;
          justify-content: space-around;
          align-items: center;
          flex: 1;
          min-height: 0;
          overflow: hidden;
        }
        .item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 1px;
          min-height: 0;
        }
        .item-t { font-size: 9px; color: ${i.textSub}; }
        .item-i { width: 18px; height: 18px; flex-shrink: 0; }
        .item-v { font-size: 10px; font-weight: 600; }
        .item-v span { opacity: 0.5; font-weight: 400; }
      </style>
      <div class="w">
        <div class="head">
          <span class="city-pill">${this.cityName}</span>
          <div class="icon">${m(t.icon)}</div>
          <span class="temp">${t.temp}°</span>
          <div class="spacer"></div>
          ${e ? d`<span class="aqi" style="background:${gt(e.category)};color:${pt(e.category)}">${e.category}</span>` : ""}
        </div>
        <div class="card">
          ${s.map((a) => d`
            <div class="item">
              <span class="item-t">${a.fxTime.slice(11, 16)}</span>
              <div class="item-i">${m(a.icon)}</div>
              <span class="item-v">${a.temp}°</span>
            </div>
          `)}
        </div>
        <div class="card">
          ${n.map((a, l) => d`
            <div class="item">
              <span class="item-t">${l === 0 ? "今天" : l === 1 ? "明天" : a.fxDate.slice(5)}</span>
              <div class="item-i">${m(a.iconDay)}</div>
              <span class="item-v">${a.tempMax}°<span>/${a.tempMin}°</span></span>
            </div>
          `)}
        </div>
      </div>
    `;
  }
}
st(pe, "properties", {
  weather: { type: Object },
  air: { type: Object },
  hourly: { type: Array },
  daily: { type: Array },
  loading: { type: Boolean },
  error: { type: String },
  config: { type: Object }
});
class ge extends de {
  constructor() {
    super(), this.widgetInfo = {}, this.apiKey = "", this.apiHost = "", this.amapKey = "", this.hasSavedApiKey = !1, this.hasSavedApiHost = !1, this.hasSavedAmapKey = !1, this.showApiKey = !1, this.showApiHost = !1, this.showAmapKey = !1, this.loadingApiKey = !1, this.loadingApiHost = !1, this.loadingAmapKey = !1, this.locationMode = "manual", this.location = "101010100", this.cityName = "北京", this.longitude = "", this.latitude = "", this.refreshInterval = 15, this.textMode = "light", this.saving = !1, this.locating = !1, this.error = "", this.locationStatus = "";
  }
  async onInitialized({ widgetInfo: t, customParam: e }) {
    var s;
    this.widgetInfo = t || {};
    const i = ((s = this.widgetInfo) == null ? void 0 : s.config) || {};
    this.apiKey = "", this.apiHost = "", this.amapKey = "", this.showApiKey = !1, this.showApiHost = !1, this.showAmapKey = !1, this.loadingApiKey = !1, this.loadingApiHost = !1, this.loadingAmapKey = !1, this.error = "", this.locationStatus = "", this.locationMode = i.locationMode || "manual", this.location = i.location || "101010100", this.cityName = i.cityName || "北京", this.refreshInterval = i.refreshInterval || 15, this.textMode = i.textMode || "light", this.longitude = i.longitude || "", this.latitude = i.latitude || "", this.hasSavedApiKey = !!(i.hasSavedApiKey ?? i.templateDataNode), this.hasSavedApiHost = !!(i.hasSavedApiHost ?? i.templateDataNode), this.hasSavedAmapKey = !!i.hasSavedAmapKey, this.requestUpdate();
  }
  getMaskedPlaceholder(t, e) {
    return e ? `•••••• 已保存（点击右侧眼睛读取${t}）` : "";
  }
  getSecretStatus(t, e) {
    return e ? "读取中..." : t ? "已保存" : "未保存";
  }
  getSecretStatusClass(t, e) {
    return e ? "status-tag loading" : t ? "status-tag saved" : "status-tag empty";
  }
  async toggleSecretVisibility(t) {
    var n;
    const i = {
      apiKey: {
        show: "showApiKey",
        loading: "loadingApiKey",
        saved: "hasSavedApiKey",
        value: "apiKey",
        label: "和风 API Key"
      },
      apiHost: {
        show: "showApiHost",
        loading: "loadingApiHost",
        saved: "hasSavedApiHost",
        value: "apiHost",
        label: "和风 Host"
      },
      amapKey: {
        show: "showAmapKey",
        loading: "loadingAmapKey",
        saved: "hasSavedAmapKey",
        value: "amapKey",
        label: "高德 Key"
      }
    }[t];
    if (!i) return;
    if (this[i.show]) {
      this[i.show] = !1;
      return;
    }
    if (!!((n = this[i.value]) != null && n.trim())) {
      this[i.show] = !0;
      return;
    }
    this[i.loading] = !0, this.error = "";
    try {
      const a = await this.spCtx.api.dataNode.app.getByKey("config", t);
      typeof a == "string" && a.trim() ? (this[i.value] = a.trim(), this[i.saved] = !0) : this[i.saved] = !1, this[i.show] = !0;
    } catch (a) {
      const l = String((a == null ? void 0 : a.message) || "").toLowerCase();
      Number(a == null ? void 0 : a.code) === 1202 || l.includes("no data record found") || l.includes("data node not found") ? (this[i.saved] = !1, this.error = `${i.label} 尚未保存`) : this.error = `读取${i.label}失败: ${(a == null ? void 0 : a.message) || "未知错误"}`;
    } finally {
      this[i.loading] = !1;
    }
  }
  normalizeHost(t) {
    return t.replace(/^https?:\/\//, "").replace(/\/$/, "").trim();
  }
  async reverseGeocodeAMap(t, e) {
    try {
      const i = this.amapKey.trim();
      if (i)
        await this.spCtx.api.dataNode.app.setByKey("config", "amapKey", i), this.hasSavedAmapKey = !0;
      else if (!this.hasSavedAmapKey)
        return null;
      await this.spCtx.api.dataNode.app.setByKey("config", "geoLocation", `${t},${e}`);
      const s = await this.spCtx.api.network.request({
        targetUrl: "https://restapi.amap.com/v3/geocode/regeo?key={{amapKey}}&location={{geoLocation}}&extensions=base",
        method: "GET",
        templateReplacements: [
          { placeholder: "{{amapKey}}", fields: ["targetUrl"], dataNode: "config.amapKey" },
          { placeholder: "{{geoLocation}}", fields: ["targetUrl"], dataNode: "config.geoLocation" }
        ]
      }), n = (s == null ? void 0 : s.data) || s;
      if (n.status === "1" && n.regeocode) {
        const a = n.regeocode.addressComponent, l = String(a.province || ""), r = String(a.city || ""), h = String(a.district || ""), p = l.replace("市", ""), c = r.replace("市", ""), u = p && c && p === c;
        let g;
        return u ? g = p : c ? g = c : g = p, g || null;
      }
      return null;
    } catch (i) {
      return console.warn("高德逆地理编码失败:", i), null;
    }
  }
  async detectLocation() {
    if (!navigator.geolocation) {
      this.error = "浏览器不支持定位功能";
      return;
    }
    this.locating = !0, this.error = "", this.locationStatus = "正在获取位置...";
    try {
      const t = await new Promise((e, i) => {
        navigator.geolocation.getCurrentPosition(e, i, {
          enableHighAccuracy: !0,
          timeout: 1e4,
          maximumAge: 0
        });
      });
      if (this.longitude = t.coords.longitude.toFixed(2), this.latitude = t.coords.latitude.toFixed(2), this.amapKey.trim() || this.hasSavedAmapKey) {
        this.locationStatus = "正在获取城市名称...";
        const e = await this.reverseGeocodeAMap(this.longitude, this.latitude);
        e ? (this.cityName = e, this.locationStatus = `定位成功: ${e} (${this.longitude}, ${this.latitude})`) : this.locationStatus = `已获取坐标: ${this.longitude}, ${this.latitude}`;
      } else
        this.locationStatus = `已获取坐标: ${this.longitude}, ${this.latitude}（未配置高德 Key，无法自动识别城市名）`;
    } catch (t) {
      const e = {
        1: "用户拒绝了定位请求",
        2: "无法获取位置信息",
        3: "定位请求超时"
      };
      this.error = e[t.code] || "定位失败", this.locationStatus = "";
    } finally {
      this.locating = !1;
    }
  }
  getLocationValue() {
    return this.locationMode === "auto" ? this.longitude && this.latitude ? `${this.longitude},${this.latitude}` : "" : this.location;
  }
  async handleSaveOrCreateWidget() {
    const t = this.apiKey.trim();
    if (!!!(t || this.hasSavedApiKey)) {
      this.error = "请输入和风天气 API Key";
      return;
    }
    const i = this.getLocationValue();
    if (!i) {
      this.error = this.locationMode === "auto" ? "请先获取当前位置" : "请输入城市位置";
      return;
    }
    this.saving = !0, this.error = "";
    try {
      let s = this.hasSavedApiKey, n = this.hasSavedApiHost, a = this.hasSavedAmapKey;
      const l = this.apiHost.trim(), r = this.normalizeHost(l || "devapi.qweather.com"), h = this.amapKey.trim();
      t && (await this.spCtx.api.dataNode.app.setByKey("config", "apiKey", t), s = !0), (l || !n) && (await this.spCtx.api.dataNode.app.setByKey("config", "apiHost", r), n = !0), h && (await this.spCtx.api.dataNode.app.setByKey("config", "amapKey", h), a = !0), await this.spCtx.api.dataNode.app.setByKey("config", "locationValue", i);
      const p = {
        locationMode: this.locationMode,
        location: this.location.trim(),
        cityName: this.cityName.trim() || "未知",
        refreshInterval: this.refreshInterval,
        textMode: this.textMode,
        longitude: this.longitude,
        latitude: this.latitude,
        hasSavedApiKey: s,
        hasSavedApiHost: n,
        hasSavedAmapKey: a,
        templateDataNode: "config.apiKey"
      };
      await this.spCtx.api.dataNode.app.setByKey("config", "settings", p), this.hasSavedApiKey = s, this.hasSavedApiHost = n, this.hasSavedAmapKey = a, await this.spCtx.api.widget.save({
        ...this.widgetInfo,
        config: p
      });
    } catch (s) {
      this.error = "保存失败: " + ((s == null ? void 0 : s.message) || "未知错误");
    } finally {
      this.saving = !1;
    }
  }
  getButtonTitle() {
    var t;
    return ((t = this.widgetInfo) == null ? void 0 : t.id) !== 0 ? "保存" : "创建";
  }
  get iconKey() {
    return d`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>`;
  }
  get iconLocation() {
    return d`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>`;
  }
  get iconClock() {
    return d`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>`;
  }
  get iconTarget() {
    return d`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>`;
  }
  get iconMap() {
    return d`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg>`;
  }
  get iconEye() {
    return d`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>`;
  }
  get iconEyeOff() {
    return d`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19C5 19 1 12 1 12a21.85 21.85 0 0 1 5.06-5.94"/><path d="M9.9 4.24A10.9 10.9 0 0 1 12 4c7 0 11 8 11 8a21.86 21.86 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
  }
  render() {
    var i;
    const t = ((i = this.spCtx) == null ? void 0 : i.darkMode) ?? !1, e = {
      bg: t ? "#1a1a1a" : "#ffffff",
      cardBg: t ? "#242424" : "#f8f9fa",
      border: t ? "#333" : "#e5e7eb",
      text: t ? "#e5e5e5" : "#1f2937",
      textSecondary: t ? "#a0a0a0" : "#6b7280",
      accent: "#3b82f6",
      inputBg: t ? "#1a1a1a" : "#ffffff",
      error: "#ef4444",
      success: "#22c55e"
    };
    return d`
      <style>
        :host { display: block; height: 100%; width: 100%; }
        * { box-sizing: border-box; }
        .config-container {
          height: 100%; width: 100%; padding: 20px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          color: ${e.text};
          display: flex; flex-direction: column;
          background: ${e.bg};
        }
        .config-header { margin-bottom: 20px; }
        .config-title { font-size: 18px; font-weight: 600; margin: 0 0 4px; color: ${e.text}; }
        .config-subtitle { font-size: 13px; color: ${e.textSecondary}; margin: 0; }
        .config-content { flex: 1; overflow-y: auto; }
        .config-section {
          background: ${e.cardBg};
          border: 1px solid ${e.border};
          border-radius: 8px; padding: 16px; margin-bottom: 16px;
        }
        .section-header {
          display: flex; align-items: center; gap: 8px;
          margin-bottom: 16px; color: ${e.textSecondary};
        }
        .section-title { font-size: 13px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px; }
        .form-row { margin-bottom: 16px; }
        .form-row:last-child { margin-bottom: 0; }
        .label-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          margin-bottom: 6px;
        }
        .form-label { display: block; font-size: 13px; font-weight: 500; color: ${e.text}; margin-bottom: 6px; }
        .label-row .form-label { margin-bottom: 0; }
        .form-input {
          width: 100%; padding: 10px 12px; font-size: 14px;
          border: 1px solid ${e.border}; border-radius: 6px;
          background: ${e.inputBg}; color: ${e.text};
          transition: border-color 0.2s;
        }
        .form-input:focus { outline: none; border-color: ${e.accent}; }
        .form-input::placeholder { color: ${e.textSecondary}; }
        .input-wrap {
          display: grid;
          grid-template-columns: minmax(0, 1fr) 42px;
          gap: 8px;
          align-items: center;
        }
        .btn-eye {
          height: 40px;
          border: 1px solid ${e.border};
          background: ${e.inputBg};
          color: ${e.textSecondary};
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .btn-eye:hover:not(:disabled) {
          color: ${e.accent};
          border-color: ${e.accent};
        }
        .btn-eye:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        .status-tag {
          font-size: 11px;
          padding: 2px 8px;
          border-radius: 999px;
          border: 1px solid transparent;
          line-height: 1.5;
        }
        .status-tag.saved {
          color: ${t ? "#86efac" : "#166534"};
          border-color: ${t ? "rgba(34,197,94,.35)" : "#86efac"};
          background: ${t ? "rgba(34,197,94,.12)" : "#f0fdf4"};
        }
        .status-tag.empty {
          color: ${e.textSecondary};
          border-color: ${e.border};
          background: ${t ? "rgba(255,255,255,.04)" : "#f9fafb"};
        }
        .status-tag.loading {
          color: ${t ? "#93c5fd" : "#1d4ed8"};
          border-color: ${t ? "rgba(59,130,246,.4)" : "#bfdbfe"};
          background: ${t ? "rgba(59,130,246,.12)" : "#eff6ff"};
        }
        .form-hint { font-size: 12px; color: ${e.textSecondary}; margin-top: 4px; }
        .form-hint a { color: ${e.accent}; text-decoration: none; }
        .info-box {
          display: flex; align-items: flex-start; gap: 8px;
          padding: 10px 12px; margin-bottom: 16px; font-size: 12px;
          color: ${t ? "#93c5fd" : "#1e3a8a"};
          background: ${t ? "rgba(59, 130, 246, 0.1)" : "rgba(59, 130, 246, 0.06)"};
          border: 1px solid ${t ? "rgba(59, 130, 246, 0.3)" : "rgba(59, 130, 246, 0.28)"};
          border-radius: 6px; line-height: 1.5;
        }
        .info-box svg { flex-shrink: 0; margin-top: 2px; }
        .info-box code {
          padding: 1px 4px; font-size: 11px;
          background: ${t ? "rgba(0,0,0,0.3)" : "rgba(0,0,0,0.06)"};
          border-radius: 3px; font-family: monospace;
        }
        .radio-group { display: flex; gap: 12px; }
        .radio-item {
          flex: 1; display: flex; align-items: center; gap: 8px;
          padding: 10px 12px; border: 1px solid ${e.border};
          border-radius: 6px; cursor: pointer; transition: all 0.2s;
          background: ${e.inputBg};
        }
        .radio-item:hover { border-color: ${e.accent}; }
        .radio-item.active {
          border-color: ${e.accent};
          background: ${t ? "rgba(59, 130, 246, 0.1)" : "rgba(59, 130, 246, 0.05)"};
        }
        .radio-item input { display: none; }
        .radio-dot {
          width: 16px; height: 16px; border: 2px solid ${e.border};
          border-radius: 50%; display: flex; align-items: center;
          justify-content: center; flex-shrink: 0;
        }
        .radio-item.active .radio-dot { border-color: ${e.accent}; }
        .radio-dot::after {
          content: ''; width: 8px; height: 8px; border-radius: 50%;
          background: ${e.accent}; opacity: 0; transition: opacity 0.2s;
        }
        .radio-item.active .radio-dot::after { opacity: 1; }
        .radio-label { font-size: 13px; color: ${e.text}; }
        .coords-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .btn-locate {
          display: flex; align-items: center; justify-content: center; gap: 6px;
          width: 100%; padding: 10px; margin-top: 12px;
          font-size: 13px; font-weight: 500; color: ${e.accent};
          background: ${t ? "rgba(59, 130, 246, 0.1)" : "rgba(59, 130, 246, 0.05)"};
          border: 1px solid ${e.accent}; border-radius: 6px;
          cursor: pointer; transition: all 0.2s;
        }
        .btn-locate:hover:not(:disabled) { background: ${t ? "rgba(59, 130, 246, 0.2)" : "rgba(59, 130, 246, 0.1)"}; }
        .btn-locate:disabled { opacity: 0.5; cursor: not-allowed; }
        .location-status {
          display: flex; align-items: center; gap: 6px;
          margin-top: 8px; padding: 8px 10px; font-size: 12px;
          color: ${e.success};
          background: ${t ? "rgba(34, 197, 94, 0.1)" : "rgba(34, 197, 94, 0.05)"};
          border-radius: 6px;
        }
        .error-msg {
          display: flex; align-items: center; gap: 6px;
          margin-top: 16px; padding: 10px 12px; font-size: 13px;
          color: ${e.error};
          background: ${t ? "rgba(239, 68, 68, 0.1)" : "rgba(239, 68, 68, 0.05)"};
          border-radius: 6px;
        }
        .config-footer { padding-top: 16px; border-top: 1px solid ${e.border}; margin-top: 16px; }
        .btn-save {
          width: 100%; padding: 12px; font-size: 14px; font-weight: 500;
          color: #fff; background: ${e.accent}; border: none;
          border-radius: 6px; cursor: pointer; transition: all 0.2s;
        }
        .btn-save:hover:not(:disabled) { background: #2563eb; }
        .btn-save:disabled { opacity: 0.5; cursor: not-allowed; }
        select.form-input { cursor: pointer; }
      </style>

      <div class="config-container">
        <div class="config-header">
          <h1 class="config-title">天气配置</h1>
          <p class="config-subtitle">配置和风天气 API 以显示天气信息</p>
        </div>

        <div class="config-content">
          <!-- API 配置 -->
          <div class="config-section">
            <div class="section-header">
              ${this.iconKey}
              <span class="section-title">API 配置</span>
            </div>

            <div class="info-box">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              <div>
                敏感字段默认隐藏。点击右侧眼睛会在当次操作时调用 <code>dataNode.app.getByKey</code> 读取并展示；不点击不会回显明文。<br>
                空值保存策略：留空不会覆盖已保存密钥。若使用自定义 Host，请先在 <code>networkDomains</code> 白名单声明对应域名。
              </div>
            </div>

            <div class="form-row">
              <div class="label-row">
                <label class="form-label">和风天气 API Key *</label>
                <span class="${this.getSecretStatusClass(this.hasSavedApiKey, this.loadingApiKey)}">
                  ${this.getSecretStatus(this.hasSavedApiKey, this.loadingApiKey)}
                </span>
              </div>
              <div class="input-wrap">
                <input class="form-input"
                  type="${this.showApiKey ? "text" : "password"}"
                  autocomplete="off"
                  .value="${this.apiKey}"
                  @input="${(s) => {
      this.apiKey = s.target.value, this.error = "";
    }}"
                  placeholder="${this.getMaskedPlaceholder("和风 API Key", this.hasSavedApiKey) || "输入和风天气 API Key"}">
                <button type="button" class="btn-eye"
                  title="${this.showApiKey ? "隐藏" : "显示"}"
                  ?disabled="${this.loadingApiKey}"
                  @click="${() => this.toggleSecretVisibility("apiKey")}">
                  ${this.showApiKey ? this.iconEyeOff : this.iconEye}
                </button>
              </div>
              <div class="form-hint">在 <a href="https://dev.qweather.com" target="_blank">和风天气开发平台</a> 获取</div>
            </div>

            <div class="form-row">
              <div class="label-row">
                <label class="form-label">和风 API Host</label>
                <span class="${this.getSecretStatusClass(this.hasSavedApiHost, this.loadingApiHost)}">
                  ${this.getSecretStatus(this.hasSavedApiHost, this.loadingApiHost)}
                </span>
              </div>
              <div class="input-wrap">
                <input class="form-input"
                  type="${this.showApiHost ? "text" : "password"}"
                  autocomplete="off"
                  .value="${this.apiHost}"
                  @input="${(s) => {
      this.apiHost = s.target.value, this.error = "";
    }}"
                  placeholder="${this.getMaskedPlaceholder("和风 Host", this.hasSavedApiHost) || "devapi.qweather.com"}">
                <button type="button" class="btn-eye"
                  title="${this.showApiHost ? "隐藏" : "显示"}"
                  ?disabled="${this.loadingApiHost}"
                  @click="${() => this.toggleSecretVisibility("apiHost")}">
                  ${this.showApiHost ? this.iconEyeOff : this.iconEye}
                </button>
              </div>
              <div class="form-hint">不填时默认使用 <code>devapi.qweather.com</code></div>
            </div>

            <div class="form-row">
              <div class="label-row">
                <label class="form-label">高德地图 API Key（可选）</label>
                <span class="${this.getSecretStatusClass(this.hasSavedAmapKey, this.loadingAmapKey)}">
                  ${this.getSecretStatus(this.hasSavedAmapKey, this.loadingAmapKey)}
                </span>
              </div>
              <div class="input-wrap">
                <input class="form-input"
                  type="${this.showAmapKey ? "text" : "password"}"
                  autocomplete="off"
                  .value="${this.amapKey}"
                  @input="${(s) => {
      this.amapKey = s.target.value, this.error = "";
    }}"
                  placeholder="${this.getMaskedPlaceholder("高德 Key", this.hasSavedAmapKey) || "用于自动定位时获取城市名称"}">
                <button type="button" class="btn-eye"
                  title="${this.showAmapKey ? "隐藏" : "显示"}"
                  ?disabled="${this.loadingAmapKey}"
                  @click="${() => this.toggleSecretVisibility("amapKey")}">
                  ${this.showAmapKey ? this.iconEyeOff : this.iconEye}
                </button>
              </div>
              <div class="form-hint">在 <a href="https://console.amap.com" target="_blank">高德开放平台</a> 获取，用于逆地理编码</div>
            </div>
          </div>

          <!-- 位置设置 -->
          <div class="config-section">
            <div class="section-header">
              ${this.iconLocation}
              <span class="section-title">位置设置</span>
            </div>

            <div class="form-row">
              <label class="form-label">定位方式</label>
              <div class="radio-group">
                <label class="radio-item ${this.locationMode === "manual" ? "active" : ""}" @click="${() => {
      this.locationMode = "manual", this.error = "";
    }}">
                  <input type="radio" name="mode" value="manual" .checked="${this.locationMode === "manual"}">
                  <span class="radio-dot"></span>
                  <span class="radio-label">城市ID</span>
                </label>
                <label class="radio-item ${this.locationMode === "auto" ? "active" : ""}" @click="${() => {
      this.locationMode = "auto", this.error = "";
    }}">
                  <input type="radio" name="mode" value="auto" .checked="${this.locationMode === "auto"}">
                  <span class="radio-dot"></span>
                  <span class="radio-label">经纬度</span>
                </label>
              </div>
            </div>

            <div class="form-row">
              <label class="form-label">城市名称</label>
              <input type="text" class="form-input"
                .value="${this.cityName}"
                @input="${(s) => this.cityName = s.target.value}"
                placeholder="${this.locationMode === "auto" ? "定位后自动获取或手动输入" : "北京"}">
              <div class="form-hint">显示在卡片上的城市名称</div>
            </div>

            ${this.locationMode === "manual" ? d`
              <div class="form-row">
                <label class="form-label">城市ID</label>
                <input type="text" class="form-input"
                  .value="${this.location}"
                  @input="${(s) => {
      this.location = s.target.value, this.error = "";
    }}"
                  placeholder="101010100">
                <div class="form-hint">北京 101010100 / 上海 101020100 / 广州 101280101</div>
              </div>
            ` : d`
              <div class="form-row">
                <label class="form-label">坐标</label>
                <div class="coords-grid">
                  <input type="text" class="form-input"
                    .value="${this.longitude}"
                    @input="${(s) => this.longitude = s.target.value}"
                    placeholder="经度">
                  <input type="text" class="form-input"
                    .value="${this.latitude}"
                    @input="${(s) => this.latitude = s.target.value}"
                    placeholder="纬度">
                </div>
                <button type="button" class="btn-locate"
                  @click="${this.detectLocation}"
                  ?disabled="${this.locating}">
                  ${this.iconTarget}
                  ${this.locating ? "定位中..." : "获取当前位置"}
                </button>
                ${this.locationStatus ? d`
                  <div class="location-status">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
                    ${this.locationStatus}
                  </div>
                ` : ""}
              </div>
            `}
          </div>

          <!-- 刷新设置 -->
          <div class="config-section">
            <div class="section-header">
              ${this.iconClock}
              <span class="section-title">刷新设置</span>
            </div>

            <div class="form-row">
              <label class="form-label">刷新间隔</label>
              <select class="form-input"
                .value="${String(this.refreshInterval)}"
                @change="${(s) => this.refreshInterval = Number(s.target.value)}">
                <option value="5">5 分钟</option>
                <option value="10">10 分钟</option>
                <option value="15">15 分钟</option>
                <option value="30">30 分钟</option>
                <option value="60">60 分钟</option>
              </select>
            </div>

            <div class="form-row">
              <label class="form-label">文字颜色</label>
              <div class="radio-group">
                <label class="radio-item ${this.textMode === "light" ? "active" : ""}" @click="${() => this.textMode = "light"}">
                  <input type="radio" name="textMode" value="light" .checked="${this.textMode === "light"}">
                  <span class="radio-dot"></span>
                  <span class="radio-label">浅色</span>
                </label>
                <label class="radio-item ${this.textMode === "dark" ? "active" : ""}" @click="${() => this.textMode = "dark"}">
                  <input type="radio" name="textMode" value="dark" .checked="${this.textMode === "dark"}">
                  <span class="radio-dot"></span>
                  <span class="radio-label">深色</span>
                </label>
              </div>
              <div class="form-hint">深色背景选浅色文字，浅色背景选深色文字</div>
            </div>
          </div>

          ${this.error ? d`
            <div class="error-msg">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              ${this.error}
            </div>
          ` : ""}
        </div>

        <div class="config-footer">
          <button type="button" class="btn-save"
            @click="${this.handleSaveOrCreateWidget}"
            ?disabled="${this.saving}">
            ${this.saving ? "保存中..." : this.getButtonTitle()}
          </button>
        </div>
      </div>
    `;
  }
}
st(ge, "properties", {
  widgetInfo: { type: Object },
  apiKey: { type: String },
  apiHost: { type: String },
  amapKey: { type: String },
  hasSavedApiKey: { type: Boolean },
  hasSavedApiHost: { type: Boolean },
  hasSavedAmapKey: { type: Boolean },
  showApiKey: { type: Boolean },
  showApiHost: { type: Boolean },
  showAmapKey: { type: Boolean },
  loadingApiKey: { type: Boolean },
  loadingApiHost: { type: Boolean },
  loadingAmapKey: { type: Boolean },
  locationMode: { type: String },
  location: { type: String },
  cityName: { type: String },
  longitude: { type: String },
  latitude: { type: String },
  refreshInterval: { type: Number },
  textMode: { type: String },
  saving: { type: Boolean },
  locating: { type: Boolean },
  error: { type: String },
  locationStatus: { type: String }
});
const Ft = {
  author: "Madrays",
  microAppId: "madrays-weather",
  version: "1.0.0",
  entry: "main.js",
  icon: "logo.png",
  appInfo: {
    "zh-CN": {
      appName: "天气",
      description: "基于和风天气API的天气小部件，支持实时天气、小时预报、多日预报",
      networkDescription: "用于调用和风天气API获取天气数据"
    },
    "en-US": {
      appName: "Weather",
      description: "Weather widget based on QWeather API, supports real-time weather, hourly and daily forecast",
      networkDescription: "Used to call QWeather API for weather data"
    }
  },
  permissions: ["network", "dataNode"],
  networkDomains: [
    "devapi.qweather.com",
    "api.qweather.com",
    "restapi.amap.com"
  ],
  dataNodes: {
    config: {
      scope: "app",
      isPublic: !0
    },
    settings: {
      scope: "app",
      isPublic: !0
    }
  }
}, Qe = {
  // 页面注册
  pages: {
    "weather-config": {
      component: ge,
      background: "rgba(255, 255, 255, 0.85)",
      headerTextColor: "#1f2937"
    }
  },
  // 小部件注册
  widgets: {
    "weather-widget": {
      component: pe,
      configComponentName: "weather-config",
      size: ["1x1", "1x2", "1xfull", "2x1", "2x2", "2x4"],
      background: "transparent",
      isModifyBackground: !0
    }
  }
}, ti = !1, ei = (o) => o.microAppId, pi = {
  appConfig: {
    ...Ft,
    microAppId: ei(Ft),
    dev: ti
  },
  components: Qe
};
export {
  pi as default
};
