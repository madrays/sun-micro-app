var ue = Object.defineProperty;
var fe = (o, t, e) => t in o ? ue(o, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : o[t] = e;
var rt = (o, t, e) => fe(o, typeof t != "symbol" ? t + "" : t, e);
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const J = globalThis, mt = J.ShadowRoot && (J.ShadyCSS === void 0 || J.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Qt = Symbol(), bt = /* @__PURE__ */ new WeakMap();
let ge = class {
  constructor(t, e, s) {
    if (this._$cssResult$ = !0, s !== Qt) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if (mt && t === void 0) {
      const s = e !== void 0 && e.length === 1;
      s && (t = bt.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), s && bt.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const $e = (o) => new ge(typeof o == "string" ? o : o + "", void 0, Qt), ve = (o, t) => {
  if (mt) o.adoptedStyleSheets = t.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet);
  else for (const e of t) {
    const s = document.createElement("style"), i = J.litNonce;
    i !== void 0 && s.setAttribute("nonce", i), s.textContent = e.cssText, o.appendChild(s);
  }
}, At = mt ? (o) => o : (o) => o instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const s of t.cssRules) e += s.cssText;
  return $e(e);
})(o) : o;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: me, defineProperty: ye, getOwnPropertyDescriptor: _e, getOwnPropertyNames: xe, getOwnPropertySymbols: we, getPrototypeOf: be } = Object, x = globalThis, St = x.trustedTypes, Ae = St ? St.emptyScript : "", nt = x.reactiveElementPolyfillSupport, L = (o, t) => o, ft = { toAttribute(o, t) {
  switch (t) {
    case Boolean:
      o = o ? Ae : null;
      break;
    case Object:
    case Array:
      o = o == null ? o : JSON.stringify(o);
  }
  return o;
}, fromAttribute(o, t) {
  let e = o;
  switch (t) {
    case Boolean:
      e = o !== null;
      break;
    case Number:
      e = o === null ? null : Number(o);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(o);
      } catch {
        e = null;
      }
  }
  return e;
} }, Zt = (o, t) => !me(o, t), Ct = { attribute: !0, type: String, converter: ft, reflect: !1, useDefault: !1, hasChanged: Zt };
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), x.litPropertyMetadata ?? (x.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let U = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ?? (this.l = [])).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = Ct) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const s = Symbol(), i = this.getPropertyDescriptor(t, s, e);
      i !== void 0 && ye(this.prototype, t, i);
    }
  }
  static getPropertyDescriptor(t, e, s) {
    const { get: i, set: r } = _e(this.prototype, t) ?? { get() {
      return this[e];
    }, set(n) {
      this[e] = n;
    } };
    return { get: i, set(n) {
      const l = i == null ? void 0 : i.call(this);
      r == null || r.call(this, n), this.requestUpdate(t, l, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? Ct;
  }
  static _$Ei() {
    if (this.hasOwnProperty(L("elementProperties"))) return;
    const t = be(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(L("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(L("properties"))) {
      const e = this.properties, s = [...xe(e), ...we(e)];
      for (const i of s) this.createProperty(i, e[i]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [s, i] of e) this.elementProperties.set(s, i);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, s] of this.elementProperties) {
      const i = this._$Eu(e, s);
      i !== void 0 && this._$Eh.set(i, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const s = new Set(t.flat(1 / 0).reverse());
      for (const i of s) e.unshift(At(i));
    } else t !== void 0 && e.push(At(t));
    return e;
  }
  static _$Eu(t, e) {
    const s = e.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var t;
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (t = this.constructor.l) == null || t.forEach((e) => e(this));
  }
  addController(t) {
    var e;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(t), this.renderRoot !== void 0 && this.isConnected && ((e = t.hostConnected) == null || e.call(t));
  }
  removeController(t) {
    var e;
    (e = this._$EO) == null || e.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const s of e.keys()) this.hasOwnProperty(s) && (t.set(s, this[s]), delete this[s]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return ve(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    var t;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (t = this._$EO) == null || t.forEach((e) => {
      var s;
      return (s = e.hostConnected) == null ? void 0 : s.call(e);
    });
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    var t;
    (t = this._$EO) == null || t.forEach((e) => {
      var s;
      return (s = e.hostDisconnected) == null ? void 0 : s.call(e);
    });
  }
  attributeChangedCallback(t, e, s) {
    this._$AK(t, s);
  }
  _$ET(t, e) {
    var r;
    const s = this.constructor.elementProperties.get(t), i = this.constructor._$Eu(t, s);
    if (i !== void 0 && s.reflect === !0) {
      const n = (((r = s.converter) == null ? void 0 : r.toAttribute) !== void 0 ? s.converter : ft).toAttribute(e, s.type);
      this._$Em = t, n == null ? this.removeAttribute(i) : this.setAttribute(i, n), this._$Em = null;
    }
  }
  _$AK(t, e) {
    var r, n;
    const s = this.constructor, i = s._$Eh.get(t);
    if (i !== void 0 && this._$Em !== i) {
      const l = s.getPropertyOptions(i), a = typeof l.converter == "function" ? { fromAttribute: l.converter } : ((r = l.converter) == null ? void 0 : r.fromAttribute) !== void 0 ? l.converter : ft;
      this._$Em = i;
      const h = a.fromAttribute(e, l.type);
      this[i] = h ?? ((n = this._$Ej) == null ? void 0 : n.get(i)) ?? h, this._$Em = null;
    }
  }
  requestUpdate(t, e, s, i = !1, r) {
    var n;
    if (t !== void 0) {
      const l = this.constructor;
      if (i === !1 && (r = this[t]), s ?? (s = l.getPropertyOptions(t)), !((s.hasChanged ?? Zt)(r, e) || s.useDefault && s.reflect && r === ((n = this._$Ej) == null ? void 0 : n.get(t)) && !this.hasAttribute(l._$Eu(t, s)))) return;
      this.C(t, e, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: s, reflect: i, wrapped: r }, n) {
    s && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(t) && (this._$Ej.set(t, n ?? e ?? this[t]), r !== !0 || n !== void 0) || (this._$AL.has(t) || (this.hasUpdated || s || (e = void 0), this._$AL.set(t, e)), i === !0 && this._$Em !== t && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var s;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [r, n] of this._$Ep) this[r] = n;
        this._$Ep = void 0;
      }
      const i = this.constructor.elementProperties;
      if (i.size > 0) for (const [r, n] of i) {
        const { wrapped: l } = n, a = this[r];
        l !== !0 || this._$AL.has(r) || a === void 0 || this.C(r, void 0, n, a);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), (s = this._$EO) == null || s.forEach((i) => {
        var r;
        return (r = i.hostUpdate) == null ? void 0 : r.call(i);
      }), this.update(e)) : this._$EM();
    } catch (i) {
      throw t = !1, this._$EM(), i;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    var e;
    (e = this._$EO) == null || e.forEach((s) => {
      var i;
      return (i = s.hostUpdated) == null ? void 0 : i.call(s);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((e) => this._$ET(e, this[e]))), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
U.elementStyles = [], U.shadowRootOptions = { mode: "open" }, U[L("elementProperties")] = /* @__PURE__ */ new Map(), U[L("finalized")] = /* @__PURE__ */ new Map(), nt == null || nt({ ReactiveElement: U }), (x.reactiveElementVersions ?? (x.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const j = globalThis, Et = (o) => o, et = j.trustedTypes, kt = et ? et.createPolicy("lit-html", { createHTML: (o) => o }) : void 0, Gt = "$lit$", y = `lit$${Math.random().toFixed(9).slice(2)}$`, Jt = "?" + y, Se = `<${Jt}>`, M = document, q = () => M.createComment(""), W = (o) => o === null || typeof o != "object" && typeof o != "function", yt = Array.isArray, Ce = (o) => yt(o) || typeof (o == null ? void 0 : o[Symbol.iterator]) == "function", at = `[ 	
\f\r]`, T = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Mt = /-->/g, Pt = />/g, b = RegExp(`>|${at}(?:([^\\s"'>=/]+)(${at}*=${at}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Ut = /'/g, zt = /"/g, Xt = /^(?:script|style|textarea|title)$/i, Ee = (o) => (t, ...e) => ({ _$litType$: o, strings: t, values: e }), f = Ee(1), B = Symbol.for("lit-noChange"), g = Symbol.for("lit-nothing"), Bt = /* @__PURE__ */ new WeakMap(), S = M.createTreeWalker(M, 129);
function Yt(o, t) {
  if (!yt(o) || !o.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return kt !== void 0 ? kt.createHTML(t) : t;
}
const ke = (o, t) => {
  const e = o.length - 1, s = [];
  let i, r = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", n = T;
  for (let l = 0; l < e; l++) {
    const a = o[l];
    let h, c, d = -1, p = 0;
    for (; p < a.length && (n.lastIndex = p, c = n.exec(a), c !== null); ) p = n.lastIndex, n === T ? c[1] === "!--" ? n = Mt : c[1] !== void 0 ? n = Pt : c[2] !== void 0 ? (Xt.test(c[2]) && (i = RegExp("</" + c[2], "g")), n = b) : c[3] !== void 0 && (n = b) : n === b ? c[0] === ">" ? (n = i ?? T, d = -1) : c[1] === void 0 ? d = -2 : (d = n.lastIndex - c[2].length, h = c[1], n = c[3] === void 0 ? b : c[3] === '"' ? zt : Ut) : n === zt || n === Ut ? n = b : n === Mt || n === Pt ? n = T : (n = b, i = void 0);
    const u = n === b && o[l + 1].startsWith("/>") ? " " : "";
    r += n === T ? a + Se : d >= 0 ? (s.push(h), a.slice(0, d) + Gt + a.slice(d) + y + u) : a + y + (d === -2 ? l : u);
  }
  return [Yt(o, r + (o[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), s];
};
let gt = class te {
  constructor({ strings: t, _$litType$: e }, s) {
    let i;
    this.parts = [];
    let r = 0, n = 0;
    const l = t.length - 1, a = this.parts, [h, c] = ke(t, e);
    if (this.el = te.createElement(h, s), S.currentNode = this.el.content, e === 2 || e === 3) {
      const d = this.el.content.firstChild;
      d.replaceWith(...d.childNodes);
    }
    for (; (i = S.nextNode()) !== null && a.length < l; ) {
      if (i.nodeType === 1) {
        if (i.hasAttributes()) for (const d of i.getAttributeNames()) if (d.endsWith(Gt)) {
          const p = c[n++], u = i.getAttribute(d).split(y), v = /([.?@])?(.*)/.exec(p);
          a.push({ type: 1, index: r, name: v[2], strings: u, ctor: v[1] === "." ? Pe : v[1] === "?" ? Ue : v[1] === "@" ? ze : it }), i.removeAttribute(d);
        } else d.startsWith(y) && (a.push({ type: 6, index: r }), i.removeAttribute(d));
        if (Xt.test(i.tagName)) {
          const d = i.textContent.split(y), p = d.length - 1;
          if (p > 0) {
            i.textContent = et ? et.emptyScript : "";
            for (let u = 0; u < p; u++) i.append(d[u], q()), S.nextNode(), a.push({ type: 2, index: ++r });
            i.append(d[p], q());
          }
        }
      } else if (i.nodeType === 8) if (i.data === Jt) a.push({ type: 2, index: r });
      else {
        let d = -1;
        for (; (d = i.data.indexOf(y, d + 1)) !== -1; ) a.push({ type: 7, index: r }), d += y.length - 1;
      }
      r++;
    }
  }
  static createElement(t, e) {
    const s = M.createElement("template");
    return s.innerHTML = t, s;
  }
};
function H(o, t, e = o, s) {
  var n, l;
  if (t === B) return t;
  let i = s !== void 0 ? (n = e._$Co) == null ? void 0 : n[s] : e._$Cl;
  const r = W(t) ? void 0 : t._$litDirective$;
  return (i == null ? void 0 : i.constructor) !== r && ((l = i == null ? void 0 : i._$AO) == null || l.call(i, !1), r === void 0 ? i = void 0 : (i = new r(o), i._$AT(o, e, s)), s !== void 0 ? (e._$Co ?? (e._$Co = []))[s] = i : e._$Cl = i), i !== void 0 && (t = H(o, i._$AS(o, t.values), i, s)), t;
}
let Me = class {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: s } = this._$AD, i = ((t == null ? void 0 : t.creationScope) ?? M).importNode(e, !0);
    S.currentNode = i;
    let r = S.nextNode(), n = 0, l = 0, a = s[0];
    for (; a !== void 0; ) {
      if (n === a.index) {
        let h;
        a.type === 2 ? h = new _t(r, r.nextSibling, this, t) : a.type === 1 ? h = new a.ctor(r, a.name, a.strings, this, t) : a.type === 6 && (h = new Be(r, this, t)), this._$AV.push(h), a = s[++l];
      }
      n !== (a == null ? void 0 : a.index) && (r = S.nextNode(), n++);
    }
    return S.currentNode = M, i;
  }
  p(t) {
    let e = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(t, s, e), e += s.strings.length - 2) : s._$AI(t[e])), e++;
  }
}, _t = class ee {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, e, s, i) {
    this.type = 2, this._$AH = g, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = s, this.options = i, this._$Cv = (i == null ? void 0 : i.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = H(this, t, e), W(t) ? t === g || t == null || t === "" ? (this._$AH !== g && this._$AR(), this._$AH = g) : t !== this._$AH && t !== B && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Ce(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== g && W(this._$AH) ? this._$AA.nextSibling.data = t : this.T(M.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var r;
    const { values: e, _$litType$: s } = t, i = typeof s == "number" ? this._$AC(t) : (s.el === void 0 && (s.el = gt.createElement(Yt(s.h, s.h[0]), this.options)), s);
    if (((r = this._$AH) == null ? void 0 : r._$AD) === i) this._$AH.p(e);
    else {
      const n = new Me(i, this), l = n.u(this.options);
      n.p(e), this.T(l), this._$AH = n;
    }
  }
  _$AC(t) {
    let e = Bt.get(t.strings);
    return e === void 0 && Bt.set(t.strings, e = new gt(t)), e;
  }
  k(t) {
    yt(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let s, i = 0;
    for (const r of t) i === e.length ? e.push(s = new ee(this.O(q()), this.O(q()), this, this.options)) : s = e[i], s._$AI(r), i++;
    i < e.length && (this._$AR(s && s._$AB.nextSibling, i), e.length = i);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    var s;
    for ((s = this._$AP) == null ? void 0 : s.call(this, !1, !0, e); t !== this._$AB; ) {
      const i = Et(t).nextSibling;
      Et(t).remove(), t = i;
    }
  }
  setConnected(t) {
    var e;
    this._$AM === void 0 && (this._$Cv = t, (e = this._$AP) == null || e.call(this, t));
  }
}, it = class {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, s, i, r) {
    this.type = 1, this._$AH = g, this._$AN = void 0, this.element = t, this.name = e, this._$AM = i, this.options = r, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = g;
  }
  _$AI(t, e = this, s, i) {
    const r = this.strings;
    let n = !1;
    if (r === void 0) t = H(this, t, e, 0), n = !W(t) || t !== this._$AH && t !== B, n && (this._$AH = t);
    else {
      const l = t;
      let a, h;
      for (t = r[0], a = 0; a < r.length - 1; a++) h = H(this, l[s + a], e, a), h === B && (h = this._$AH[a]), n || (n = !W(h) || h !== this._$AH[a]), h === g ? t = g : t !== g && (t += (h ?? "") + r[a + 1]), this._$AH[a] = h;
    }
    n && !i && this.j(t);
  }
  j(t) {
    t === g ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}, Pe = class extends it {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === g ? void 0 : t;
  }
}, Ue = class extends it {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== g);
  }
}, ze = class extends it {
  constructor(t, e, s, i, r) {
    super(t, e, s, i, r), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = H(this, t, e, 0) ?? g) === B) return;
    const s = this._$AH, i = t === g && s !== g || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, r = t !== g && (s === g || i);
    i && this.element.removeEventListener(this.name, this, s), r && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var e;
    typeof this._$AH == "function" ? this._$AH.call(((e = this.options) == null ? void 0 : e.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}, Be = class {
  constructor(t, e, s) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    H(this, t);
  }
};
const lt = j.litHtmlPolyfillSupport;
lt == null || lt(gt, _t), (j.litHtmlVersions ?? (j.litHtmlVersions = [])).push("3.3.2");
const He = (o, t, e) => {
  const s = (e == null ? void 0 : e.renderBefore) ?? t;
  let i = s._$litPart$;
  if (i === void 0) {
    const r = (e == null ? void 0 : e.renderBefore) ?? null;
    s._$litPart$ = i = new _t(t.insertBefore(q(), r), r, void 0, e ?? {});
  }
  return i._$AI(o), i;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const E = globalThis;
let X = class extends U {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = He(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return B;
  }
};
var Ft;
X._$litElement$ = !0, X.finalized = !0, (Ft = E.litElementHydrateSupport) == null || Ft.call(E, { LitElement: X });
const dt = E.litElementPolyfillSupport;
dt == null || dt({ LitElement: X });
(E.litElementVersions ?? (E.litElementVersions = [])).push("4.2.2");
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Y = globalThis, xt = Y.ShadowRoot && (Y.ShadyCSS === void 0 || Y.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, se = Symbol(), Ht = /* @__PURE__ */ new WeakMap();
let Ne = class {
  constructor(o, t, e) {
    if (this._$cssResult$ = !0, e !== se) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = o, this.t = t;
  }
  get styleSheet() {
    let o = this.o;
    const t = this.t;
    if (xt && o === void 0) {
      const e = t !== void 0 && t.length === 1;
      e && (o = Ht.get(t)), o === void 0 && ((this.o = o = new CSSStyleSheet()).replaceSync(this.cssText), e && Ht.set(t, o));
    }
    return o;
  }
  toString() {
    return this.cssText;
  }
};
const Nt = xt ? (o) => o : (o) => o instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const s of t.cssRules) e += s.cssText;
  return ((s) => new Ne(typeof s == "string" ? s : s + "", void 0, se))(e);
})(o) : o, { is: Oe, defineProperty: Te, getOwnPropertyDescriptor: Re, getOwnPropertyNames: Le, getOwnPropertySymbols: je, getPrototypeOf: Ie } = Object, w = globalThis, Ot = w.trustedTypes, De = Ot ? Ot.emptyScript : "", ht = w.reactiveElementPolyfillSupport, I = (o, t) => o, $t = { toAttribute(o, t) {
  switch (t) {
    case Boolean:
      o = o ? De : null;
      break;
    case Object:
    case Array:
      o = o == null ? o : JSON.stringify(o);
  }
  return o;
}, fromAttribute(o, t) {
  let e = o;
  switch (t) {
    case Boolean:
      e = o !== null;
      break;
    case Number:
      e = o === null ? null : Number(o);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(o);
      } catch {
        e = null;
      }
  }
  return e;
} }, ie = (o, t) => !Oe(o, t), Tt = { attribute: !0, type: String, converter: $t, reflect: !1, useDefault: !1, hasChanged: ie };
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), w.litPropertyMetadata ?? (w.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let z = class extends HTMLElement {
  static addInitializer(o) {
    this._$Ei(), (this.l ?? (this.l = [])).push(o);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(o, t = Tt) {
    if (t.state && (t.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(o) && ((t = Object.create(t)).wrapped = !0), this.elementProperties.set(o, t), !t.noAccessor) {
      const e = Symbol(), s = this.getPropertyDescriptor(o, e, t);
      s !== void 0 && Te(this.prototype, o, s);
    }
  }
  static getPropertyDescriptor(o, t, e) {
    const { get: s, set: i } = Re(this.prototype, o) ?? { get() {
      return this[t];
    }, set(r) {
      this[t] = r;
    } };
    return { get: s, set(r) {
      const n = s == null ? void 0 : s.call(this);
      i == null || i.call(this, r), this.requestUpdate(o, n, e);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(o) {
    return this.elementProperties.get(o) ?? Tt;
  }
  static _$Ei() {
    if (this.hasOwnProperty(I("elementProperties"))) return;
    const o = Ie(this);
    o.finalize(), o.l !== void 0 && (this.l = [...o.l]), this.elementProperties = new Map(o.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(I("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(I("properties"))) {
      const t = this.properties, e = [...Le(t), ...je(t)];
      for (const s of e) this.createProperty(s, t[s]);
    }
    const o = this[Symbol.metadata];
    if (o !== null) {
      const t = litPropertyMetadata.get(o);
      if (t !== void 0) for (const [e, s] of t) this.elementProperties.set(e, s);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [t, e] of this.elementProperties) {
      const s = this._$Eu(t, e);
      s !== void 0 && this._$Eh.set(s, t);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(o) {
    const t = [];
    if (Array.isArray(o)) {
      const e = new Set(o.flat(1 / 0).reverse());
      for (const s of e) t.unshift(Nt(s));
    } else o !== void 0 && t.push(Nt(o));
    return t;
  }
  static _$Eu(o, t) {
    const e = t.attribute;
    return e === !1 ? void 0 : typeof e == "string" ? e : typeof o == "string" ? o.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var o;
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (o = this.constructor.l) == null || o.forEach((t) => t(this));
  }
  addController(o) {
    var t;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(o), this.renderRoot !== void 0 && this.isConnected && ((t = o.hostConnected) == null || t.call(o));
  }
  removeController(o) {
    var t;
    (t = this._$EO) == null || t.delete(o);
  }
  _$E_() {
    const o = /* @__PURE__ */ new Map(), t = this.constructor.elementProperties;
    for (const e of t.keys()) this.hasOwnProperty(e) && (o.set(e, this[e]), delete this[e]);
    o.size > 0 && (this._$Ep = o);
  }
  createRenderRoot() {
    const o = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return ((t, e) => {
      if (xt) t.adoptedStyleSheets = e.map((s) => s instanceof CSSStyleSheet ? s : s.styleSheet);
      else for (const s of e) {
        const i = document.createElement("style"), r = Y.litNonce;
        r !== void 0 && i.setAttribute("nonce", r), i.textContent = s.cssText, t.appendChild(i);
      }
    })(o, this.constructor.elementStyles), o;
  }
  connectedCallback() {
    var o;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (o = this._$EO) == null || o.forEach((t) => {
      var e;
      return (e = t.hostConnected) == null ? void 0 : e.call(t);
    });
  }
  enableUpdating(o) {
  }
  disconnectedCallback() {
    var o;
    (o = this._$EO) == null || o.forEach((t) => {
      var e;
      return (e = t.hostDisconnected) == null ? void 0 : e.call(t);
    });
  }
  attributeChangedCallback(o, t, e) {
    this._$AK(o, e);
  }
  _$ET(o, t) {
    var i;
    const e = this.constructor.elementProperties.get(o), s = this.constructor._$Eu(o, e);
    if (s !== void 0 && e.reflect === !0) {
      const r = (((i = e.converter) == null ? void 0 : i.toAttribute) !== void 0 ? e.converter : $t).toAttribute(t, e.type);
      this._$Em = o, r == null ? this.removeAttribute(s) : this.setAttribute(s, r), this._$Em = null;
    }
  }
  _$AK(o, t) {
    var i, r;
    const e = this.constructor, s = e._$Eh.get(o);
    if (s !== void 0 && this._$Em !== s) {
      const n = e.getPropertyOptions(s), l = typeof n.converter == "function" ? { fromAttribute: n.converter } : ((i = n.converter) == null ? void 0 : i.fromAttribute) !== void 0 ? n.converter : $t;
      this._$Em = s;
      const a = l.fromAttribute(t, n.type);
      this[s] = a ?? ((r = this._$Ej) == null ? void 0 : r.get(s)) ?? a, this._$Em = null;
    }
  }
  requestUpdate(o, t, e, s = !1, i) {
    var r;
    if (o !== void 0) {
      const n = this.constructor;
      if (s === !1 && (i = this[o]), e ?? (e = n.getPropertyOptions(o)), !((e.hasChanged ?? ie)(i, t) || e.useDefault && e.reflect && i === ((r = this._$Ej) == null ? void 0 : r.get(o)) && !this.hasAttribute(n._$Eu(o, e)))) return;
      this.C(o, t, e);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(o, t, { useDefault: e, reflect: s, wrapped: i }, r) {
    e && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(o) && (this._$Ej.set(o, r ?? t ?? this[o]), i !== !0 || r !== void 0) || (this._$AL.has(o) || (this.hasUpdated || e || (t = void 0), this._$AL.set(o, t)), s === !0 && this._$Em !== o && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(o));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (t) {
      Promise.reject(t);
    }
    const o = this.scheduleUpdate();
    return o != null && await o, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var e;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [i, r] of this._$Ep) this[i] = r;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [i, r] of s) {
        const { wrapped: n } = r, l = this[i];
        n !== !0 || this._$AL.has(i) || l === void 0 || this.C(i, void 0, r, l);
      }
    }
    let o = !1;
    const t = this._$AL;
    try {
      o = this.shouldUpdate(t), o ? (this.willUpdate(t), (e = this._$EO) == null || e.forEach((s) => {
        var i;
        return (i = s.hostUpdate) == null ? void 0 : i.call(s);
      }), this.update(t)) : this._$EM();
    } catch (s) {
      throw o = !1, this._$EM(), s;
    }
    o && this._$AE(t);
  }
  willUpdate(o) {
  }
  _$AE(o) {
    var t;
    (t = this._$EO) == null || t.forEach((e) => {
      var s;
      return (s = e.hostUpdated) == null ? void 0 : s.call(e);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(o)), this.updated(o);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(o) {
    return !0;
  }
  update(o) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((t) => this._$ET(t, this[t]))), this._$EM();
  }
  updated(o) {
  }
  firstUpdated(o) {
  }
};
z.elementStyles = [], z.shadowRootOptions = { mode: "open" }, z[I("elementProperties")] = /* @__PURE__ */ new Map(), z[I("finalized")] = /* @__PURE__ */ new Map(), ht == null || ht({ ReactiveElement: z }), (w.reactiveElementVersions ?? (w.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const D = globalThis, Rt = (o) => o, st = D.trustedTypes, Lt = st ? st.createPolicy("lit-html", { createHTML: (o) => o }) : void 0, oe = "$lit$", _ = `lit$${Math.random().toFixed(9).slice(2)}$`, re = "?" + _, Ve = `<${re}>`, P = document, F = () => P.createComment(""), K = (o) => o === null || typeof o != "object" && typeof o != "function", vt = Array.isArray, ct = `[ 	
\f\r]`, R = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, jt = /-->/g, It = />/g, A = RegExp(`>|${ct}(?:([^\\s"'>=/]+)(${ct}*=${ct}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Dt = /'/g, Vt = /"/g, ne = /^(?:script|style|textarea|title)$/i, wt = /* @__PURE__ */ ((o) => (t, ...e) => ({ _$litType$: o, strings: t, values: e }))(1), N = Symbol.for("lit-noChange"), $ = Symbol.for("lit-nothing"), qt = /* @__PURE__ */ new WeakMap(), C = P.createTreeWalker(P, 129);
function ae(o, t) {
  if (!vt(o) || !o.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Lt !== void 0 ? Lt.createHTML(t) : t;
}
const qe = (o, t) => {
  const e = o.length - 1, s = [];
  let i, r = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", n = R;
  for (let l = 0; l < e; l++) {
    const a = o[l];
    let h, c, d = -1, p = 0;
    for (; p < a.length && (n.lastIndex = p, c = n.exec(a), c !== null); ) p = n.lastIndex, n === R ? c[1] === "!--" ? n = jt : c[1] !== void 0 ? n = It : c[2] !== void 0 ? (ne.test(c[2]) && (i = RegExp("</" + c[2], "g")), n = A) : c[3] !== void 0 && (n = A) : n === A ? c[0] === ">" ? (n = i ?? R, d = -1) : c[1] === void 0 ? d = -2 : (d = n.lastIndex - c[2].length, h = c[1], n = c[3] === void 0 ? A : c[3] === '"' ? Vt : Dt) : n === Vt || n === Dt ? n = A : n === jt || n === It ? n = R : (n = A, i = void 0);
    const u = n === A && o[l + 1].startsWith("/>") ? " " : "";
    r += n === R ? a + Ve : d >= 0 ? (s.push(h), a.slice(0, d) + oe + a.slice(d) + _ + u) : a + _ + (d === -2 ? l : u);
  }
  return [ae(o, r + (o[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), s];
};
class Q {
  constructor({ strings: t, _$litType$: e }, s) {
    let i;
    this.parts = [];
    let r = 0, n = 0;
    const l = t.length - 1, a = this.parts, [h, c] = qe(t, e);
    if (this.el = Q.createElement(h, s), C.currentNode = this.el.content, e === 2 || e === 3) {
      const d = this.el.content.firstChild;
      d.replaceWith(...d.childNodes);
    }
    for (; (i = C.nextNode()) !== null && a.length < l; ) {
      if (i.nodeType === 1) {
        if (i.hasAttributes()) for (const d of i.getAttributeNames()) if (d.endsWith(oe)) {
          const p = c[n++], u = i.getAttribute(d).split(_), v = /([.?@])?(.*)/.exec(p);
          a.push({ type: 1, index: r, name: v[2], strings: u, ctor: v[1] === "." ? Fe : v[1] === "?" ? Ke : v[1] === "@" ? Qe : ot }), i.removeAttribute(d);
        } else d.startsWith(_) && (a.push({ type: 6, index: r }), i.removeAttribute(d));
        if (ne.test(i.tagName)) {
          const d = i.textContent.split(_), p = d.length - 1;
          if (p > 0) {
            i.textContent = st ? st.emptyScript : "";
            for (let u = 0; u < p; u++) i.append(d[u], F()), C.nextNode(), a.push({ type: 2, index: ++r });
            i.append(d[p], F());
          }
        }
      } else if (i.nodeType === 8) if (i.data === re) a.push({ type: 2, index: r });
      else {
        let d = -1;
        for (; (d = i.data.indexOf(_, d + 1)) !== -1; ) a.push({ type: 7, index: r }), d += _.length - 1;
      }
      r++;
    }
  }
  static createElement(t, e) {
    const s = P.createElement("template");
    return s.innerHTML = t, s;
  }
}
function O(o, t, e = o, s) {
  var n, l;
  if (t === N) return t;
  let i = s !== void 0 ? (n = e._$Co) == null ? void 0 : n[s] : e._$Cl;
  const r = K(t) ? void 0 : t._$litDirective$;
  return (i == null ? void 0 : i.constructor) !== r && ((l = i == null ? void 0 : i._$AO) == null || l.call(i, !1), r === void 0 ? i = void 0 : (i = new r(o), i._$AT(o, e, s)), s !== void 0 ? (e._$Co ?? (e._$Co = []))[s] = i : e._$Cl = i), i !== void 0 && (t = O(o, i._$AS(o, t.values), i, s)), t;
}
class We {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: s } = this._$AD, i = ((t == null ? void 0 : t.creationScope) ?? P).importNode(e, !0);
    C.currentNode = i;
    let r = C.nextNode(), n = 0, l = 0, a = s[0];
    for (; a !== void 0; ) {
      if (n === a.index) {
        let h;
        a.type === 2 ? h = new Z(r, r.nextSibling, this, t) : a.type === 1 ? h = new a.ctor(r, a.name, a.strings, this, t) : a.type === 6 && (h = new Ze(r, this, t)), this._$AV.push(h), a = s[++l];
      }
      n !== (a == null ? void 0 : a.index) && (r = C.nextNode(), n++);
    }
    return C.currentNode = P, i;
  }
  p(t) {
    let e = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(t, s, e), e += s.strings.length - 2) : s._$AI(t[e])), e++;
  }
}
class Z {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, e, s, i) {
    this.type = 2, this._$AH = $, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = s, this.options = i, this._$Cv = (i == null ? void 0 : i.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = O(this, t, e), K(t) ? t === $ || t == null || t === "" ? (this._$AH !== $ && this._$AR(), this._$AH = $) : t !== this._$AH && t !== N && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : ((s) => vt(s) || typeof (s == null ? void 0 : s[Symbol.iterator]) == "function")(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== $ && K(this._$AH) ? this._$AA.nextSibling.data = t : this.T(P.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var r;
    const { values: e, _$litType$: s } = t, i = typeof s == "number" ? this._$AC(t) : (s.el === void 0 && (s.el = Q.createElement(ae(s.h, s.h[0]), this.options)), s);
    if (((r = this._$AH) == null ? void 0 : r._$AD) === i) this._$AH.p(e);
    else {
      const n = new We(i, this), l = n.u(this.options);
      n.p(e), this.T(l), this._$AH = n;
    }
  }
  _$AC(t) {
    let e = qt.get(t.strings);
    return e === void 0 && qt.set(t.strings, e = new Q(t)), e;
  }
  k(t) {
    vt(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let s, i = 0;
    for (const r of t) i === e.length ? e.push(s = new Z(this.O(F()), this.O(F()), this, this.options)) : s = e[i], s._$AI(r), i++;
    i < e.length && (this._$AR(s && s._$AB.nextSibling, i), e.length = i);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    var s;
    for ((s = this._$AP) == null ? void 0 : s.call(this, !1, !0, e); t !== this._$AB; ) {
      const i = Rt(t).nextSibling;
      Rt(t).remove(), t = i;
    }
  }
  setConnected(t) {
    var e;
    this._$AM === void 0 && (this._$Cv = t, (e = this._$AP) == null || e.call(this, t));
  }
}
class ot {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, s, i, r) {
    this.type = 1, this._$AH = $, this._$AN = void 0, this.element = t, this.name = e, this._$AM = i, this.options = r, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = $;
  }
  _$AI(t, e = this, s, i) {
    const r = this.strings;
    let n = !1;
    if (r === void 0) t = O(this, t, e, 0), n = !K(t) || t !== this._$AH && t !== N, n && (this._$AH = t);
    else {
      const l = t;
      let a, h;
      for (t = r[0], a = 0; a < r.length - 1; a++) h = O(this, l[s + a], e, a), h === N && (h = this._$AH[a]), n || (n = !K(h) || h !== this._$AH[a]), h === $ ? t = $ : t !== $ && (t += (h ?? "") + r[a + 1]), this._$AH[a] = h;
    }
    n && !i && this.j(t);
  }
  j(t) {
    t === $ ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Fe extends ot {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === $ ? void 0 : t;
  }
}
class Ke extends ot {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== $);
  }
}
class Qe extends ot {
  constructor(t, e, s, i, r) {
    super(t, e, s, i, r), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = O(this, t, e, 0) ?? $) === N) return;
    const s = this._$AH, i = t === $ && s !== $ || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, r = t !== $ && (s === $ || i);
    i && this.element.removeEventListener(this.name, this, s), r && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var e;
    typeof this._$AH == "function" ? this._$AH.call(((e = this.options) == null ? void 0 : e.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class Ze {
  constructor(t, e, s) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    O(this, t);
  }
}
const pt = D.litHtmlPolyfillSupport;
pt == null || pt(Q, Z), (D.litHtmlVersions ?? (D.litHtmlVersions = [])).push("3.3.2");
const k = globalThis;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class V extends z {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = ((s, i, r) => {
      const n = (r == null ? void 0 : r.renderBefore) ?? i;
      let l = n._$litPart$;
      if (l === void 0) {
        const a = (r == null ? void 0 : r.renderBefore) ?? null;
        n._$litPart$ = l = new Z(i.insertBefore(F(), a), a, void 0, r ?? {});
      }
      return l._$AI(s), l;
    })(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return N;
  }
}
var Kt;
V._$litElement$ = !0, V.finalized = !0, (Kt = k.litElementHydrateSupport) == null || Kt.call(k, { LitElement: V });
const ut = k.litElementPolyfillSupport;
ut == null || ut({ LitElement: V }), (k.litElementVersions ?? (k.litElementVersions = [])).push("4.2.2");
class le extends V {
  constructor() {
    super(), this._initialized = !1, this._eventListeners = /* @__PURE__ */ new Map();
  }
  initializeMicroApp() {
    this._initialized || (this._setupEventListeners(), this._initialized = !0);
  }
  connectedCallback() {
    super.connectedCallback(), this.initializeMicroApp(), this.onConnected();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupEventListeners(), this.onDisconnected();
  }
  attributeChangedCallback(t, e, s) {
    super.attributeChangedCallback(t, e, s), this.onAttributeChanged(t, e, s);
  }
  _setupEventListeners() {
  }
  _cleanupEventListeners() {
    const t = Array.from(this._eventListeners.entries());
    for (const [e, s] of t) s.forEach((i) => {
      window.removeEventListener(e, i);
    });
    this._eventListeners.clear();
  }
  addEventListener(t, e, s) {
    super.addEventListener(t, e, s);
  }
  dispatchCustomEvent(t, e) {
    const s = new CustomEvent(t, { bubbles: !0, composed: !0, detail: e });
    this.dispatchEvent(s);
  }
  onConnected() {
  }
  onDisconnected() {
  }
  onAttributeChanged(t, e, s) {
  }
  render() {
    return wt``;
  }
}
class de extends le {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, widgetInfo: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([s, i]) => i !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    var e;
    (e = super.firstUpdated) == null || e.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, s = this.spCtx;
      s.widgetInfo !== e.widgetInfo && this.onWidgetInfoChanged(s.widgetInfo, e.widgetInfo), s.darkMode !== e.darkMode && this.onDarkModeChanged(s.darkMode, e.darkMode), s.language !== e.language && this.onLanguageChanged(s.language, e.language), s.networkMode !== e.networkMode && this.onNetworkModeChanged(s.networkMode, e.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized();
  }
  onInitialized() {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
  }
  onNetworkModeChanged(t, e) {
  }
  onWidgetInfoChanged(t, e) {
  }
  render() {
    return wt``;
  }
}
de.properties = { spCtx: { type: Object, attribute: !1 } };
class he extends le {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, background: "", widgetInfo: {}, customParam: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([s, i]) => i !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    var e;
    (e = super.firstUpdated) == null || e.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, s = this.spCtx;
      s.darkMode !== e.darkMode && this.onDarkModeChanged(s.darkMode, e.darkMode), s.language !== e.language && this.onLanguageChanged(s.language, e.language), s.networkMode !== e.networkMode && this.onNetworkModeChanged(s.networkMode, e.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized({ widgetInfo: this.spCtx.widgetInfo, customParam: this.spCtx.customParam });
  }
  onInitialized(t) {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
  }
  onNetworkModeChanged(t, e) {
  }
  render() {
    return wt``;
  }
}
he.properties = { spCtx: { type: Object, attribute: !1 } };
function tt(o, t = 1) {
  if (!o || o === 0) return "0 B";
  const e = 1024, s = ["B", "KB", "MB", "GB", "TB"], i = Math.floor(Math.log(o) / Math.log(e));
  return parseFloat((o / Math.pow(e, i)).toFixed(t)) + " " + s[i];
}
function m(o) {
  return !o || o === 0 ? "0 B/s" : tt(o) + "/s";
}
function Wt(o) {
  return o == null || o < 0 ? "∞" : o.toFixed(2);
}
function G(o) {
  const t = {
    total: 0,
    downloading: 0,
    seeding: 0,
    paused: 0,
    completed: 0,
    error: 0,
    active: 0,
    totalSize: 0,
    ratioSum: 0
  };
  return o && Object.values(o).forEach((e) => {
    t.total++, t.totalSize += e.size || 0, t.ratioSum += e.ratio || 0;
    const s = e.state || "";
    s.includes("error") || s === "missingFiles" ? t.error++ : s.includes("paused") || s === "pausedDL" || s === "pausedUP" ? t.paused++ : s === "uploading" || s === "stalledUP" || s === "forcedUP" || s === "queuedUP" ? t.seeding++ : (s === "downloading" || s === "stalledDL" || s === "forcedDL" || s === "queuedDL" || s === "metaDL") && t.downloading++, e.progress >= 1 && t.completed++, (s === "downloading" || s === "uploading") && t.active++;
  }), t;
}
const Ge = {
  download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
  upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
  dlLimit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22V8"/><path d="m5 15 7 7 7-7"/><line x1="4" y1="4" x2="20" y2="4"/></svg>',
  upLimit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v14"/><path d="m5 9 7-7 7 7"/><line x1="4" y1="20" x2="20" y2="20"/></svg>',
  totalDl: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/><path d="m8 10 4 4 4-4"/></svg>',
  totalUp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/><path d="m8 10 4-4 4 4"/></svg>',
  ratio: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>',
  disk: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',
  size: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>',
  io: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
  total: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
  active: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
  seed: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22c4-4 8-7.5 8-12a8 8 0 1 0-16 0c0 4.5 4 8 8 12z"/><circle cx="12" cy="10" r="3"/></svg>',
  pause: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
  error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
  fire: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>'
};
class ce extends de {
  constructor() {
    super(), this.data = null, this.torrents = {}, this.loading = !0, this.error = "", this.config = {}, this._timer = null, this._rid = 0;
  }
  async onInitialized() {
    var t;
    this.config = ((t = this.spCtx.widgetInfo) == null ? void 0 : t.config) || {}, await this.fetchData(), this.startRefresh();
  }
  onWidgetInfoChanged(t) {
    const e = t == null ? void 0 : t.config;
    e && JSON.stringify(e) !== JSON.stringify(this.config) && (this.config = e, this.startRefresh()), this.requestUpdate();
  }
  startRefresh() {
    var e;
    this._timer && clearInterval(this._timer);
    const t = (((e = this.config) == null ? void 0 : e.refreshInterval) || 5) * 1e3;
    this._timer = setInterval(() => this.fetchData(), t);
  }
  onDisconnected() {
    this._timer && clearInterval(this._timer);
  }
  async login() {
    try {
      return await this.spCtx.api.network.request({
        targetUrl: "{{host}}/api/v2/auth/login",
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "username={{username}}&password={{password}}",
        templateReplacements: [
          { placeholder: "{{host}}", fields: ["targetUrl"], dataNode: "config.host" },
          { placeholder: "{{username}}", fields: ["body"], dataNode: "config.username" },
          { placeholder: "{{password}}", fields: ["body"], dataNode: "config.password" }
        ]
      }), !0;
    } catch {
      return !1;
    }
  }
  async fetchData() {
    try {
      let t = await this.spCtx.api.network.request({
        targetUrl: `{{host}}/api/v2/sync/maindata?rid=${this._rid}`,
        method: "GET",
        templateReplacements: [{ placeholder: "{{host}}", fields: ["targetUrl"], dataNode: "config.host" }]
      });
      ((t == null ? void 0 : t.status) === 403 || (t == null ? void 0 : t.data) === "Forbidden") && (await this.login(), t = await this.spCtx.api.network.request({
        targetUrl: `{{host}}/api/v2/sync/maindata?rid=${this._rid}`,
        method: "GET",
        templateReplacements: [{ placeholder: "{{host}}", fields: ["targetUrl"], dataNode: "config.host" }]
      }));
      const e = (t == null ? void 0 : t.data) || t;
      e.rid && (this._rid = e.rid), e.full_update || !this.data ? (this.data = e.server_state || {}, this.torrents = e.torrents || {}) : (e.server_state && Object.assign(this.data, e.server_state), e.torrents && Object.assign(this.torrents, e.torrents), e.torrents_removed && e.torrents_removed.forEach((s) => delete this.torrents[s])), this.error = "";
    } catch (t) {
      this.error = String((t == null ? void 0 : t.message) || "").includes("not found") ? "请先配置连接" : "连接失败";
    } finally {
      this.loading = !1;
    }
  }
  get colors() {
    var e;
    const t = ((e = this.config) == null ? void 0 : e.textMode) !== "dark";
    return {
      text: t ? "#fff" : "#1a1a2e",
      sub: t ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.5)",
      glass: t ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.05)",
      dl: "#22c55e",
      up: "#3b82f6",
      seed: "#f59e0b",
      pause: "#94a3b8",
      total: "#a855f7",
      ratio: "#06b6d4",
      disk: "#ec4899"
    };
  }
  icon(t, e = 16) {
    return f`<span class="icon" style="width:${e}px;height:${e}px" .innerHTML=${Ge[t] || ""}></span>`;
  }
  // 根据文本长度动态计算字号
  fs(t, e, s = 8) {
    const i = String(t).length;
    return i <= 6 ? e : i <= 8 ? Math.max(e * 0.85, s) : i <= 10 ? Math.max(e * 0.7, s) : Math.max(e * 0.6, s);
  }
  get baseStyle() {
    const t = this.colors;
    return `:host{display:block;width:100%;height:100%;overflow:hidden}*{box-sizing:border-box;margin:0;padding:0}.w{width:100%;height:100%;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:${t.text};display:flex;flex-direction:column;overflow:hidden;min-width:0;min-height:0}.icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.icon svg{width:100%;height:100%}.dl{color:${t.dl}}.up{color:${t.up}}.seed{color:${t.seed}}.pause{color:${t.pause}}.total{color:${t.total}}.ratio{color:${t.ratio}}.disk{color:${t.disk}}.glass{background:${t.glass};border-radius:4px}.val,.speed-val,.speed-num,.stat-val,.item-val,.metric-val{white-space:nowrap}`;
  }
  render() {
    var s;
    const t = this.colors;
    if (this.loading) return f`<style>${this.baseStyle}.w{align-items:center;justify-content:center;font-size:11px;color:${t.sub}}</style><div class="w">加载中...</div>`;
    if (this.error) return f`<style>${this.baseStyle}.w{align-items:center;justify-content:center;font-size:11px;color:#f87171}</style><div class="w">${this.error}</div>`;
    const e = (s = this.spCtx.widgetInfo) == null ? void 0 : s.gridSize;
    return e === "1x1" ? this.render1x1() : e === "1x2" ? this.render1x2() : e === "2x1" ? this.render2x1() : e === "2x4" ? this.render2x4() : this.render2x2();
  }
  render1x1() {
    const t = this.data, e = m(t.dl_info_speed), s = m(t.up_info_speed);
    return f`<style>${this.baseStyle}.w{align-items:center;justify-content:center;gap:8px;padding:6px}.row{display:flex;align-items:center;gap:4px}.val{font-weight:700;letter-spacing:-0.3px}</style>
      <div class="w">
        <div class="row dl">${this.icon("download", 14)}<span class="val" style="font-size:${this.fs(e, 13)}px">${e}</span></div>
        <div class="row up">${this.icon("upload", 14)}<span class="val" style="font-size:${this.fs(s, 13)}px">${s}</span></div>
      </div>`;
  }
  render1x2() {
    const t = this.data, e = this.colors, s = G(this.torrents), i = m(t.dl_info_speed), r = m(t.up_info_speed);
    return f`<style>${this.baseStyle}.w{flex-direction:row;padding:8px 12px;align-items:center;justify-content:space-between}.left{display:flex;flex-direction:column;gap:6px}.row{display:flex;align-items:center;gap:4px}.val{font-weight:700}.right{display:flex;gap:12px}.stat{text-align:center}.stat-val{font-size:12px;font-weight:700;display:block}.stat-label{font-size:8px;color:${e.sub}}</style>
      <div class="w">
        <div class="left">
          <div class="row dl">${this.icon("download", 12)}<span class="val" style="font-size:${this.fs(i, 14)}px">${i}</span></div>
          <div class="row up">${this.icon("upload", 12)}<span class="val" style="font-size:${this.fs(r, 14)}px">${r}</span></div>
        </div>
        <div class="right">
          <div class="stat dl"><span class="stat-val">${s.downloading}</span><span class="stat-label">下载</span></div>
          <div class="stat seed"><span class="stat-val">${s.seeding}</span><span class="stat-label">做种</span></div>
          <div class="stat total"><span class="stat-val">${s.total}</span><span class="stat-label">总数</span></div>
        </div>
      </div>`;
  }
  render2x1() {
    const t = this.data, e = this.colors, s = G(this.torrents), i = m(t.dl_info_speed), r = m(t.up_info_speed);
    return f`<style>${this.baseStyle}
      .w{padding:8px;justify-content:space-between}
      .speed-card{background:${e.glass};border-radius:8px;padding:8px 6px;text-align:center}
      .speed-icon{margin-bottom:4px;opacity:.9}
      .speed-val{font-weight:800;display:block;line-height:1.2}
      .stats{display:flex;justify-content:space-around;padding:0 4px}
      .stat{text-align:center}
      .stat-val{font-size:13px;font-weight:700;display:block}
      .stat-label{font-size:8px;color:${e.sub}}
    </style>
      <div class="w">
        <div class="speed-card dl">
          <span class="speed-icon">${this.icon("download", 16)}</span>
          <span class="speed-val" style="font-size:${this.fs(i, 14)}px">${i}</span>
        </div>
        <div class="speed-card up">
          <span class="speed-icon">${this.icon("upload", 16)}</span>
          <span class="speed-val" style="font-size:${this.fs(r, 14)}px">${r}</span>
        </div>
        <div class="stats">
          <div class="stat dl"><span class="stat-val">${s.downloading}</span><span class="stat-label">下载</span></div>
          <div class="stat total"><span class="stat-val">${s.total}</span><span class="stat-label">总数</span></div>
        </div>
      </div>`;
  }
  render2x2() {
    const t = this.data, e = this.colors, s = G(this.torrents), i = m(t.dl_info_speed), r = m(t.up_info_speed);
    return f`<style>${this.baseStyle}.w{padding:10px;justify-content:space-between}.head{display:flex;justify-content:space-between;align-items:center}.title{font-size:10px;font-weight:600;opacity:.7}.speeds{display:flex;justify-content:center;gap:24px;padding:10px 0}.row{display:flex;align-items:center;gap:4px}.val{font-weight:700}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.item{text-align:center}.item-val{font-size:12px;font-weight:600;display:block}.item-label{font-size:8px;color:${e.sub}}</style>
      <div class="w">
        <div class="head"><span class="title">QB 下载器</span><span class="ratio" style="font-size:10px">${Wt(parseFloat(t.global_ratio))}</span></div>
        <div class="speeds">
          <div class="row dl">${this.icon("download", 14)}<span class="val" style="font-size:${this.fs(i, 18)}px">${i}</span></div>
          <div class="row up">${this.icon("upload", 14)}<span class="val" style="font-size:${this.fs(r, 18)}px">${r}</span></div>
        </div>
        <div class="grid">
          <div class="item dl"><span class="item-val">${s.downloading}</span><span class="item-label">下载</span></div>
          <div class="item seed"><span class="item-val">${s.seeding}</span><span class="item-label">做种</span></div>
          <div class="item pause"><span class="item-val">${s.completed}</span><span class="item-label">完成</span></div>
          <div class="item total"><span class="item-val">${s.total}</span><span class="item-label">总数</span></div>
        </div>
      </div>`;
  }
  render2x4() {
    const t = this.data, e = this.colors, s = G(this.torrents), i = m(t.dl_info_speed), r = m(t.up_info_speed), n = tt(t.alltime_dl), l = tt(t.alltime_ul), a = Wt(parseFloat(t.global_ratio)), h = tt(t.free_space_on_disk);
    return f`<style>${this.baseStyle}
      .w{flex-direction:row;padding:12px;gap:12px;align-items:stretch}
      .panel{background:${e.glass};border-radius:10px;padding:10px}
      .speed-panel{display:flex;flex-direction:column;justify-content:center;gap:12px;min-width:100px}
      .speed-item{display:flex;align-items:center;gap:6px}
      .speed-num{font-weight:800;letter-spacing:-0.3px}
      .center{flex:1;display:flex;flex-direction:column;justify-content:space-between;gap:10px}
      .row{display:flex;justify-content:space-around}
      .metric{display:flex;flex-direction:column;align-items:center;gap:3px}
      .metric-icon{opacity:.8}
      .metric-val{font-weight:700}
      .metric-label{font-size:8px;color:${e.sub}}
    </style>
      <div class="w">
        <div class="panel speed-panel">
          <div class="speed-item dl">${this.icon("download", 16)}<span class="speed-num" style="font-size:${this.fs(i, 20)}px">${i}</span></div>
          <div class="speed-item up">${this.icon("upload", 16)}<span class="speed-num" style="font-size:${this.fs(r, 20)}px">${r}</span></div>
        </div>
        <div class="center">
          <div class="row">
            <div class="metric dl"><span class="metric-icon">${this.icon("download", 12)}</span><span class="metric-val" style="font-size:13px">${s.downloading}</span><span class="metric-label">下载中</span></div>
            <div class="metric seed"><span class="metric-icon">${this.icon("seed", 12)}</span><span class="metric-val" style="font-size:13px">${s.seeding}</span><span class="metric-label">做种</span></div>
            <div class="metric pause"><span class="metric-icon">${this.icon("pause", 12)}</span><span class="metric-val" style="font-size:13px">${s.paused}</span><span class="metric-label">暂停</span></div>
            <div class="metric total"><span class="metric-icon">${this.icon("total", 12)}</span><span class="metric-val" style="font-size:13px">${s.total}</span><span class="metric-label">总数</span></div>
          </div>
          <div class="row">
            <div class="metric dl"><span class="metric-icon">${this.icon("totalDl", 12)}</span><span class="metric-val" style="font-size:${this.fs(n, 13)}px">${n}</span><span class="metric-label">总下载</span></div>
            <div class="metric up"><span class="metric-icon">${this.icon("totalUp", 12)}</span><span class="metric-val" style="font-size:${this.fs(l, 13)}px">${l}</span><span class="metric-label">总上传</span></div>
            <div class="metric ratio"><span class="metric-icon">${this.icon("ratio", 12)}</span><span class="metric-val" style="font-size:${this.fs(a, 13)}px">${a}</span><span class="metric-label">分享率</span></div>
            <div class="metric disk"><span class="metric-icon">${this.icon("disk", 12)}</span><span class="metric-val" style="font-size:${this.fs(h, 13)}px">${h}</span><span class="metric-label">剩余</span></div>
          </div>
        </div>
      </div>`;
  }
  renderItem(t, e, s) {
    return f`<div class="item"><span class="item-icon">${this.icon(t, 12)}</span><span class="item-val">${e}</span><span class="item-label">${s}</span></div>`;
  }
}
rt(ce, "properties", {
  data: { type: Object },
  torrents: { type: Object },
  loading: { type: Boolean },
  error: { type: String },
  config: { type: Object }
});
class pe extends he {
  constructor() {
    super(), this.host = "", this.username = "", this.password = "", this.refreshInterval = 5, this.textMode = "light", this.showHost = !1, this.showUser = !1, this.showPass = !1, this.hasSavedHost = !1, this.hasSavedUser = !1, this.hasSavedPass = !1, this.loading = !1, this.saving = !1, this.error = "", this.testStatus = "", this.testing = !1;
  }
  async onInitialized({ widgetInfo: t }) {
    const e = (t == null ? void 0 : t.config) || {};
    this.refreshInterval = e.refreshInterval || 5, this.textMode = e.textMode || "light", this.hasSavedHost = !!e.hasSavedHost, this.hasSavedUser = !!e.hasSavedUser, this.hasSavedPass = !!e.hasSavedPass;
  }
  async toggleSecret(t) {
    const s = {
      host: { show: "showHost", saved: "hasSavedHost", value: "host", key: "host" },
      user: { show: "showUser", saved: "hasSavedUser", value: "username", key: "username" },
      pass: { show: "showPass", saved: "hasSavedPass", value: "password", key: "password" }
    }[t];
    if (this[s.show]) {
      this[s.show] = !1;
      return;
    }
    if (this[s.value]) {
      this[s.show] = !0;
      return;
    }
    this.loading = !0;
    try {
      const i = await this.spCtx.api.dataNode.app.getByKey("config", s.key);
      i && (this[s.value] = i, this[s.saved] = !0), this[s.show] = !0;
    } catch (i) {
      String(i == null ? void 0 : i.message).includes("not found") && (this[s.saved] = !1);
    } finally {
      this.loading = !1;
    }
  }
  async testConnection() {
    var i, r;
    const t = this.host.trim(), e = this.username.trim(), s = this.password;
    if (!t && !this.hasSavedHost) {
      this.error = "请输入 QB 地址";
      return;
    }
    if (!e && !this.hasSavedUser) {
      this.error = "请输入用户名";
      return;
    }
    if (!s && !this.hasSavedPass) {
      this.error = "请输入密码";
      return;
    }
    this.testing = !0, this.testStatus = "测试中...", this.error = "", this.requestUpdate();
    try {
      console.log("[QB] 新输入:", { host: t || "(使用已保存)", username: e || "(使用已保存)", password: s ? "***" : "(使用已保存)" }), t && await this.spCtx.api.dataNode.app.setByKey("config", "host", t), e && await this.spCtx.api.dataNode.app.setByKey("config", "username", e), s && await this.spCtx.api.dataNode.app.setByKey("config", "password", s), console.log("[QB] 开始登录...");
      let n, l, a;
      try {
        n = (await this.spCtx.api.dataNode.app.getByKey("config", "host")).replace(/\/+$/, ""), l = await this.spCtx.api.dataNode.app.getByKey("config", "username"), a = await this.spCtx.api.dataNode.app.getByKey("config", "password"), console.log("[QB] dataNode 中的值:", { host: n, username: l, password: a ? a.substring(0, 2) + "***" : "(empty)" });
      } catch (v) {
        throw console.log("[QB] 读取 dataNode 失败:", v.message), new Error("无法读取配置");
      }
      const h = `username=${l}&password=${a}`;
      console.log("[QB] 登录请求体:", h.replace(/password=[^&]+/, "password=***"), "长度:", h.length);
      const c = await this.spCtx.api.network.request({
        targetUrl: n + "/api/v2/auth/login",
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Content-Length": String(h.length),
          Connection: "close",
          Referer: n + "/",
          Origin: n
        },
        body: h
      });
      console.log("[QB] login response:", c), console.log("[QB] login response data:", c == null ? void 0 : c.data), console.log("[QB] login response headers:", c == null ? void 0 : c.headers);
      const d = ((i = c == null ? void 0 : c.headers) == null ? void 0 : i["set-cookie"]) || ((r = c == null ? void 0 : c.headers) == null ? void 0 : r["Set-Cookie"]);
      let p = "";
      if (d) {
        const v = String(d).match(/SID=([^;]+)/);
        v && (p = v[1]);
      }
      console.log("[QB] SID:", p), p && await this.spCtx.api.dataNode.app.setByKey("config", "sid", p);
      const u = await this.spCtx.api.network.request({
        targetUrl: n + "/api/v2/app/version",
        method: "GET",
        headers: p ? { Cookie: `SID=${p}` } : {}
      });
      this.testStatus = `连接成功! QB版本: ${(u == null ? void 0 : u.data) || u}`, this.hasSavedHost = !0, this.hasSavedUser = !0, this.hasSavedPass = !0;
    } catch (n) {
      this.testStatus = "", this.error = "连接失败: " + ((n == null ? void 0 : n.message) || "未知错误");
    } finally {
      this.testing = !1;
    }
  }
  async handleSave() {
    const t = this.host.trim();
    if (!t && !this.hasSavedHost) {
      this.error = "请输入 QB 地址";
      return;
    }
    this.saving = !0, this.error = "";
    try {
      let e = this.hasSavedHost, s = this.hasSavedUser, i = this.hasSavedPass;
      t && (await this.spCtx.api.dataNode.app.setByKey("config", "host", t), e = !0), this.username.trim() && (await this.spCtx.api.dataNode.app.setByKey("config", "username", this.username.trim()), s = !0), this.password && (await this.spCtx.api.dataNode.app.setByKey("config", "password", this.password), i = !0), await this.spCtx.api.widget.save({
        ...this.spCtx.widgetInfo,
        config: { refreshInterval: this.refreshInterval, textMode: this.textMode, hasSavedHost: e, hasSavedUser: s, hasSavedPass: i }
      }), this.hasSavedHost = e, this.hasSavedUser = s, this.hasSavedPass = i;
    } catch (e) {
      this.error = "保存失败: " + ((e == null ? void 0 : e.message) || "未知错误");
    } finally {
      this.saving = !1;
    }
  }
  get iconEye() {
    return f`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>`;
  }
  get iconEyeOff() {
    return f`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19C5 19 1 12 1 12a21.85 21.85 0 0 1 5.06-5.94"/><path d="M9.9 4.24A10.9 10.9 0 0 1 12 4c7 0 11 8 11 8a21.86 21.86 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
  }
  get iconLink() {
    return f`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`;
  }
  get iconGear() {
    return f`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
  }
  get iconPlug() {
    return f`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8Z"/></svg>`;
  }
  get iconCheck() {
    return f`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>`;
  }
  get iconWarn() {
    return f`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
  }
  getStatus(t) {
    return t ? "已保存" : "未保存";
  }
  getStatusClass(t) {
    return t ? "status saved" : "status empty";
  }
  getPlaceholder(t, e) {
    return e ? `•••••• 已保存（点击眼睛查看${t}）` : `输入${t}`;
  }
  render() {
    var s;
    const t = ((s = this.spCtx) == null ? void 0 : s.darkMode) ?? !1, e = {
      bg: t ? "#1a1a1a" : "#fff",
      card: t ? "#242424" : "#f8f9fa",
      border: t ? "#333" : "#e5e7eb",
      text: t ? "#e5e5e5" : "#1f2937",
      sub: t ? "#a0a0a0" : "#6b7280",
      accent: "#3b82f6",
      input: t ? "#1a1a1a" : "#fff"
    };
    return f`
      <style>
        :host { display:block; height:100%; width:100%; }
        * { box-sizing:border-box; }
        .wrap { height:100%; padding:20px; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; color:${e.text}; background:${e.bg}; display:flex; flex-direction:column; }
        .title { font-size:18px; font-weight:600; margin:0 0 4px; }
        .subtitle { font-size:13px; color:${e.sub}; margin:0 0 20px; }
        .section { background:${e.card}; border:1px solid ${e.border}; border-radius:8px; padding:16px; margin-bottom:16px; }
        .section-title { font-size:13px; font-weight:500; color:${e.sub}; text-transform:uppercase; letter-spacing:.5px; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
        .row { margin-bottom:16px; }
        .row:last-child { margin-bottom:0; }
        .label-row { display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; }
        .label { font-size:13px; font-weight:500; }
        .status { font-size:11px; padding:2px 8px; border-radius:999px; }
        .status.saved { color:${t ? "#86efac" : "#166534"}; background:${t ? "rgba(34,197,94,.12)" : "#f0fdf4"}; border:1px solid ${t ? "rgba(34,197,94,.35)" : "#86efac"}; }
        .status.empty { color:${e.sub}; background:${t ? "rgba(255,255,255,.04)" : "#f9fafb"}; border:1px solid ${e.border}; }
        .input-row { display:grid; grid-template-columns:1fr 42px; gap:8px; }
        input, select { width:100%; padding:10px 12px; font-size:14px; border:1px solid ${e.border}; border-radius:6px; background:${e.input}; color:${e.text}; }
        input:focus, select:focus { outline:none; border-color:${e.accent}; }
        .btn-eye { height:40px; border:1px solid ${e.border}; background:${e.input}; color:${e.sub}; border-radius:6px; cursor:pointer; display:flex; align-items:center; justify-content:center; }
        .btn-eye:hover { color:${e.accent}; border-color:${e.accent}; }
        .hint { font-size:12px; color:${e.sub}; margin-top:4px; }
        .radio-group { display:flex; gap:12px; }
        .radio-item { flex:1; display:flex; align-items:center; gap:8px; padding:10px 12px; border:1px solid ${e.border}; border-radius:6px; cursor:pointer; background:${e.input}; }
        .radio-item:hover { border-color:${e.accent}; }
        .radio-item.active { border-color:${e.accent}; background:${t ? "rgba(59,130,246,.1)" : "rgba(59,130,246,.05)"}; }
        .radio-dot { width:16px; height:16px; border:2px solid ${e.border}; border-radius:50%; display:flex; align-items:center; justify-content:center; }
        .radio-item.active .radio-dot { border-color:${e.accent}; }
        .radio-dot::after { content:''; width:8px; height:8px; border-radius:50%; background:${e.accent}; opacity:0; }
        .radio-item.active .radio-dot::after { opacity:1; }
        .btn-test { padding:10px; font-size:13px; color:${e.accent}; background:${t ? "rgba(59,130,246,.1)" : "rgba(59,130,246,.05)"}; border:1px solid ${e.accent}; border-radius:6px; cursor:pointer; margin-top:12px; }
        .btn-test:hover { background:${t ? "rgba(59,130,246,.2)" : "rgba(59,130,246,.1)"}; }
        .test-ok { margin-top:8px; padding:8px 10px; font-size:12px; color:#22c55e; background:${t ? "rgba(34,197,94,.1)" : "rgba(34,197,94,.05)"}; border-radius:6px; }
        .error { margin-top:16px; padding:10px 12px; font-size:13px; color:#ef4444; background:${t ? "rgba(239,68,68,.1)" : "rgba(239,68,68,.05)"}; border-radius:6px; }
        .footer { padding-top:16px; border-top:1px solid ${e.border}; margin-top:auto; }
        .btn-save { width:100%; padding:12px; font-size:14px; font-weight:500; color:#fff; background:${e.accent}; border:none; border-radius:6px; cursor:pointer; }
        .btn-save:hover { background:#2563eb; }
        .btn-save:disabled { opacity:.5; cursor:not-allowed; }
      </style>
      <div class="wrap">
        <h1 class="title">QB下载器配置</h1>
        <p class="subtitle">配置 qBittorrent WebUI 连接信息</p>

        <div class="section">
          <div class="section-title">${this.iconLink} 连接设置</div>
          ${this.renderSecretField("host", "QB 地址", "http://192.168.1.100:8080")}
          ${this.renderSecretField("user", "用户名", "admin")}
          ${this.renderSecretField("pass", "密码", "••••••")}
          <button class="btn-test" @click=${this.testConnection} ?disabled=${this.testing}>${this.iconPlug} ${this.testing ? "测试中..." : "测试连接"}</button>
          ${this.testStatus ? f`<div class="test-ok">${this.iconCheck} ${this.testStatus}</div>` : ""}
        </div>

        <div class="section">
          <div class="section-title">${this.iconGear} 显示设置</div>
          <div class="row">
            <div class="label">刷新间隔</div>
            <select .value=${String(this.refreshInterval)} @change=${(i) => this.refreshInterval = Number(i.target.value)}>
              <option value="3">3 秒</option><option value="5">5 秒</option><option value="10">10 秒</option><option value="30">30 秒</option>
            </select>
          </div>
          <div class="row">
            <div class="label">文字颜色</div>
            <div class="radio-group">
              <label class="radio-item ${this.textMode === "light" ? "active" : ""}" @click=${() => this.textMode = "light"}><span class="radio-dot"></span>浅色</label>
              <label class="radio-item ${this.textMode === "dark" ? "active" : ""}" @click=${() => this.textMode = "dark"}><span class="radio-dot"></span>深色</label>
            </div>
            <div class="hint">深色背景选浅色文字，浅色背景选深色文字</div>
          </div>
        </div>

        ${this.error ? f`<div class="error">${this.iconWarn} ${this.error}</div>` : ""}

        <div class="footer">
          <button class="btn-save" @click=${this.handleSave} ?disabled=${this.saving}>${this.saving ? "保存中..." : "保存"}</button>
        </div>
      </div>
    `;
  }
  renderSecretField(t, e, s) {
    const i = { host: ["showHost", "hasSavedHost", "host"], user: ["showUser", "hasSavedUser", "username"], pass: ["showPass", "hasSavedPass", "password"] }, [r, n, l] = i[t], a = t === "pass";
    return f`
      <div class="row">
        <div class="label-row"><span class="label">${e}</span><span class="${this.getStatusClass(this[n])}">${this.getStatus(this[n])}</span></div>
        <div class="input-row">
          <input type="${this[r] && !a ? "text" : "password"}" .value=${this[l]} @input=${(h) => {
      this[l] = h.target.value, this.error = "";
    }} placeholder=${this.getPlaceholder(e, this[n]) || s}>
          <button class="btn-eye" @click=${() => this.toggleSecret(t)}>${this[r] ? this.iconEyeOff : this.iconEye}</button>
        </div>
      </div>
    `;
  }
}
rt(pe, "properties", {
  host: { type: String },
  username: { type: String },
  password: { type: String },
  refreshInterval: { type: Number },
  textMode: { type: String },
  showHost: { type: Boolean },
  showUser: { type: Boolean },
  showPass: { type: Boolean },
  hasSavedHost: { type: Boolean },
  hasSavedUser: { type: Boolean },
  hasSavedPass: { type: Boolean },
  loading: { type: Boolean },
  saving: { type: Boolean },
  error: { type: String },
  testStatus: { type: String },
  testing: { type: Boolean }
});
const Je = {
  microAppId: "madrays-qb-downloader",
  version: "1.0.0",
  author: "Madrays",
  entry: "main.js",
  icon: "logo.svg"
}, Xe = {
  pages: {
    "qb-config": {
      component: pe,
      background: "#f8fafc"
    }
  },
  widgets: {
    "qb-widget": {
      component: ce,
      configComponentName: "qb-config",
      size: ["1x1", "1x2", "2x1", "2x2", "2x4"],
      background: "",
      isModifyBackground: !0
    }
  }
}, ds = { appConfig: Je, components: Xe };
export {
  ds as default
};
