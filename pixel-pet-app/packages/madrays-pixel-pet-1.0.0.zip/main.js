var xe = Object.defineProperty;
var ve = (s, t, i) => t in s ? xe(s, t, { enumerable: !0, configurable: !0, writable: !0, value: i }) : s[t] = i;
var at = (s, t, i) => ve(s, typeof t != "symbol" ? t + "" : t, i);
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const tt = globalThis, _t = tt.ShadowRoot && (tt.ShadyCSS === void 0 || tt.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, ee = Symbol(), Mt = /* @__PURE__ */ new WeakMap();
let _e = class {
  constructor(t, i, n) {
    if (this._$cssResult$ = !0, n !== ee) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = i;
  }
  get styleSheet() {
    let t = this.o;
    const i = this.t;
    if (_t && t === void 0) {
      const n = i !== void 0 && i.length === 1;
      n && (t = Mt.get(i)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), n && Mt.set(i, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const ke = (s) => new _e(typeof s == "string" ? s : s + "", void 0, ee), we = (s, t) => {
  if (_t) s.adoptedStyleSheets = t.map((i) => i instanceof CSSStyleSheet ? i : i.styleSheet);
  else for (const i of t) {
    const n = document.createElement("style"), r = tt.litNonce;
    r !== void 0 && n.setAttribute("nonce", r), n.textContent = i.cssText, s.appendChild(n);
  }
}, Et = _t ? (s) => s : (s) => s instanceof CSSStyleSheet ? ((t) => {
  let i = "";
  for (const n of t.cssRules) i += n.cssText;
  return ke(i);
})(s) : s;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: Ae, defineProperty: Se, getOwnPropertyDescriptor: Me, getOwnPropertyNames: Ee, getOwnPropertySymbols: Ce, getPrototypeOf: Pe } = Object, w = globalThis, Ct = w.trustedTypes, Le = Ct ? Ct.emptyScript : "", lt = w.reactiveElementPolyfillSupport, B = (s, t) => s, gt = { toAttribute(s, t) {
  switch (t) {
    case Boolean:
      s = s ? Le : null;
      break;
    case Object:
    case Array:
      s = s == null ? s : JSON.stringify(s);
  }
  return s;
}, fromAttribute(s, t) {
  let i = s;
  switch (t) {
    case Boolean:
      i = s !== null;
      break;
    case Number:
      i = s === null ? null : Number(s);
      break;
    case Object:
    case Array:
      try {
        i = JSON.parse(s);
      } catch {
        i = null;
      }
  }
  return i;
} }, se = (s, t) => !Ae(s, t), Pt = { attribute: !0, type: String, converter: gt, reflect: !1, useDefault: !1, hasChanged: se };
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), w.litPropertyMetadata ?? (w.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let U = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ?? (this.l = [])).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, i = Pt) {
    if (i.state && (i.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((i = Object.create(i)).wrapped = !0), this.elementProperties.set(t, i), !i.noAccessor) {
      const n = Symbol(), r = this.getPropertyDescriptor(t, n, i);
      r !== void 0 && Se(this.prototype, t, r);
    }
  }
  static getPropertyDescriptor(t, i, n) {
    const { get: r, set: o } = Me(this.prototype, t) ?? { get() {
      return this[i];
    }, set(e) {
      this[i] = e;
    } };
    return { get: r, set(e) {
      const a = r == null ? void 0 : r.call(this);
      o == null || o.call(this, e), this.requestUpdate(t, a, n);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? Pt;
  }
  static _$Ei() {
    if (this.hasOwnProperty(B("elementProperties"))) return;
    const t = Pe(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(B("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(B("properties"))) {
      const i = this.properties, n = [...Ee(i), ...Ce(i)];
      for (const r of n) this.createProperty(r, i[r]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const i = litPropertyMetadata.get(t);
      if (i !== void 0) for (const [n, r] of i) this.elementProperties.set(n, r);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [i, n] of this.elementProperties) {
      const r = this._$Eu(i, n);
      r !== void 0 && this._$Eh.set(r, i);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const i = [];
    if (Array.isArray(t)) {
      const n = new Set(t.flat(1 / 0).reverse());
      for (const r of n) i.unshift(Et(r));
    } else t !== void 0 && i.push(Et(t));
    return i;
  }
  static _$Eu(t, i) {
    const n = i.attribute;
    return n === !1 ? void 0 : typeof n == "string" ? n : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var t;
    this._$ES = new Promise((i) => this.enableUpdating = i), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (t = this.constructor.l) == null || t.forEach((i) => i(this));
  }
  addController(t) {
    var i;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(t), this.renderRoot !== void 0 && this.isConnected && ((i = t.hostConnected) == null || i.call(t));
  }
  removeController(t) {
    var i;
    (i = this._$EO) == null || i.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), i = this.constructor.elementProperties;
    for (const n of i.keys()) this.hasOwnProperty(n) && (t.set(n, this[n]), delete this[n]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return we(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    var t;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (t = this._$EO) == null || t.forEach((i) => {
      var n;
      return (n = i.hostConnected) == null ? void 0 : n.call(i);
    });
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    var t;
    (t = this._$EO) == null || t.forEach((i) => {
      var n;
      return (n = i.hostDisconnected) == null ? void 0 : n.call(i);
    });
  }
  attributeChangedCallback(t, i, n) {
    this._$AK(t, n);
  }
  _$ET(t, i) {
    var o;
    const n = this.constructor.elementProperties.get(t), r = this.constructor._$Eu(t, n);
    if (r !== void 0 && n.reflect === !0) {
      const e = (((o = n.converter) == null ? void 0 : o.toAttribute) !== void 0 ? n.converter : gt).toAttribute(i, n.type);
      this._$Em = t, e == null ? this.removeAttribute(r) : this.setAttribute(r, e), this._$Em = null;
    }
  }
  _$AK(t, i) {
    var o, e;
    const n = this.constructor, r = n._$Eh.get(t);
    if (r !== void 0 && this._$Em !== r) {
      const a = n.getPropertyOptions(r), p = typeof a.converter == "function" ? { fromAttribute: a.converter } : ((o = a.converter) == null ? void 0 : o.fromAttribute) !== void 0 ? a.converter : gt;
      this._$Em = r;
      const l = p.fromAttribute(i, a.type);
      this[r] = l ?? ((e = this._$Ej) == null ? void 0 : e.get(r)) ?? l, this._$Em = null;
    }
  }
  requestUpdate(t, i, n, r = !1, o) {
    var e;
    if (t !== void 0) {
      const a = this.constructor;
      if (r === !1 && (o = this[t]), n ?? (n = a.getPropertyOptions(t)), !((n.hasChanged ?? se)(o, i) || n.useDefault && n.reflect && o === ((e = this._$Ej) == null ? void 0 : e.get(t)) && !this.hasAttribute(a._$Eu(t, n)))) return;
      this.C(t, i, n);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, i, { useDefault: n, reflect: r, wrapped: o }, e) {
    n && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(t) && (this._$Ej.set(t, e ?? i ?? this[t]), o !== !0 || e !== void 0) || (this._$AL.has(t) || (this.hasUpdated || n || (i = void 0), this._$AL.set(t, i)), r === !0 && this._$Em !== t && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (i) {
      Promise.reject(i);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var n;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [o, e] of this._$Ep) this[o] = e;
        this._$Ep = void 0;
      }
      const r = this.constructor.elementProperties;
      if (r.size > 0) for (const [o, e] of r) {
        const { wrapped: a } = e, p = this[o];
        a !== !0 || this._$AL.has(o) || p === void 0 || this.C(o, void 0, e, p);
      }
    }
    let t = !1;
    const i = this._$AL;
    try {
      t = this.shouldUpdate(i), t ? (this.willUpdate(i), (n = this._$EO) == null || n.forEach((r) => {
        var o;
        return (o = r.hostUpdate) == null ? void 0 : o.call(r);
      }), this.update(i)) : this._$EM();
    } catch (r) {
      throw t = !1, this._$EM(), r;
    }
    t && this._$AE(i);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    var i;
    (i = this._$EO) == null || i.forEach((n) => {
      var r;
      return (r = n.hostUpdated) == null ? void 0 : r.call(n);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((i) => this._$ET(i, this[i]))), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
U.elementStyles = [], U.shadowRootOptions = { mode: "open" }, U[B("elementProperties")] = /* @__PURE__ */ new Map(), U[B("finalized")] = /* @__PURE__ */ new Map(), lt == null || lt({ ReactiveElement: U }), (w.reactiveElementVersions ?? (w.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Q = globalThis, Lt = (s) => s, it = Q.trustedTypes, Tt = it ? it.createPolicy("lit-html", { createHTML: (s) => s }) : void 0, ie = "$lit$", _ = `lit$${Math.random().toFixed(9).slice(2)}$`, ne = "?" + _, Te = `<${ne}>`, T = document, q = () => T.createComment(""), Z = (s) => s === null || typeof s != "object" && typeof s != "function", kt = Array.isArray, Ne = (s) => kt(s) || typeof (s == null ? void 0 : s[Symbol.iterator]) == "function", ht = `[ 	
\f\r]`, j = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Nt = /-->/g, Ut = />/g, S = RegExp(`>|${ht}(?:([^\\s"'>=/]+)(${ht}*=${ht}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Ot = /'/g, zt = /"/g, re = /^(?:script|style|textarea|title)$/i, Ue = (s) => (t, ...i) => ({ _$litType$: s, strings: t, values: i }), b = Ue(1), z = Symbol.for("lit-noChange"), y = Symbol.for("lit-nothing"), Ht = /* @__PURE__ */ new WeakMap(), E = T.createTreeWalker(T, 129);
function oe(s, t) {
  if (!kt(s) || !s.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Tt !== void 0 ? Tt.createHTML(t) : t;
}
const Oe = (s, t) => {
  const i = s.length - 1, n = [];
  let r, o = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", e = j;
  for (let a = 0; a < i; a++) {
    const p = s[a];
    let l, h, c = -1, u = 0;
    for (; u < p.length && (e.lastIndex = u, h = e.exec(p), h !== null); ) u = e.lastIndex, e === j ? h[1] === "!--" ? e = Nt : h[1] !== void 0 ? e = Ut : h[2] !== void 0 ? (re.test(h[2]) && (r = RegExp("</" + h[2], "g")), e = S) : h[3] !== void 0 && (e = S) : e === S ? h[0] === ">" ? (e = r ?? j, c = -1) : h[1] === void 0 ? c = -2 : (c = e.lastIndex - h[2].length, l = h[1], e = h[3] === void 0 ? S : h[3] === '"' ? zt : Ot) : e === zt || e === Ot ? e = S : e === Nt || e === Ut ? e = j : (e = S, r = void 0);
    const $ = e === S && s[a + 1].startsWith("/>") ? " " : "";
    o += e === j ? p + Te : c >= 0 ? (n.push(l), p.slice(0, c) + ie + p.slice(c) + _ + $) : p + _ + (c === -2 ? a : $);
  }
  return [oe(s, o + (s[i] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), n];
};
let bt = class ae {
  constructor({ strings: t, _$litType$: i }, n) {
    let r;
    this.parts = [];
    let o = 0, e = 0;
    const a = t.length - 1, p = this.parts, [l, h] = Oe(t, i);
    if (this.el = ae.createElement(l, n), E.currentNode = this.el.content, i === 2 || i === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (r = E.nextNode()) !== null && p.length < a; ) {
      if (r.nodeType === 1) {
        if (r.hasAttributes()) for (const c of r.getAttributeNames()) if (c.endsWith(ie)) {
          const u = h[e++], $ = r.getAttribute(c).split(_), x = /([.?@])?(.*)/.exec(u);
          p.push({ type: 1, index: o, name: x[2], strings: $, ctor: x[1] === "." ? He : x[1] === "?" ? Re : x[1] === "@" ? De : rt }), r.removeAttribute(c);
        } else c.startsWith(_) && (p.push({ type: 6, index: o }), r.removeAttribute(c));
        if (re.test(r.tagName)) {
          const c = r.textContent.split(_), u = c.length - 1;
          if (u > 0) {
            r.textContent = it ? it.emptyScript : "";
            for (let $ = 0; $ < u; $++) r.append(c[$], q()), E.nextNode(), p.push({ type: 2, index: ++o });
            r.append(c[u], q());
          }
        }
      } else if (r.nodeType === 8) if (r.data === ne) p.push({ type: 2, index: o });
      else {
        let c = -1;
        for (; (c = r.data.indexOf(_, c + 1)) !== -1; ) p.push({ type: 7, index: o }), c += _.length - 1;
      }
      o++;
    }
  }
  static createElement(t, i) {
    const n = T.createElement("template");
    return n.innerHTML = t, n;
  }
};
function H(s, t, i = s, n) {
  var e, a;
  if (t === z) return t;
  let r = n !== void 0 ? (e = i._$Co) == null ? void 0 : e[n] : i._$Cl;
  const o = Z(t) ? void 0 : t._$litDirective$;
  return (r == null ? void 0 : r.constructor) !== o && ((a = r == null ? void 0 : r._$AO) == null || a.call(r, !1), o === void 0 ? r = void 0 : (r = new o(s), r._$AT(s, i, n)), n !== void 0 ? (i._$Co ?? (i._$Co = []))[n] = r : i._$Cl = r), r !== void 0 && (t = H(s, r._$AS(s, t.values), r, n)), t;
}
let ze = class {
  constructor(t, i) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = i;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: i }, parts: n } = this._$AD, r = ((t == null ? void 0 : t.creationScope) ?? T).importNode(i, !0);
    E.currentNode = r;
    let o = E.nextNode(), e = 0, a = 0, p = n[0];
    for (; p !== void 0; ) {
      if (e === p.index) {
        let l;
        p.type === 2 ? l = new wt(o, o.nextSibling, this, t) : p.type === 1 ? l = new p.ctor(o, p.name, p.strings, this, t) : p.type === 6 && (l = new je(o, this, t)), this._$AV.push(l), p = n[++a];
      }
      e !== (p == null ? void 0 : p.index) && (o = E.nextNode(), e++);
    }
    return E.currentNode = T, r;
  }
  p(t) {
    let i = 0;
    for (const n of this._$AV) n !== void 0 && (n.strings !== void 0 ? (n._$AI(t, n, i), i += n.strings.length - 2) : n._$AI(t[i])), i++;
  }
}, wt = class le {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, i, n, r) {
    this.type = 2, this._$AH = y, this._$AN = void 0, this._$AA = t, this._$AB = i, this._$AM = n, this.options = r, this._$Cv = (r == null ? void 0 : r.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const i = this._$AM;
    return i !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = i.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, i = this) {
    t = H(this, t, i), Z(t) ? t === y || t == null || t === "" ? (this._$AH !== y && this._$AR(), this._$AH = y) : t !== this._$AH && t !== z && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Ne(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== y && Z(this._$AH) ? this._$AA.nextSibling.data = t : this.T(T.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var o;
    const { values: i, _$litType$: n } = t, r = typeof n == "number" ? this._$AC(t) : (n.el === void 0 && (n.el = bt.createElement(oe(n.h, n.h[0]), this.options)), n);
    if (((o = this._$AH) == null ? void 0 : o._$AD) === r) this._$AH.p(i);
    else {
      const e = new ze(r, this), a = e.u(this.options);
      e.p(i), this.T(a), this._$AH = e;
    }
  }
  _$AC(t) {
    let i = Ht.get(t.strings);
    return i === void 0 && Ht.set(t.strings, i = new bt(t)), i;
  }
  k(t) {
    kt(this._$AH) || (this._$AH = [], this._$AR());
    const i = this._$AH;
    let n, r = 0;
    for (const o of t) r === i.length ? i.push(n = new le(this.O(q()), this.O(q()), this, this.options)) : n = i[r], n._$AI(o), r++;
    r < i.length && (this._$AR(n && n._$AB.nextSibling, r), i.length = r);
  }
  _$AR(t = this._$AA.nextSibling, i) {
    var n;
    for ((n = this._$AP) == null ? void 0 : n.call(this, !1, !0, i); t !== this._$AB; ) {
      const r = Lt(t).nextSibling;
      Lt(t).remove(), t = r;
    }
  }
  setConnected(t) {
    var i;
    this._$AM === void 0 && (this._$Cv = t, (i = this._$AP) == null || i.call(this, t));
  }
}, rt = class {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, i, n, r, o) {
    this.type = 1, this._$AH = y, this._$AN = void 0, this.element = t, this.name = i, this._$AM = r, this.options = o, n.length > 2 || n[0] !== "" || n[1] !== "" ? (this._$AH = Array(n.length - 1).fill(new String()), this.strings = n) : this._$AH = y;
  }
  _$AI(t, i = this, n, r) {
    const o = this.strings;
    let e = !1;
    if (o === void 0) t = H(this, t, i, 0), e = !Z(t) || t !== this._$AH && t !== z, e && (this._$AH = t);
    else {
      const a = t;
      let p, l;
      for (t = o[0], p = 0; p < o.length - 1; p++) l = H(this, a[n + p], i, p), l === z && (l = this._$AH[p]), e || (e = !Z(l) || l !== this._$AH[p]), l === y ? t = y : t !== y && (t += (l ?? "") + o[p + 1]), this._$AH[p] = l;
    }
    e && !r && this.j(t);
  }
  j(t) {
    t === y ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}, He = class extends rt {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === y ? void 0 : t;
  }
}, Re = class extends rt {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== y);
  }
}, De = class extends rt {
  constructor(t, i, n, r, o) {
    super(t, i, n, r, o), this.type = 5;
  }
  _$AI(t, i = this) {
    if ((t = H(this, t, i, 0) ?? y) === z) return;
    const n = this._$AH, r = t === y && n !== y || t.capture !== n.capture || t.once !== n.once || t.passive !== n.passive, o = t !== y && (n === y || r);
    r && this.element.removeEventListener(this.name, this, n), o && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var i;
    typeof this._$AH == "function" ? this._$AH.call(((i = this.options) == null ? void 0 : i.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}, je = class {
  constructor(t, i, n) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = i, this.options = n;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    H(this, t);
  }
};
const pt = Q.litHtmlPolyfillSupport;
pt == null || pt(bt, wt), (Q.litHtmlVersions ?? (Q.litHtmlVersions = [])).push("3.3.2");
const Ie = (s, t, i) => {
  const n = (i == null ? void 0 : i.renderBefore) ?? t;
  let r = n._$litPart$;
  if (r === void 0) {
    const o = (i == null ? void 0 : i.renderBefore) ?? null;
    n._$litPart$ = r = new wt(t.insertBefore(q(), o), o, void 0, i ?? {});
  }
  return r._$AI(s), r;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const P = globalThis;
let et = class extends U {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var i;
    const t = super.createRenderRoot();
    return (i = this.renderOptions).renderBefore ?? (i.renderBefore = t.firstChild), t;
  }
  update(t) {
    const i = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = Ie(i, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return z;
  }
};
var Gt;
et._$litElement$ = !0, et.finalized = !0, (Gt = P.litElementHydrateSupport) == null || Gt.call(P, { LitElement: et });
const dt = P.litElementPolyfillSupport;
dt == null || dt({ LitElement: et });
(P.litElementVersions ?? (P.litElementVersions = [])).push("4.2.2");
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const st = globalThis, At = st.ShadowRoot && (st.ShadyCSS === void 0 || st.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, he = Symbol(), Rt = /* @__PURE__ */ new WeakMap();
let Be = class {
  constructor(s, t, i) {
    if (this._$cssResult$ = !0, i !== he) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = s, this.t = t;
  }
  get styleSheet() {
    let s = this.o;
    const t = this.t;
    if (At && s === void 0) {
      const i = t !== void 0 && t.length === 1;
      i && (s = Rt.get(t)), s === void 0 && ((this.o = s = new CSSStyleSheet()).replaceSync(this.cssText), i && Rt.set(t, s));
    }
    return s;
  }
  toString() {
    return this.cssText;
  }
};
const Dt = At ? (s) => s : (s) => s instanceof CSSStyleSheet ? ((t) => {
  let i = "";
  for (const n of t.cssRules) i += n.cssText;
  return ((n) => new Be(typeof n == "string" ? n : n + "", void 0, he))(i);
})(s) : s, { is: Qe, defineProperty: Fe, getOwnPropertyDescriptor: We, getOwnPropertyNames: Xe, getOwnPropertySymbols: qe, getPrototypeOf: Ze } = Object, A = globalThis, jt = A.trustedTypes, Ve = jt ? jt.emptyScript : "", ct = A.reactiveElementPolyfillSupport, F = (s, t) => s, mt = { toAttribute(s, t) {
  switch (t) {
    case Boolean:
      s = s ? Ve : null;
      break;
    case Object:
    case Array:
      s = s == null ? s : JSON.stringify(s);
  }
  return s;
}, fromAttribute(s, t) {
  let i = s;
  switch (t) {
    case Boolean:
      i = s !== null;
      break;
    case Number:
      i = s === null ? null : Number(s);
      break;
    case Object:
    case Array:
      try {
        i = JSON.parse(s);
      } catch {
        i = null;
      }
  }
  return i;
} }, pe = (s, t) => !Qe(s, t), It = { attribute: !0, type: String, converter: mt, reflect: !1, useDefault: !1, hasChanged: pe };
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), A.litPropertyMetadata ?? (A.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let O = class extends HTMLElement {
  static addInitializer(s) {
    this._$Ei(), (this.l ?? (this.l = [])).push(s);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(s, t = It) {
    if (t.state && (t.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(s) && ((t = Object.create(t)).wrapped = !0), this.elementProperties.set(s, t), !t.noAccessor) {
      const i = Symbol(), n = this.getPropertyDescriptor(s, i, t);
      n !== void 0 && Fe(this.prototype, s, n);
    }
  }
  static getPropertyDescriptor(s, t, i) {
    const { get: n, set: r } = We(this.prototype, s) ?? { get() {
      return this[t];
    }, set(o) {
      this[t] = o;
    } };
    return { get: n, set(o) {
      const e = n == null ? void 0 : n.call(this);
      r == null || r.call(this, o), this.requestUpdate(s, e, i);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(s) {
    return this.elementProperties.get(s) ?? It;
  }
  static _$Ei() {
    if (this.hasOwnProperty(F("elementProperties"))) return;
    const s = Ze(this);
    s.finalize(), s.l !== void 0 && (this.l = [...s.l]), this.elementProperties = new Map(s.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(F("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(F("properties"))) {
      const t = this.properties, i = [...Xe(t), ...qe(t)];
      for (const n of i) this.createProperty(n, t[n]);
    }
    const s = this[Symbol.metadata];
    if (s !== null) {
      const t = litPropertyMetadata.get(s);
      if (t !== void 0) for (const [i, n] of t) this.elementProperties.set(i, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [t, i] of this.elementProperties) {
      const n = this._$Eu(t, i);
      n !== void 0 && this._$Eh.set(n, t);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(s) {
    const t = [];
    if (Array.isArray(s)) {
      const i = new Set(s.flat(1 / 0).reverse());
      for (const n of i) t.unshift(Dt(n));
    } else s !== void 0 && t.push(Dt(s));
    return t;
  }
  static _$Eu(s, t) {
    const i = t.attribute;
    return i === !1 ? void 0 : typeof i == "string" ? i : typeof s == "string" ? s.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var s;
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (s = this.constructor.l) == null || s.forEach((t) => t(this));
  }
  addController(s) {
    var t;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(s), this.renderRoot !== void 0 && this.isConnected && ((t = s.hostConnected) == null || t.call(s));
  }
  removeController(s) {
    var t;
    (t = this._$EO) == null || t.delete(s);
  }
  _$E_() {
    const s = /* @__PURE__ */ new Map(), t = this.constructor.elementProperties;
    for (const i of t.keys()) this.hasOwnProperty(i) && (s.set(i, this[i]), delete this[i]);
    s.size > 0 && (this._$Ep = s);
  }
  createRenderRoot() {
    const s = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return ((t, i) => {
      if (At) t.adoptedStyleSheets = i.map((n) => n instanceof CSSStyleSheet ? n : n.styleSheet);
      else for (const n of i) {
        const r = document.createElement("style"), o = st.litNonce;
        o !== void 0 && r.setAttribute("nonce", o), r.textContent = n.cssText, t.appendChild(r);
      }
    })(s, this.constructor.elementStyles), s;
  }
  connectedCallback() {
    var s;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (s = this._$EO) == null || s.forEach((t) => {
      var i;
      return (i = t.hostConnected) == null ? void 0 : i.call(t);
    });
  }
  enableUpdating(s) {
  }
  disconnectedCallback() {
    var s;
    (s = this._$EO) == null || s.forEach((t) => {
      var i;
      return (i = t.hostDisconnected) == null ? void 0 : i.call(t);
    });
  }
  attributeChangedCallback(s, t, i) {
    this._$AK(s, i);
  }
  _$ET(s, t) {
    var r;
    const i = this.constructor.elementProperties.get(s), n = this.constructor._$Eu(s, i);
    if (n !== void 0 && i.reflect === !0) {
      const o = (((r = i.converter) == null ? void 0 : r.toAttribute) !== void 0 ? i.converter : mt).toAttribute(t, i.type);
      this._$Em = s, o == null ? this.removeAttribute(n) : this.setAttribute(n, o), this._$Em = null;
    }
  }
  _$AK(s, t) {
    var r, o;
    const i = this.constructor, n = i._$Eh.get(s);
    if (n !== void 0 && this._$Em !== n) {
      const e = i.getPropertyOptions(n), a = typeof e.converter == "function" ? { fromAttribute: e.converter } : ((r = e.converter) == null ? void 0 : r.fromAttribute) !== void 0 ? e.converter : mt;
      this._$Em = n;
      const p = a.fromAttribute(t, e.type);
      this[n] = p ?? ((o = this._$Ej) == null ? void 0 : o.get(n)) ?? p, this._$Em = null;
    }
  }
  requestUpdate(s, t, i, n = !1, r) {
    var o;
    if (s !== void 0) {
      const e = this.constructor;
      if (n === !1 && (r = this[s]), i ?? (i = e.getPropertyOptions(s)), !((i.hasChanged ?? pe)(r, t) || i.useDefault && i.reflect && r === ((o = this._$Ej) == null ? void 0 : o.get(s)) && !this.hasAttribute(e._$Eu(s, i)))) return;
      this.C(s, t, i);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(s, t, { useDefault: i, reflect: n, wrapped: r }, o) {
    i && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(s) && (this._$Ej.set(s, o ?? t ?? this[s]), r !== !0 || o !== void 0) || (this._$AL.has(s) || (this.hasUpdated || i || (t = void 0), this._$AL.set(s, t)), n === !0 && this._$Em !== s && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(s));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (t) {
      Promise.reject(t);
    }
    const s = this.scheduleUpdate();
    return s != null && await s, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var i;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [r, o] of this._$Ep) this[r] = o;
        this._$Ep = void 0;
      }
      const n = this.constructor.elementProperties;
      if (n.size > 0) for (const [r, o] of n) {
        const { wrapped: e } = o, a = this[r];
        e !== !0 || this._$AL.has(r) || a === void 0 || this.C(r, void 0, o, a);
      }
    }
    let s = !1;
    const t = this._$AL;
    try {
      s = this.shouldUpdate(t), s ? (this.willUpdate(t), (i = this._$EO) == null || i.forEach((n) => {
        var r;
        return (r = n.hostUpdate) == null ? void 0 : r.call(n);
      }), this.update(t)) : this._$EM();
    } catch (n) {
      throw s = !1, this._$EM(), n;
    }
    s && this._$AE(t);
  }
  willUpdate(s) {
  }
  _$AE(s) {
    var t;
    (t = this._$EO) == null || t.forEach((i) => {
      var n;
      return (n = i.hostUpdated) == null ? void 0 : n.call(i);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(s)), this.updated(s);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(s) {
    return !0;
  }
  update(s) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((t) => this._$ET(t, this[t]))), this._$EM();
  }
  updated(s) {
  }
  firstUpdated(s) {
  }
};
O.elementStyles = [], O.shadowRootOptions = { mode: "open" }, O[F("elementProperties")] = /* @__PURE__ */ new Map(), O[F("finalized")] = /* @__PURE__ */ new Map(), ct == null || ct({ ReactiveElement: O }), (A.reactiveElementVersions ?? (A.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const W = globalThis, Bt = (s) => s, nt = W.trustedTypes, Qt = nt ? nt.createPolicy("lit-html", { createHTML: (s) => s }) : void 0, de = "$lit$", k = `lit$${Math.random().toFixed(9).slice(2)}$`, ce = "?" + k, Ye = `<${ce}>`, N = document, V = () => N.createComment(""), Y = (s) => s === null || typeof s != "object" && typeof s != "function", xt = Array.isArray, ft = `[ 	
\f\r]`, I = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Ft = /-->/g, Wt = />/g, M = RegExp(`>|${ft}(?:([^\\s"'>=/]+)(${ft}*=${ft}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Xt = /'/g, qt = /"/g, fe = /^(?:script|style|textarea|title)$/i, St = /* @__PURE__ */ ((s) => (t, ...i) => ({ _$litType$: s, strings: t, values: i }))(1), R = Symbol.for("lit-noChange"), g = Symbol.for("lit-nothing"), Zt = /* @__PURE__ */ new WeakMap(), C = N.createTreeWalker(N, 129);
function ue(s, t) {
  if (!xt(s) || !s.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Qt !== void 0 ? Qt.createHTML(t) : t;
}
const Ke = (s, t) => {
  const i = s.length - 1, n = [];
  let r, o = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", e = I;
  for (let a = 0; a < i; a++) {
    const p = s[a];
    let l, h, c = -1, u = 0;
    for (; u < p.length && (e.lastIndex = u, h = e.exec(p), h !== null); ) u = e.lastIndex, e === I ? h[1] === "!--" ? e = Ft : h[1] !== void 0 ? e = Wt : h[2] !== void 0 ? (fe.test(h[2]) && (r = RegExp("</" + h[2], "g")), e = M) : h[3] !== void 0 && (e = M) : e === M ? h[0] === ">" ? (e = r ?? I, c = -1) : h[1] === void 0 ? c = -2 : (c = e.lastIndex - h[2].length, l = h[1], e = h[3] === void 0 ? M : h[3] === '"' ? qt : Xt) : e === qt || e === Xt ? e = M : e === Ft || e === Wt ? e = I : (e = M, r = void 0);
    const $ = e === M && s[a + 1].startsWith("/>") ? " " : "";
    o += e === I ? p + Ye : c >= 0 ? (n.push(l), p.slice(0, c) + de + p.slice(c) + k + $) : p + k + (c === -2 ? a : $);
  }
  return [ue(s, o + (s[i] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), n];
};
class K {
  constructor({ strings: t, _$litType$: i }, n) {
    let r;
    this.parts = [];
    let o = 0, e = 0;
    const a = t.length - 1, p = this.parts, [l, h] = Ke(t, i);
    if (this.el = K.createElement(l, n), C.currentNode = this.el.content, i === 2 || i === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (r = C.nextNode()) !== null && p.length < a; ) {
      if (r.nodeType === 1) {
        if (r.hasAttributes()) for (const c of r.getAttributeNames()) if (c.endsWith(de)) {
          const u = h[e++], $ = r.getAttribute(c).split(k), x = /([.?@])?(.*)/.exec(u);
          p.push({ type: 1, index: o, name: x[2], strings: $, ctor: x[1] === "." ? Ge : x[1] === "?" ? ts : x[1] === "@" ? es : ot }), r.removeAttribute(c);
        } else c.startsWith(k) && (p.push({ type: 6, index: o }), r.removeAttribute(c));
        if (fe.test(r.tagName)) {
          const c = r.textContent.split(k), u = c.length - 1;
          if (u > 0) {
            r.textContent = nt ? nt.emptyScript : "";
            for (let $ = 0; $ < u; $++) r.append(c[$], V()), C.nextNode(), p.push({ type: 2, index: ++o });
            r.append(c[u], V());
          }
        }
      } else if (r.nodeType === 8) if (r.data === ce) p.push({ type: 2, index: o });
      else {
        let c = -1;
        for (; (c = r.data.indexOf(k, c + 1)) !== -1; ) p.push({ type: 7, index: o }), c += k.length - 1;
      }
      o++;
    }
  }
  static createElement(t, i) {
    const n = N.createElement("template");
    return n.innerHTML = t, n;
  }
}
function D(s, t, i = s, n) {
  var e, a;
  if (t === R) return t;
  let r = n !== void 0 ? (e = i._$Co) == null ? void 0 : e[n] : i._$Cl;
  const o = Y(t) ? void 0 : t._$litDirective$;
  return (r == null ? void 0 : r.constructor) !== o && ((a = r == null ? void 0 : r._$AO) == null || a.call(r, !1), o === void 0 ? r = void 0 : (r = new o(s), r._$AT(s, i, n)), n !== void 0 ? (i._$Co ?? (i._$Co = []))[n] = r : i._$Cl = r), r !== void 0 && (t = D(s, r._$AS(s, t.values), r, n)), t;
}
class Je {
  constructor(t, i) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = i;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: i }, parts: n } = this._$AD, r = ((t == null ? void 0 : t.creationScope) ?? N).importNode(i, !0);
    C.currentNode = r;
    let o = C.nextNode(), e = 0, a = 0, p = n[0];
    for (; p !== void 0; ) {
      if (e === p.index) {
        let l;
        p.type === 2 ? l = new J(o, o.nextSibling, this, t) : p.type === 1 ? l = new p.ctor(o, p.name, p.strings, this, t) : p.type === 6 && (l = new ss(o, this, t)), this._$AV.push(l), p = n[++a];
      }
      e !== (p == null ? void 0 : p.index) && (o = C.nextNode(), e++);
    }
    return C.currentNode = N, r;
  }
  p(t) {
    let i = 0;
    for (const n of this._$AV) n !== void 0 && (n.strings !== void 0 ? (n._$AI(t, n, i), i += n.strings.length - 2) : n._$AI(t[i])), i++;
  }
}
class J {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, i, n, r) {
    this.type = 2, this._$AH = g, this._$AN = void 0, this._$AA = t, this._$AB = i, this._$AM = n, this.options = r, this._$Cv = (r == null ? void 0 : r.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const i = this._$AM;
    return i !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = i.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, i = this) {
    t = D(this, t, i), Y(t) ? t === g || t == null || t === "" ? (this._$AH !== g && this._$AR(), this._$AH = g) : t !== this._$AH && t !== R && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : ((n) => xt(n) || typeof (n == null ? void 0 : n[Symbol.iterator]) == "function")(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== g && Y(this._$AH) ? this._$AA.nextSibling.data = t : this.T(N.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var o;
    const { values: i, _$litType$: n } = t, r = typeof n == "number" ? this._$AC(t) : (n.el === void 0 && (n.el = K.createElement(ue(n.h, n.h[0]), this.options)), n);
    if (((o = this._$AH) == null ? void 0 : o._$AD) === r) this._$AH.p(i);
    else {
      const e = new Je(r, this), a = e.u(this.options);
      e.p(i), this.T(a), this._$AH = e;
    }
  }
  _$AC(t) {
    let i = Zt.get(t.strings);
    return i === void 0 && Zt.set(t.strings, i = new K(t)), i;
  }
  k(t) {
    xt(this._$AH) || (this._$AH = [], this._$AR());
    const i = this._$AH;
    let n, r = 0;
    for (const o of t) r === i.length ? i.push(n = new J(this.O(V()), this.O(V()), this, this.options)) : n = i[r], n._$AI(o), r++;
    r < i.length && (this._$AR(n && n._$AB.nextSibling, r), i.length = r);
  }
  _$AR(t = this._$AA.nextSibling, i) {
    var n;
    for ((n = this._$AP) == null ? void 0 : n.call(this, !1, !0, i); t !== this._$AB; ) {
      const r = Bt(t).nextSibling;
      Bt(t).remove(), t = r;
    }
  }
  setConnected(t) {
    var i;
    this._$AM === void 0 && (this._$Cv = t, (i = this._$AP) == null || i.call(this, t));
  }
}
class ot {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, i, n, r, o) {
    this.type = 1, this._$AH = g, this._$AN = void 0, this.element = t, this.name = i, this._$AM = r, this.options = o, n.length > 2 || n[0] !== "" || n[1] !== "" ? (this._$AH = Array(n.length - 1).fill(new String()), this.strings = n) : this._$AH = g;
  }
  _$AI(t, i = this, n, r) {
    const o = this.strings;
    let e = !1;
    if (o === void 0) t = D(this, t, i, 0), e = !Y(t) || t !== this._$AH && t !== R, e && (this._$AH = t);
    else {
      const a = t;
      let p, l;
      for (t = o[0], p = 0; p < o.length - 1; p++) l = D(this, a[n + p], i, p), l === R && (l = this._$AH[p]), e || (e = !Y(l) || l !== this._$AH[p]), l === g ? t = g : t !== g && (t += (l ?? "") + o[p + 1]), this._$AH[p] = l;
    }
    e && !r && this.j(t);
  }
  j(t) {
    t === g ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Ge extends ot {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === g ? void 0 : t;
  }
}
class ts extends ot {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== g);
  }
}
class es extends ot {
  constructor(t, i, n, r, o) {
    super(t, i, n, r, o), this.type = 5;
  }
  _$AI(t, i = this) {
    if ((t = D(this, t, i, 0) ?? g) === R) return;
    const n = this._$AH, r = t === g && n !== g || t.capture !== n.capture || t.once !== n.once || t.passive !== n.passive, o = t !== g && (n === g || r);
    r && this.element.removeEventListener(this.name, this, n), o && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var i;
    typeof this._$AH == "function" ? this._$AH.call(((i = this.options) == null ? void 0 : i.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class ss {
  constructor(t, i, n) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = i, this.options = n;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    D(this, t);
  }
}
const ut = W.litHtmlPolyfillSupport;
ut == null || ut(K, J), (W.litHtmlVersions ?? (W.litHtmlVersions = [])).push("3.3.2");
const L = globalThis;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class X extends O {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var i;
    const t = super.createRenderRoot();
    return (i = this.renderOptions).renderBefore ?? (i.renderBefore = t.firstChild), t;
  }
  update(t) {
    const i = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = ((n, r, o) => {
      const e = (o == null ? void 0 : o.renderBefore) ?? r;
      let a = e._$litPart$;
      if (a === void 0) {
        const p = (o == null ? void 0 : o.renderBefore) ?? null;
        e._$litPart$ = a = new J(r.insertBefore(V(), p), p, void 0, o ?? {});
      }
      return a._$AI(n), a;
    })(i, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return R;
  }
}
var te;
X._$litElement$ = !0, X.finalized = !0, (te = L.litElementHydrateSupport) == null || te.call(L, { LitElement: X });
const $t = L.litElementPolyfillSupport;
$t == null || $t({ LitElement: X }), (L.litElementVersions ?? (L.litElementVersions = [])).push("4.2.2");
class $e extends X {
  constructor() {
    super(), this._initialized = !1, this._eventListeners = /* @__PURE__ */ new Map();
  }
  initializeMicroApp() {
    this._initialized || (this._setupEventListeners(), this._initialized = !0);
  }
  connectedCallback() {
    super.connectedCallback(), this.initializeMicroApp(), this.onConnected();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupEventListeners(), this.onDisconnected();
  }
  attributeChangedCallback(t, i, n) {
    super.attributeChangedCallback(t, i, n), this.onAttributeChanged(t, i, n);
  }
  _setupEventListeners() {
  }
  _cleanupEventListeners() {
    const t = Array.from(this._eventListeners.entries());
    for (const [i, n] of t) n.forEach((r) => {
      window.removeEventListener(i, r);
    });
    this._eventListeners.clear();
  }
  addEventListener(t, i, n) {
    super.addEventListener(t, i, n);
  }
  dispatchCustomEvent(t, i) {
    const n = new CustomEvent(t, { bubbles: !0, composed: !0, detail: i });
    this.dispatchEvent(n);
  }
  onConnected() {
  }
  onDisconnected() {
  }
  onAttributeChanged(t, i, n) {
  }
  render() {
    return St``;
  }
}
class ye extends $e {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, widgetInfo: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const i = Object.fromEntries(Object.entries(t).filter(([n, r]) => r !== void 0));
    this.spCtx = { ...this.spCtx, ...i };
  }
  firstUpdated(t) {
    var i;
    (i = super.firstUpdated) == null || i.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const i = t.get("spCtx") || {}, n = this.spCtx;
      n.widgetInfo !== i.widgetInfo && this.onWidgetInfoChanged(n.widgetInfo, i.widgetInfo), n.darkMode !== i.darkMode && this.onDarkModeChanged(n.darkMode, i.darkMode), n.language !== i.language && this.onLanguageChanged(n.language, i.language), n.networkMode !== i.networkMode && this.onNetworkModeChanged(n.networkMode, i.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized();
  }
  onInitialized() {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, i) {
  }
  onLanguageChanged(t, i) {
  }
  onNetworkModeChanged(t, i) {
  }
  onWidgetInfoChanged(t, i) {
  }
  render() {
    return St``;
  }
}
ye.properties = { spCtx: { type: Object, attribute: !1 } };
class ge extends $e {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, background: "", widgetInfo: {}, customParam: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const i = Object.fromEntries(Object.entries(t).filter(([n, r]) => r !== void 0));
    this.spCtx = { ...this.spCtx, ...i };
  }
  firstUpdated(t) {
    var i;
    (i = super.firstUpdated) == null || i.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const i = t.get("spCtx") || {}, n = this.spCtx;
      n.darkMode !== i.darkMode && this.onDarkModeChanged(n.darkMode, i.darkMode), n.language !== i.language && this.onLanguageChanged(n.language, i.language), n.networkMode !== i.networkMode && this.onNetworkModeChanged(n.networkMode, i.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized({ widgetInfo: this.spCtx.widgetInfo, customParam: this.spCtx.customParam });
  }
  onInitialized(t) {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, i) {
  }
  onLanguageChanged(t, i) {
  }
  onNetworkModeChanged(t, i) {
  }
  render() {
    return St``;
  }
}
ge.properties = { spCtx: { type: Object, attribute: !1 } };
const v = 100, is = 60 * 1e3, m = {
  create() {
    return { hunger: 80, happiness: 80, affection: 50, health: 100, lastUpdate: Date.now() };
  },
  decay(s) {
    const t = Date.now() - s.lastUpdate, i = Math.floor(t / is);
    if (i <= 0) return s;
    const n = Math.max(0, s.hunger - i * 2), r = Math.max(0, s.happiness - i), o = n === 0 ? i : 0, e = Math.max(0, s.health - o);
    return { ...s, hunger: n, happiness: r, health: e, lastUpdate: Date.now() };
  },
  // 喂食 - 返回 { state, result: 'ok'|'full'|'refuse'|'sick', msg }
  feed(s) {
    const t = this.decay(s);
    if (t.health < 20) return { state: t, result: "sick", msg: "生病了..." };
    if (t.affection < 20) return { state: t, result: "refuse", msg: "不想吃你的东西！" };
    if (t.hunger >= 95) return { state: t, result: "full", msg: "吃不下了~" };
    const i = t.hunger > 80 ? 10 : 25;
    return {
      state: { ...t, hunger: Math.min(v, t.hunger + i), happiness: Math.min(v, t.happiness + 5), affection: Math.min(v, t.affection + 2) },
      result: "ok",
      msg: `饱食+${i}`
    };
  },
  // 玩耍
  play(s) {
    const t = this.decay(s);
    return t.health < 20 ? { state: t, result: "sick", msg: "没力气玩..." } : t.hunger < 20 ? { state: t, result: "hungry", msg: "太饿了，先吃东西..." } : t.affection < 15 ? { state: t, result: "refuse", msg: "不想跟你玩！" } : {
      state: { ...t, hunger: Math.max(0, t.hunger - 8), happiness: Math.min(v, t.happiness + 20), affection: Math.min(v, t.affection + 5) },
      result: "ok",
      msg: "心情+20"
    };
  },
  // 抚摸
  pet(s) {
    const t = this.decay(s);
    if (t.health < 10) return { state: t, result: "sick", msg: "..." };
    if (t.affection < 10 && Math.random() < 0.5) return { state: t, result: "refuse", msg: "别碰我！" };
    const i = t.affection < 30 ? 5 : 3;
    return {
      state: { ...t, happiness: Math.min(v, t.happiness + 10), affection: Math.min(v, t.affection + i) },
      result: "ok",
      msg: `好感+${i}`
    };
  },
  // 治疗（当健康值低时）
  heal(s) {
    const t = this.decay(s);
    return t.health >= 80 ? { state: t, result: "healthy", msg: "很健康哦~" } : {
      state: { ...t, health: Math.min(v, t.health + 30), happiness: Math.min(v, t.happiness + 10) },
      result: "ok",
      msg: "健康+30"
    };
  },
  getMood(s) {
    const t = this.decay(s);
    if (t.health < 20) return "sick";
    if (t.hunger < 15) return "hungry";
    const i = (t.hunger + t.happiness) / 2;
    return i >= 70 ? "happy" : i >= 40 ? "idle" : i >= 20 ? "sad" : "sleep";
  },
  isDead(s) {
    return this.decay(s).health <= 0;
  }
}, Vt = {
  cat: { main: "#ff9f43", light: "#ffd699", dark: "#e89b3a", white: "#fff8f0", pink: "#ffb6c1", eye: "#2d5016", nose: "#ff8fab", blush: "#ffc0cb" },
  dog: { main: "#c4a574", light: "#e8d4b8", dark: "#a08050", white: "#fff8f0", pink: "#ffb6c1", eye: "#3d2914", nose: "#3d3d3d", blush: "#ffc0cb" },
  bunny: { main: "#fafafa", light: "#ffffff", dark: "#e0e0e0", white: "#fff8f0", pink: "#ffb6c1", eye: "#3d2914", nose: "#ffb6c1", blush: "#ffc0cb" },
  bird: { main: "#7ec8e3", light: "#a8dff0", dark: "#5eb3d0", white: "#fff8f0", pink: "#ffb6c1", eye: "#3d2914", nose: "#ffb347", blush: "#ffc0cb" },
  panda: { main: "#ffffff", light: "#f8f8f8", dark: "#2d2d2d", white: "#ffffff", pink: "#ffb6c1", eye: "#ffffff", nose: "#2d2d2d", blush: "#ffc0cb" },
  hamster: { main: "#f5d4a8", light: "#fae8d0", dark: "#e8c090", white: "#fff8f0", pink: "#ffb6c1", eye: "#3d2914", nose: "#ffb6c1", blush: "#ffc0cb" }
}, f = (s, t, i, n, r) => `<ellipse cx="${s}" cy="${t}" rx="${i}" ry="${n}" fill="${r}"/>`, G = 2, d = (s, t, i) => `<rect x="${s * G}" y="${t * G}" width="${G}" height="${G}" fill="${i}"/>`;
function ns(s, t, i) {
  const n = i % 4, r = i % 8, o = i % 12, e = r < 4 ? 0 : 1, a = n < 2 ? 0 : -1, p = o < 2, l = r < 2;
  let h = "";
  h += `<path d="M14 ${20 + a} L20 8 L26 ${20 + a} Z" fill="${s.main}"/>`, h += `<path d="M38 ${20 + a} L44 8 L50 ${20 + a} Z" fill="${s.main}"/>`, h += `<path d="M17 ${18 + a} L20 10 L23 ${18 + a} Z" fill="${s.pink}"/>`, h += `<path d="M41 ${18 + a} L44 10 L47 ${18 + a} Z" fill="${s.pink}"/>`, h += f(32, 30 + e, 18, 14, s.main), t === "sleep" ? (h += `<path d="M24 ${28 + e} L30 ${28 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${28 + e} L40 ${28 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (t === "happy" || t === "eat") && l ? (h += `<path d="M24 ${30 + e} Q27 ${26 + e} 30 ${30 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${30 + e} Q37 ${26 + e} 40 ${30 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : p ? (h += `<path d="M24 ${28 + e} L30 ${28 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${28 + e} L40 ${28 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (h += f(27, 28 + e, 4, 5, "#90EE90"), h += f(37, 28 + e, 4, 5, "#90EE90"), h += `<ellipse cx="27" cy="${28 + e}" rx="1.5" ry="3.5" fill="${s.eye}"/>`, h += `<ellipse cx="37" cy="${28 + e}" rx="1.5" ry="3.5" fill="${s.eye}"/>`), h += `<path d="M12 ${32 + e} L24 ${30 + e} M10 ${36 + e} L24 ${34 + e}" stroke="#666" stroke-width="0.8" fill="none"/>`, h += `<path d="M52 ${32 + e} L40 ${30 + e} M54 ${36 + e} L40 ${34 + e}" stroke="#666" stroke-width="0.8" fill="none"/>`, h += f(20, 34 + e, 3, 2, s.blush), h += f(44, 34 + e, 3, 2, s.blush), h += `<path d="M30 ${36 + e} L32 ${38 + e} L34 ${36 + e} Z" fill="${s.nose}"/>`, h += `<path d="M32 ${38 + e} L32 ${40 + e} M29 ${42 + e} Q32 ${44 + e} 35 ${42 + e}" stroke="#333" stroke-width="1" fill="none"/>`, h += f(32, 52 + e, 12, 10, s.main);
  const c = n < 2 ? 0 : 2, u = n < 2 ? 2 : 0;
  h += f(24, 58 + e + c, 4, 3, s.main), h += f(40, 58 + e + u, 4, 3, s.main);
  const $ = Math.sin(i * 0.4) * 6;
  return h += `<path d="M44 ${52 + e} Q${52 + $} ${46 + e} ${50 + $} ${38 + e}" stroke="${s.main}" stroke-width="4" fill="none" stroke-linecap="round"/>`, h;
}
function rs(s, t, i) {
  const n = i % 4, r = i % 8, o = i % 12, e = r < 4 ? 0 : 1, a = n < 2 ? 0 : 1, p = o < 2, l = r < 2;
  let h = "";
  h += f(14, 26 + a, 6, 12, s.dark), h += f(50, 26 + a, 6, 12, s.dark), h += f(32, 28 + e, 16, 12, s.main), h += f(32, 36 + e, 8, 6, s.light), t === "sleep" ? (h += `<path d="M24 ${26 + e} L30 ${26 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${26 + e} L40 ${26 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (t === "happy" || t === "eat") && l ? (h += `<path d="M24 ${28 + e} Q27 ${24 + e} 30 ${28 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${28 + e} Q37 ${24 + e} 40 ${28 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : p ? (h += `<path d="M24 ${26 + e} L30 ${26 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${26 + e} L40 ${26 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (h += `<circle cx="27" cy="${26 + e}" r="4" fill="#fff"/>`, h += `<circle cx="37" cy="${26 + e}" r="4" fill="#fff"/>`, h += `<circle cx="28" cy="${26 + e}" r="2.5" fill="${s.eye}"/>`, h += `<circle cx="38" cy="${26 + e}" r="2.5" fill="${s.eye}"/>`, h += `<circle cx="26" cy="${25 + e}" r="1" fill="#fff"/>`, h += `<circle cx="36" cy="${25 + e}" r="1" fill="#fff"/>`), h += f(32, 36 + e, 3, 2.5, s.nose), h += `<path d="M28 ${40 + e} Q32 ${44 + e} 36 ${40 + e}" stroke="#e57373" stroke-width="2" fill="none" stroke-linecap="round"/>`, h += f(32, 52 + e, 12, 10, s.main);
  const c = n < 2 ? 0 : 2, u = n < 2 ? 2 : 0;
  h += f(24, 58 + e + c, 4, 3, s.main), h += f(40, 58 + e + u, 4, 3, s.main);
  const $ = t === "happy" ? Math.sin(i * 0.8) * 10 : Math.sin(i * 0.3) * 5;
  return h += `<path d="M44 ${50 + e} Q${52 + $} ${44 + e} ${50 + $} ${36 + e}" stroke="${s.main}" stroke-width="4" fill="none" stroke-linecap="round"/>`, h;
}
function os(s, t, i) {
  const n = i % 4, r = i % 8, o = i % 12, e = r < 4 ? 0 : 1, a = n < 2 ? 0 : -1, p = o < 2, l = r < 2;
  let h = "";
  h += `<ellipse cx="24" cy="${18 + a}" rx="4" ry="12" fill="${s.main}"/>`, h += `<ellipse cx="40" cy="16" rx="4" ry="12" fill="${s.main}"/>`, h += `<ellipse cx="24" cy="${18 + a}" rx="2.5" ry="9" fill="${s.pink}"/>`, h += `<ellipse cx="40" cy="16" rx="2.5" ry="9" fill="${s.pink}"/>`, h += f(32, 36 + e, 16, 14, s.main), h += f(32, 40 + e, 10, 8, s.light), t === "sleep" ? (h += `<path d="M25 ${34 + e} L30 ${34 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${34 + e} L39 ${34 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (t === "happy" || t === "eat") && l ? (h += `<path d="M25 ${36 + e} Q27.5 ${32 + e} 30 ${36 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${36 + e} Q36.5 ${32 + e} 39 ${36 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : p ? (h += `<path d="M25 ${34 + e} L30 ${34 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, h += `<path d="M34 ${34 + e} L39 ${34 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (h += f(27, 34 + e, 3.5, 4, "#ff6b81"), h += f(37, 34 + e, 3.5, 4, "#ff6b81"), h += `<circle cx="28" cy="${34 + e}" r="2" fill="${s.eye}"/>`, h += `<circle cx="38" cy="${34 + e}" r="2" fill="${s.eye}"/>`, h += `<circle cx="26" cy="${33 + e}" r="1" fill="#fff"/>`, h += `<circle cx="36" cy="${33 + e}" r="1" fill="#fff"/>`), h += f(20, 40 + e, 3, 2, s.blush), h += f(44, 40 + e, 3, 2, s.blush), h += `<ellipse cx="32" cy="${42 + e}" rx="2" ry="1.5" fill="${s.nose}"/>`, h += `<path d="M30 ${44 + e} L32 ${46 + e} L34 ${44 + e}" stroke="${s.eye}" stroke-width="1" fill="none"/>`, h += f(32, 54 + e, 12, 8, s.main);
  const c = n < 2 ? 0 : -2;
  return h += f(24, 60 + e + c, 5, 3, s.main), h += f(40, 60 + e, 5, 3, s.main), h;
}
function as(s, t, i) {
  const n = i % 4, r = i % 8, o = i % 12, e = r < 4 ? 0 : 2, a = o < 2, p = r < 2;
  let l = "";
  l += `<path d="M28 ${12 - e} L32 ${6 - e} L36 ${12 - e}" fill="${s.light}"/>`, l += f(32, 22 + e, 12, 10, s.main), t === "sleep" ? (l += `<path d="M25 ${21 + e} L29 ${21 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, l += `<path d="M35 ${21 + e} L39 ${21 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (t === "happy" || t === "eat") && p ? (l += `<path d="M25 ${23 + e} Q27 ${19 + e} 29 ${23 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, l += `<path d="M35 ${23 + e} Q37 ${19 + e} 39 ${23 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : a ? (l += `<path d="M25 ${21 + e} L29 ${21 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, l += `<path d="M35 ${21 + e} L39 ${21 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (l += `<circle cx="27" cy="${21 + e}" r="3" fill="#fff"/>`, l += `<circle cx="37" cy="${21 + e}" r="3" fill="#fff"/>`, l += `<circle cx="28" cy="${21 + e}" r="2" fill="${s.eye}"/>`, l += `<circle cx="38" cy="${21 + e}" r="2" fill="${s.eye}"/>`);
  const h = (t === "eat" || t === "happy") && n < 2;
  return l += `<path d="M29 ${26 + e} L32 ${30 + e} L35 ${26 + e} Z" fill="${s.nose}"/>`, h && (l += `<path d="M30 ${30 + e} L32 ${34 + e} L34 ${30 + e} Z" fill="#ffcc80"/>`), l += f(32, 44 + e, 10, 12, s.main), l += f(32, 46 + e, 7, 8, s.light), n < 2 ? (l += `<ellipse cx="20" cy="${40 + e}" rx="5" ry="8" fill="${s.main}" transform="rotate(-20 20 ${40 + e})"/>`, l += `<ellipse cx="44" cy="${40 + e}" rx="5" ry="8" fill="${s.main}" transform="rotate(20 44 ${40 + e})"/>`) : (l += `<ellipse cx="20" cy="${48 + e}" rx="4" ry="6" fill="${s.main}" transform="rotate(-10 20 ${48 + e})"/>`, l += `<ellipse cx="44" cy="${48 + e}" rx="4" ry="6" fill="${s.main}" transform="rotate(10 44 ${48 + e})"/>`), l += `<path d="M28 ${54 + e} L26 ${60 + e} M28 ${54 + e} L28 ${60 + e} M28 ${54 + e} L30 ${60 + e}" stroke="${s.nose}" stroke-width="2"/>`, l += `<path d="M36 ${54 + e} L34 ${60 + e} M36 ${54 + e} L36 ${60 + e} M36 ${54 + e} L38 ${60 + e}" stroke="${s.nose}" stroke-width="2"/>`, l;
}
function ls(s, t, i) {
  const n = i % 4, r = i % 8, o = i % 12, e = r < 4 ? 0 : 1, a = o < 2, p = r < 2;
  let l = "";
  l += `<circle cx="16" cy="16" r="7" fill="${s.dark}"/>`, l += `<circle cx="48" cy="16" r="7" fill="${s.dark}"/>`, l += f(32, 30 + e, 18, 16, s.main), l += f(24, 28 + e, 7, 6, s.dark), l += f(40, 28 + e, 7, 6, s.dark), t === "sleep" ? (l += `<path d="M21 ${28 + e} L27 ${28 + e}" stroke="#fff" stroke-width="2" fill="none"/>`, l += `<path d="M37 ${28 + e} L43 ${28 + e}" stroke="#fff" stroke-width="2" fill="none"/>`) : (t === "happy" || t === "eat") && p ? (l += `<path d="M21 ${30 + e} Q24 ${26 + e} 27 ${30 + e}" stroke="#fff" stroke-width="2" fill="none"/>`, l += `<path d="M37 ${30 + e} Q40 ${26 + e} 43 ${30 + e}" stroke="#fff" stroke-width="2" fill="none"/>`) : a ? (l += `<path d="M21 ${28 + e} L27 ${28 + e}" stroke="#fff" stroke-width="2" fill="none"/>`, l += `<path d="M37 ${28 + e} L43 ${28 + e}" stroke="#fff" stroke-width="2" fill="none"/>`) : (l += `<circle cx="24" cy="${28 + e}" r="3" fill="#fff"/>`, l += `<circle cx="40" cy="${28 + e}" r="3" fill="#fff"/>`, l += `<circle cx="24" cy="${28 + e}" r="1.5" fill="#333"/>`, l += `<circle cx="40" cy="${28 + e}" r="1.5" fill="#333"/>`), l += f(32, 36 + e, 3, 2, s.nose), l += `<path d="M29 ${39 + e} Q32 ${42 + e} 35 ${39 + e}" stroke="${s.dark}" stroke-width="1.5" fill="none"/>`, l += f(18, 36 + e, 3, 2, s.blush), l += f(46, 36 + e, 3, 2, s.blush), l += f(32, 52 + e, 14, 10, s.main), l += f(18, 50 + e, 5, 7, s.dark), l += f(46, 50 + e, 5, 7, s.dark);
  const h = n < 2 ? 0 : 2;
  return l += f(24, 58 + e + h, 5, 3, s.dark), l += f(40, 58 + e, 5, 3, s.dark), l;
}
function hs(s, t, i) {
  const n = i % 4, r = i % 8, o = i % 12, e = r < 4 ? 0 : 1, a = o < 2, p = r < 2;
  let l = "";
  l += `<circle cx="18" cy="18" r="5" fill="${s.main}"/>`, l += `<circle cx="46" cy="18" r="5" fill="${s.main}"/>`, l += `<circle cx="18" cy="18" r="3" fill="${s.pink}"/>`, l += `<circle cx="46" cy="18" r="3" fill="${s.pink}"/>`, l += f(32, 32 + e, 16, 14, s.main), l += f(16, 36 + e, 5, 4, s.light), l += f(48, 36 + e, 5, 4, s.light), t === "sleep" ? (l += `<path d="M25 ${30 + e} L30 ${30 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, l += `<path d="M34 ${30 + e} L39 ${30 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (t === "happy" || t === "eat") && p ? (l += `<path d="M25 ${32 + e} Q27.5 ${28 + e} 30 ${32 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, l += `<path d="M34 ${32 + e} Q36.5 ${28 + e} 39 ${32 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : a ? (l += `<path d="M25 ${30 + e} L30 ${30 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`, l += `<path d="M34 ${30 + e} L39 ${30 + e}" stroke="${s.eye}" stroke-width="2" fill="none"/>`) : (l += `<circle cx="27" cy="${30 + e}" r="3" fill="#fff"/>`, l += `<circle cx="37" cy="${30 + e}" r="3" fill="#fff"/>`, l += `<circle cx="28" cy="${30 + e}" r="2" fill="${s.eye}"/>`, l += `<circle cx="38" cy="${30 + e}" r="2" fill="${s.eye}"/>`, l += `<circle cx="26" cy="${29 + e}" r="1" fill="#fff"/>`, l += `<circle cx="36" cy="${29 + e}" r="1" fill="#fff"/>`), l += f(22, 36 + e, 3, 2, s.blush), l += f(42, 36 + e, 3, 2, s.blush), l += f(32, 38 + e, 2, 1.5, s.nose), l += `<path d="M30 ${40 + e} Q32 ${42 + e} 34 ${40 + e}" stroke="${s.eye}" stroke-width="1" fill="none"/>`, l += f(32, 52 + e, 12, 10, s.main), l += f(32, 54 + e, 8, 6, s.light);
  const h = n < 2 ? 0 : 2;
  return l += f(24, 58 + e + h, 4, 3, s.pink), l += f(40, 58 + e, 4, 3, s.pink), l;
}
function ps(s, t, i) {
  const n = i % 8, r = n < 4 ? 0 : 1;
  let o = "";
  for (let e = 0; e < 3; e++)
    o += d(8 + e, 4 - e, s.main), o += d(22 - e, 4 - e, s.main);
  for (let e = 6; e < 14; e++) for (let a = 6; a < 26; a++) o += d(a, e + r, s.main);
  t === "sleep" || t === "happy" ? (o += d(10, 9 + r, s.eye), o += d(11, 9 + r, s.eye), o += d(19, 9 + r, s.eye), o += d(20, 9 + r, s.eye)) : (o += d(10, 8 + r, s.eye), o += d(10, 9 + r, s.eye), o += d(20, 8 + r, s.eye), o += d(20, 9 + r, s.eye)), o += d(15, 11 + r, s.nose), o += d(14, 12 + r, s.eye), o += d(16, 12 + r, s.eye);
  for (let e = 14; e < 22; e++) for (let a = 8; a < 24; a++) o += d(a, e + r, s.main);
  for (let e = 8; e < 12; e++) o += d(e, 22 + r, s.main);
  for (let e = 20; e < 24; e++) o += d(e, 22 + r, s.main);
  for (let e = 0; e < 4; e++) o += d(24 + e, 18 - e + r, s.main);
  return o;
}
function ds(s, t, i) {
  const n = i % 8, r = n < 4 ? 0 : 1;
  let o = "";
  for (let e = 6; e < 14; e++)
    o += d(4, e, s.dark), o += d(5, e, s.dark), o += d(25, e, s.dark), o += d(26, e, s.dark);
  for (let e = 5; e < 13; e++) for (let a = 7; a < 25; a++) o += d(a, e + r, s.main);
  t === "sleep" || t === "happy" ? (o += d(11, 8 + r, s.eye), o += d(12, 8 + r, s.eye), o += d(19, 8 + r, s.eye), o += d(20, 8 + r, s.eye)) : (o += d(11, 7 + r, "#fff"), o += d(12, 8 + r, s.eye), o += d(19, 7 + r, "#fff"), o += d(20, 8 + r, s.eye));
  for (let e = 14; e < 18; e++) o += d(e, 10 + r, s.light);
  o += d(15, 11 + r, s.nose), o += d(16, 11 + r, s.nose);
  for (let e = 13; e < 21; e++) for (let a = 9; a < 23; a++) o += d(a, e + r, s.main);
  for (let e = 9; e < 13; e++) o += d(e, 21 + r, s.main);
  for (let e = 19; e < 23; e++) o += d(e, 21 + r, s.main);
  for (let e = 0; e < 3; e++) o += d(23 + e, 15 - e + r, s.main);
  return o;
}
function cs(s, t, i) {
  const n = i % 8, r = n < 4 ? 0 : 1;
  let o = "";
  for (let e = 0; e < 10; e++)
    o += d(10, e, s.main), o += d(11, e, s.main), o += d(20, e, s.main), o += d(21, e, s.main);
  for (let e = 2; e < 8; e++)
    o += d(10, e, s.pink), o += d(20, e, s.pink);
  for (let e = 10; e < 18; e++) for (let a = 7; a < 25; a++) o += d(a, e + r, s.main);
  o += d(11, 13 + r, "#ff6b81"), o += d(12, 13 + r, s.eye), o += d(19, 13 + r, "#ff6b81"), o += d(20, 13 + r, s.eye), o += d(15, 15 + r, s.nose), o += d(16, 15 + r, s.nose);
  for (let e = 18; e < 24; e++) for (let a = 9; a < 23; a++) o += d(a, e + r, s.main);
  for (let e = 9; e < 14; e++) o += d(e, 24 + r, s.main);
  for (let e = 18; e < 23; e++) o += d(e, 24 + r, s.main);
  return o;
}
function fs(s, t, i) {
  const n = i % 4, r = i % 8, o = r < 4 ? 0 : 1;
  let e = "";
  e += d(15, 2 - o, s.light), e += d(16, 2 - o, s.light), e += d(15, 3 - o, s.light), e += d(16, 3 - o, s.light);
  for (let p = 4; p < 12; p++) for (let l = 10; l < 22; l++) e += d(l, p + o, s.main);
  e += d(12, 7 + o, "#fff"), e += d(13, 7 + o, s.eye), e += d(18, 7 + o, "#fff"), e += d(19, 7 + o, s.eye), e += d(15, 10 + o, s.nose), e += d(16, 10 + o, s.nose), e += d(15, 11 + o, s.nose);
  for (let p = 12; p < 22; p++) for (let l = 11; l < 21; l++) e += d(l, p + o, s.main);
  const a = n < 2 ? 14 : 16;
  for (let p = a; p < a + 4; p++)
    e += d(8, p + o, s.main), e += d(9, p + o, s.main), e += d(22, p + o, s.main), e += d(23, p + o, s.main);
  return e += d(13, 22 + o, s.nose), e += d(14, 22 + o, s.nose), e += d(17, 22 + o, s.nose), e += d(18, 22 + o, s.nose), e;
}
function us(s, t, i) {
  const n = i % 8, r = n < 4 ? 0 : 1;
  let o = "";
  for (let e = 2; e < 6; e++) for (let a = 5; a < 9; a++) o += d(a, e, s.dark);
  for (let e = 2; e < 6; e++) for (let a = 23; a < 27; a++) o += d(a, e, s.dark);
  for (let e = 6; e < 16; e++) for (let a = 6; a < 26; a++) o += d(a, e + r, s.main);
  for (let e = 8; e < 12; e++) for (let a = 8; a < 13; a++) o += d(a, e + r, s.dark);
  for (let e = 8; e < 12; e++) for (let a = 19; a < 24; a++) o += d(a, e + r, s.dark);
  o += d(10, 10 + r, "#fff"), o += d(21, 10 + r, "#fff"), o += d(15, 13 + r, s.dark), o += d(16, 13 + r, s.dark);
  for (let e = 16; e < 24; e++) for (let a = 8; a < 24; a++) o += d(a, e + r, s.main);
  for (let e = 17; e < 22; e++)
    o += d(6, e + r, s.dark), o += d(7, e + r, s.dark), o += d(24, e + r, s.dark), o += d(25, e + r, s.dark);
  for (let e = 9; e < 13; e++) o += d(e, 24 + r, s.dark);
  for (let e = 19; e < 23; e++) o += d(e, 24 + r, s.dark);
  return o;
}
function $s(s, t, i) {
  const n = i % 8, r = n < 4 ? 0 : 1;
  let o = "";
  for (let e = 4; e < 8; e++)
    o += d(6, e, s.main), o += d(7, e, s.pink), o += d(24, e, s.main), o += d(25, e, s.pink);
  for (let e = 8; e < 18; e++) for (let a = 6; a < 26; a++) o += d(a, e + r, s.main);
  for (let e = 12; e < 16; e++)
    o += d(4, e + r, s.light), o += d(5, e + r, s.light), o += d(26, e + r, s.light), o += d(27, e + r, s.light);
  o += d(11, 11 + r, "#fff"), o += d(12, 12 + r, s.eye), o += d(19, 11 + r, "#fff"), o += d(20, 12 + r, s.eye), o += d(9, 14 + r, s.blush), o += d(22, 14 + r, s.blush), o += d(15, 14 + r, s.nose), o += d(16, 14 + r, s.nose);
  for (let e = 18; e < 24; e++) for (let a = 10; a < 22; a++) o += d(a, e + r, s.main);
  for (let e = 10; e < 14; e++) o += d(e, 24 + r, s.pink);
  for (let e = 18; e < 22; e++) o += d(e, 24 + r, s.pink);
  return o;
}
function vt(s = "cat", t = "idle", i = 0, n = "cute") {
  const r = Vt[s] || Vt.cat;
  let o = "";
  return n === "pixel" ? s === "dog" ? o = ds(r, t, i) : s === "bunny" ? o = cs(r, t, i) : s === "bird" ? o = fs(r, t, i) : s === "panda" ? o = us(r, t, i) : s === "hamster" ? o = $s(r, t, i) : o = ps(r, t, i) : s === "dog" ? o = rs(r, t, i) : s === "bunny" ? o = os(r, t, i) : s === "bird" ? o = as(r, t, i) : s === "panda" ? o = ls(r, t, i) : s === "hamster" ? o = hs(r, t, i) : o = ns(r, t, i), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 68"><g ${t === "jump" ? `transform="translate(0,${i % 2 ? -4 : 0})"` : ""}>${o}</g></svg>`;
}
const yt = {
  cat: { name: "小猫咪", emoji: "🐱" },
  dog: { name: "小狗狗", emoji: "🐶" },
  bunny: { name: "小兔子", emoji: "🐰" },
  bird: { name: "小鸟儿", emoji: "🐦" },
  panda: { name: "小熊猫", emoji: "🐼" },
  hamster: { name: "小仓鼠", emoji: "🐹" }
}, Yt = {
  cheerful: {
    name: "开朗",
    greeting: "今天也要元气满满哦！",
    traits: { talkative: 0.8, playful: 0.9, needy: 0.5 }
  },
  shy: {
    name: "害羞",
    greeting: "那个...你好呀...",
    traits: { talkative: 0.3, playful: 0.4, needy: 0.7 }
  },
  lazy: {
    name: "慵懒",
    greeting: "唔...让我再睡会儿...",
    traits: { talkative: 0.4, playful: 0.3, needy: 0.6 }
  },
  tsundere: {
    name: "傲娇",
    greeting: "哼，才不是特意来见你的！",
    traits: { talkative: 0.6, playful: 0.7, needy: 0.8 }
  }
}, Kt = {
  idle: {
    cheerful: ["在想什么呢~", "今天天气真好！", "陪我玩嘛~", "嘿嘿~", "主人在干嘛呀？", "好无聊啊~", "想出去玩！", "你看起来很忙呢", "我在这里哦~"],
    shy: ["...", "那个...", "你在看我吗...", "...嗯", "...今天也请多关照", "...我会乖乖的", "..."],
    lazy: ["好困...", "想睡觉...", "唔...", "...zzZ", "不想动...", "躺着真舒服...", "再让我睡会儿..."],
    tsundere: ["别盯着我看！", "哼~", "无聊死了", "才没有想你！", "你又来了啊", "哼，随便你", "才不是在等你！"]
  },
  hungry: {
    cheerful: ["肚子饿了~", "想吃好吃的！", "有零食吗？", "饿饿...", "咕噜咕噜~", "好想吃东西！", "主人~饭饭~"],
    shy: ["那个...有点饿...", "可以...吃东西吗...", "...肚子叫了...", "...想吃..."],
    lazy: ["饿...但不想动...", "喂我...", "饿死了...", "食物...在哪..."],
    tsundere: ["才不是饿了！只是...有点想吃东西", "哼，你要喂我也不是不可以", "别误会！只是顺便吃一下"]
  },
  happy: {
    cheerful: ["太开心了！", "最喜欢你了！", "耶~", "今天心情超好！", "和主人在一起最开心了！", "嘻嘻~"],
    shy: ["谢谢你...", "好开心...", "嘿嘿...", "...很幸福", "...喜欢和你在一起"],
    lazy: ["还不错~", "舒服~", "嗯~满足~", "这样挺好的~"],
    tsundere: ["哼，勉强接受！", "才没有很开心！", "...也不是讨厌你啦", "别得意！"]
  },
  sad: {
    cheerful: ["呜...不开心...", "陪陪我嘛...", "为什么不理我...", "好寂寞..."],
    shy: ["...难过...", "...呜...", "...不要丢下我...", "..."],
    lazy: ["唉...", "没力气了...", "好累...", "..."],
    tsundere: ["才没有难过！眼睛只是进沙子了！", "哼...", "才不需要你安慰！", "...走开"]
  },
  sick: {
    cheerful: ["不舒服...", "头晕晕的...", "需要休息...", "好难受...", "主人..."],
    shy: ["...难受...", "...呜...", "...帮帮我...", "...好冷..."],
    lazy: ["好难受...", "...", "动不了...", "...救命..."],
    tsundere: ["才...才没有生病...咳咳", "不用担心我！咳...", "我自己能好！...大概"]
  },
  refuse: {
    cheerful: ["现在不想要~", "等下再说吧~", "太撑了~", "休息一下~"],
    shy: ["不...不要...", "...", "...现在不行...", "...太多了..."],
    lazy: ["不想...", "懒得理你...", "别烦我...", "让我静静..."],
    tsundere: ["哼！不要！", "走开！", "别烦我！", "你烦不烦啊！"]
  },
  pet: {
    cheerful: ["好舒服~", "再摸摸~", "喵~", "这里这里~", "继续继续~", "最喜欢被摸了！"],
    shy: ["啊...那里...", "好...好害羞...", "...嗯...", "...不要停...", "...喜欢..."],
    lazy: ["嗯~继续~", "别停...", "就是这里...", "好舒服...不想动了..."],
    tsundere: ["哼！才不是喜欢被摸！", "...再摸一下也可以", "别...别停啊！", "...哼"]
  },
  feed: {
    cheerful: ["好吃！", "还要还要！", "谢谢投喂~", "太美味了！", "主人最好了！"],
    shy: ["谢谢...", "好好吃...", "...满足", "...还想要..."],
    lazy: ["唔姆唔姆...", "好吃...", "吃饱了...", "...打嗝"],
    tsundere: ["勉强能吃！", "不是很好吃啦...骗你的", "哼，下次要更好吃的！", "...其实挺好吃的"]
  },
  play: {
    cheerful: ["好玩好玩！", "再来再来！", "耶~", "太有趣了！", "还要玩！"],
    shy: ["这个...好有趣...", "还可以玩吗...", "...好开心...", "...再玩一次..."],
    lazy: ["累了...休息下...", "玩够了...", "好累但好开心...", "...歇会儿"],
    tsundere: ["哼，就玩一下！", "才没有很开心！", "...再玩一局也行", "你技术太差了！"]
  }
};
function ys(s, t) {
  var n;
  const i = ((n = Kt[s]) == null ? void 0 : n[t]) || Kt.idle[t] || ["..."];
  return i[Math.floor(Math.random() * i.length)];
}
class be extends ye {
  constructor() {
    super(), this.state = m.create(), this.action = "idle", this.frame = 0, this.dialogue = "", this.showBubble = !1, this.config = {}, this.lastChange = "", this.changeColor = "#22c55e", this.hovering = !1, this.petX = 80, this.petDir = 1, this.inScene = !1, this.sceneIdx = Math.floor(Math.random() * 4);
  }
  get petType() {
    return this.config.petType || "cat";
  }
  get petName() {
    return this.config.petName || "宠物";
  }
  get personality() {
    return this.config.personality || "cheerful";
  }
  get tagStyle() {
    return this.config.tagStyle || 0;
  }
  get petStyle() {
    return this.config.petStyle || "cute";
  }
  get stateKey() {
    var t;
    return `state-${((t = this.spCtx.widgetInfo) == null ? void 0 : t.id) || "default"}`;
  }
  async onInitialized() {
    var t;
    this.makeTransparent(), this.config = ((t = this.spCtx.widgetInfo) == null ? void 0 : t.config) || {};
    try {
      const i = await this.spCtx.api.dataNode.app.getByKey("pet-state", this.stateKey);
      console.log("[pet] loaded:", this.stateKey, i), i && i.hunger !== void 0 && (this.state = m.decay(i));
    } catch (i) {
      console.log("[pet] load error:", i);
    }
    this._timer = setInterval(() => {
      this.state = m.decay(this.state), this.maybeSpeak(), this.requestUpdate();
    }, 3e4), this._animTimer = setInterval(() => {
      this.frame = (this.frame + 1) % 24, this.action === "idle" && Math.random() < 0.25 && (this.petX += this.petDir * 10, this.petX > 300 && (this.petX = 300, this.petDir = -1), this.petX < 20 && (this.petX = 20, this.petDir = 1), this.inScene = this.petX > 160), this.requestUpdate();
    }, 250), setTimeout(() => this.speak(m.getMood(this.state)), 2e3);
  }
  onWidgetInfoChanged(t) {
    this.config = (t == null ? void 0 : t.config) || {}, this.requestUpdate();
  }
  makeTransparent() {
    var i, n;
    let t = this.parentElement;
    for (; t; )
      ((i = t.classList) != null && i.contains("item-card-content") || (n = t.classList) != null && n.contains("widget-container")) && (t.style.background = "transparent", t.style.backgroundColor = "transparent"), t = t.parentElement;
  }
  onDisconnected() {
    clearInterval(this._timer), clearInterval(this._animTimer);
  }
  updated() {
    this.makeTransparent();
  }
  async save() {
    try {
      const t = await this.spCtx.api.dataNode.app.setByKey("pet-state", this.stateKey, this.state);
      console.log("[pet] save result:", t, "key:", this.stateKey, "state:", this.state);
    } catch (t) {
      console.log("[pet] save error:", t, t == null ? void 0 : t.code, t == null ? void 0 : t.message);
    }
  }
  speak(t) {
    this.dialogue = ys(t, this.personality), this.showBubble = !0, clearTimeout(this._bubbleTimer), this._bubbleTimer = setTimeout(() => {
      this.showBubble = !1, this.requestUpdate();
    }, 3e3);
  }
  maybeSpeak() {
    Math.random() < 0.4 && this.speak(m.getMood(this.state));
  }
  showChange(t, i = !0) {
    this.lastChange = t, this.changeColor = i ? "#22c55e" : "#ef4444", clearTimeout(this._changeTimer), this._changeTimer = setTimeout(() => {
      this.lastChange = "", this.requestUpdate();
    }, 1500);
  }
  async doAction(t, i, n) {
    const { state: r, result: o, msg: e } = t.call(m, this.state);
    this.state = r, o === "ok" ? (this.action = i, this.speak(n), this.showChange(e, !0)) : (this.action = "sad", this.speak("refuse"), this.showChange(e, !1)), await this.save(), setTimeout(() => {
      this.action = "idle", this.requestUpdate();
    }, 1500);
  }
  doFeed() {
    this.doAction(m.feed, "eat", "feed");
  }
  doPlay() {
    this.doAction(m.play, "jump", "play");
  }
  doPet() {
    this.doAction(m.pet, "happy", "pet");
  }
  doHeal() {
    this.doAction(m.heal, "happy", "happy");
  }
  get petSvg() {
    const t = this.action !== "idle" ? this.action : m.getMood(this.state);
    return vt(this.petType, t, this.frame, this.petStyle);
  }
  getMoodText(t) {
    return { happy: "😊 心情愉快", idle: "😐 状态一般", sad: "😢 有点难过", hungry: "🍽️ 肚子饿了", sick: "🤒 身体不适", sleep: "😴 昏昏欲睡" }[t] || "😐 状态一般";
  }
  getMoodDesc(t, i) {
    return t === "sick" ? `健康值过低，需要治疗恢复。当前健康: ${i.health}` : t === "hungry" ? `饱食度不足，快喂点东西吧！当前饱食: ${i.hunger}` : t === "happy" ? `${this.petName}现在很开心，继续保持互动吧~` : t === "sad" ? `心情不太好，多陪陪${this.petName}玩耍吧` : `${this.petName}状态还不错，记得定期互动哦`;
  }
  get baseStyle() {
    return `
      :host { display:block; width:100%; height:100%; }
      * { box-sizing:border-box; }
      @keyframes breathe { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-2px)} }
      @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
      @keyframes fadeUp { 0%{opacity:1;transform:translateY(0)} 100%{opacity:0;transform:translateY(-10px)} }
      @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-2px)} 75%{transform:translateX(2px)} }
      .wrap { position:relative; }
      .wrap:hover .float-btns { opacity:1; pointer-events:auto; }
      .pet-svg { cursor:pointer; transition:transform .15s; }
      .pet-svg:hover { transform:scale(1.05); }
      .pet-svg svg { width:100%; height:100%; animation: ${this.action === "jump" ? "bounce .25s infinite" : this.action === "sad" ? "shake .3s" : "breathe 2s ease-in-out infinite"}; }
      .bubble { position:absolute; background:#fff; padding:5px 12px; border-radius:12px; font-size:12px; box-shadow:0 2px 8px rgba(0,0,0,.15); white-space:nowrap; z-index:20; opacity:${this.showBubble ? 1 : 0}; transition:opacity .3s; pointer-events:none; }
      .change { position:absolute; font-size:12px; font-weight:600; animation:fadeUp 1.5s forwards; pointer-events:none; z-index:15; }
      .bar { height:5px; background:rgba(0,0,0,.08); border-radius:3px; overflow:hidden; cursor:pointer; }
      .bar-fill { height:100%; border-radius:3px; transition:width .3s; }
      .bar-wrap { position:relative; }
      .bar-wrap:hover .bar-tip { opacity:1; }
      .bar-tip { position:absolute; top:-22px; left:50%; transform:translateX(-50%); background:#333; color:#fff; padding:2px 6px; border-radius:4px; font-size:9px; white-space:nowrap; opacity:0; transition:opacity .2s; pointer-events:none; z-index:100; }
      .float-btns { position:absolute; display:flex; gap:6px; opacity:0; pointer-events:none; transition:opacity .2s; z-index:10; }
      .btn { position:relative; width:30px; height:30px; border:none; background:rgba(255,255,255,.95); border-radius:50%; cursor:pointer; box-shadow:0 2px 6px rgba(0,0,0,.12); font-size:13px; display:flex; align-items:center; justify-content:center; transition:all .15s; }
      .btn:hover { transform:scale(1.1); background:#fff; }
      .btn:active { transform:scale(0.95); }
      .btn:hover::after { content:attr(data-tip); position:absolute; bottom:100%; left:50%; transform:translateX(-50%); background:#333; color:#fff; padding:3px 8px; border-radius:4px; font-size:10px; white-space:nowrap; margin-bottom:4px; }
      .name-tag { display:inline-block; padding:2px 8px; font-size:10px; font-weight:600; }
      .tag-0 { background:#fff9e6; color:#d97706; border-radius:3px 8px 8px 3px; border:1.5px solid #fbbf24; border-left:3px solid #f59e0b; }
      .tag-1 { background:#e0f2fe; color:#0284c7; border-radius:10px; border:1.5px solid #7dd3fc; }
      .tag-2 { background:#fce7f3; color:#db2777; border-radius:0 8px 0 8px; border:1.5px solid #f9a8d4; }
      .tag-3 { background:#ecfccb; color:#65a30d; border-radius:8px 0 8px 0; border:1.5px solid #bef264; }
      .hunger .bar-fill { background:linear-gradient(90deg,#fbbf24,#f59e0b); }
      .happy .bar-fill { background:linear-gradient(90deg,#a78bfa,#8b5cf6); }
      .love .bar-fill { background:linear-gradient(90deg,#fb7185,#ef4444); }
      .health .bar-fill { background:linear-gradient(90deg,#34d399,#10b981); }
    `;
  }
  render2x2() {
    const t = this.state, i = t.health < 50;
    return b`
      <style>
        ${this.baseStyle}
        .wrap { width:174px; height:174px; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:4px; }
        .pet-area { position:relative; flex:1; display:flex; align-items:center; justify-content:center; width:100%; }
        .pet-svg { width:140px; height:140px; }
        .bubble { top:0; left:50%; transform:translateX(-50%); }
        .change { top:18px; left:50%; transform:translateX(-50%); color:${this.changeColor}; }
        .float-btns { bottom:5px; left:50%; transform:translateX(-50%); }
        .bottom { display:flex; align-items:center; gap:6px; }
        .bars { display:flex; gap:4px; }
        .bar { width:26px; }
        .bar-tip { top:auto; bottom:12px; }
      </style>
      <div class="wrap">
        <div class="pet-area">
          <div class="bubble">${this.dialogue}</div>
          <div class="pet-svg" @click=${() => this.doPet()} .innerHTML=${this.petSvg}></div>
          ${this.lastChange ? b`<div class="change">${this.lastChange}</div>` : ""}
          <div class="float-btns">
            <button class="btn" @click=${() => this.doFeed()} data-tip="喂食">🍖</button>
            <button class="btn" @click=${() => this.doPlay()} data-tip="玩耍">⚽</button>
            ${i ? b`<button class="btn" @click=${() => this.doHeal()} data-tip="治疗">💊</button>` : ""}
          </div>
        </div>
        <div class="bottom">
          <span class="name-tag tag-${this.tagStyle}">${this.petName}</span>
          <div class="bars">
            <div class="bar-wrap hunger"><div class="bar"><div class="bar-fill" style="width:${t.hunger}%"></div></div><span class="bar-tip">饱食 ${t.hunger}</span></div>
            <div class="bar-wrap happy"><div class="bar"><div class="bar-fill" style="width:${t.happiness}%"></div></div><span class="bar-tip">心情 ${t.happiness}</span></div>
            <div class="bar-wrap love"><div class="bar"><div class="bar-fill" style="width:${t.affection}%"></div></div><span class="bar-tip">好感 ${t.affection}</span></div>
            ${i ? b`<div class="bar-wrap health"><div class="bar"><div class="bar-fill" style="width:${t.health}%"></div></div><span class="bar-tip">健康 ${t.health}</span></div>` : ""}
          </div>
        </div>
      </div>
    `;
  }
  get sceneSvg() {
    return `<svg viewBox="0 0 196 174" xmlns="http://www.w3.org/2000/svg">${[
      '<circle fill="#fff" cx="40" cy="25" r="15" opacity=".7"/><circle fill="#fff" cx="55" cy="22" r="10" opacity=".7"/><circle fill="#fff" cx="150" cy="30" r="18" opacity=".6"/><circle fill="#fff" cx="168" cy="26" r="10" opacity=".6"/><ellipse fill="#90EE90" cx="98" cy="165" rx="100" ry="20" opacity=".4"/>',
      '<circle fill="#FFD700" cx="30" cy="20" r="2" opacity=".8"/><circle fill="#FFD700" cx="80" cy="35" r="1.5" opacity=".7"/><circle fill="#FFD700" cx="120" cy="15" r="2" opacity=".9"/><circle fill="#FFD700" cx="160" cy="40" r="1.5" opacity=".6"/><circle fill="#FFD700" cx="50" cy="50" r="1" opacity=".5"/><circle fill="#fff" cx="170" cy="25" r="12" opacity=".3"/>',
      '<path d="M20 140 Q98 60 176 140" stroke="#ff6b6b" stroke-width="6" fill="none" opacity=".3"/><path d="M25 140 Q98 70 171 140" stroke="#ffd93d" stroke-width="6" fill="none" opacity=".3"/><path d="M30 140 Q98 80 166 140" stroke="#6bcb77" stroke-width="6" fill="none" opacity=".3"/>',
      '<ellipse fill="#f39c12" cx="40" cy="60" rx="8" ry="4" opacity=".6" transform="rotate(30 40 60)"/><ellipse fill="#e74c3c" cx="100" cy="40" rx="6" ry="3" opacity=".5" transform="rotate(-20 100 40)"/><ellipse fill="#f39c12" cx="150" cy="80" rx="7" ry="3.5" opacity=".6" transform="rotate(45 150 80)"/><ellipse fill="#90EE90" cx="98" cy="165" rx="100" ry="20" opacity=".4"/>'
    ][this.sceneIdx || 0]}</svg>`;
  }
  render2x4() {
    const t = this.state, i = t.health < 50, n = this.petX;
    return b`
      <style>
        ${this.baseStyle}
        .wrap { width:370px; height:174px; position:relative; }
        .scene-bg { position:absolute; right:0; top:0; width:196px; height:174px; border-radius:0 12px 12px 0; overflow:hidden; }
        .scene-bg svg { width:100%; height:100%; }
        .home { position:absolute; left:0; top:0; width:174px; height:174px; }
        .moving-pet { position:absolute; bottom:20px; width:120px; height:120px; transition:left .3s; cursor:pointer; z-index:5; }
        .moving-pet svg { width:100%; height:100%; }
        .moving-pet.flip svg { transform:scaleX(-1); }
        .pet-bubble { position:absolute; bottom:95px; background:#fff; padding:4px 10px; border-radius:10px; font-size:11px; box-shadow:0 2px 6px rgba(0,0,0,.12); white-space:nowrap; z-index:10; opacity:${this.showBubble ? 1 : 0}; transition:opacity .3s, left .3s; }
        .change { bottom:100px; z-index:15; }
        .bottom { position:relative; z-index:2; display:flex; align-items:center; gap:6px; }
        .bars { display:flex; gap:4px; }
        .bar { width:26px; }
        .bar-tip { top:auto; bottom:12px; }
        .float-btns { position:absolute; bottom:5px; right:10px; transform:none; }
      </style>
      <div class="wrap">
        <div class="scene-bg" .innerHTML=${this.sceneSvg}></div>
        <div class="home"></div>
        <div class="pet-bubble" style="left:${n - 15}px">${this.dialogue}</div>
        <div class="moving-pet ${this.petDir < 0 ? "flip" : ""}" style="left:${n}px" @click=${() => this.doPet()} .innerHTML=${this.petSvg}></div>
        ${this.lastChange ? b`<div class="change" style="left:${n + 20}px;color:${this.changeColor}">${this.lastChange}</div>` : ""}
        <div class="float-btns">
          <button class="btn" @click=${() => this.doFeed()} data-tip="喂食">🍖</button>
          <button class="btn" @click=${() => this.doPlay()} data-tip="玩耍">⚽</button>
          ${i ? b`<button class="btn" @click=${() => this.doHeal()} data-tip="治疗">💊</button>` : ""}
        </div>
        <div class="bottom" style="position:absolute;bottom:4px;left:4px;">
          <span class="name-tag tag-${this.tagStyle}">${this.petName}</span>
          <div class="bars">
            <div class="bar-wrap hunger"><div class="bar"><div class="bar-fill" style="width:${t.hunger}%"></div></div><span class="bar-tip">饱食 ${t.hunger}</span></div>
            <div class="bar-wrap happy"><div class="bar"><div class="bar-fill" style="width:${t.happiness}%"></div></div><span class="bar-tip">心情 ${t.happiness}</span></div>
            <div class="bar-wrap love"><div class="bar"><div class="bar-fill" style="width:${t.affection}%"></div></div><span class="bar-tip">好感 ${t.affection}</span></div>
          </div>
        </div>
      </div>
    `;
  }
  render() {
    var i, n;
    return (((n = (i = this.spCtx) == null ? void 0 : i.widgetInfo) == null ? void 0 : n.gridSize) || "2x2") === "2x4" ? this.render2x4() : this.render2x2();
  }
}
at(be, "properties", {
  state: { type: Object },
  action: { type: String },
  frame: { type: Number },
  dialogue: { type: String },
  showBubble: { type: Boolean },
  config: { type: Object },
  lastChange: { type: String },
  changeColor: { type: String },
  hovering: { type: Boolean },
  petX: { type: Number },
  petDir: { type: Number },
  inScene: { type: Boolean }
});
class me extends ge {
  constructor() {
    super(), this.petType = "cat", this.petName = "", this.personality = "cheerful", this.tagStyle = 0, this.petStyle = "cute", this.step = 1;
  }
  async onInitialized({ widgetInfo: t }) {
    const i = (t == null ? void 0 : t.config) || {};
    i.petType && (this.petType = i.petType), i.petName && (this.petName = i.petName), i.personality && (this.personality = i.personality), i.tagStyle !== void 0 && (this.tagStyle = i.tagStyle), i.petStyle && (this.petStyle = i.petStyle), i.petName && (this.step = 3);
  }
  async save() {
    await this.spCtx.api.widget.save({
      ...this.spCtx.widgetInfo,
      config: { petType: this.petType, petName: this.petName, personality: this.personality, tagStyle: this.tagStyle, petStyle: this.petStyle }
    });
  }
  nextStep() {
    this.step === 1 && !this.petType || this.step === 2 && !this.petName.trim() || (this.step++, this.step > 3 && this.finish());
  }
  prevStep() {
    this.step > 1 && this.step--;
  }
  async finish() {
    await this.save(), this.spCtx.api.window.close();
  }
  render() {
    return b`
      <style>
        :host { display:block; width:100%; height:100%; }
        .wrap { padding:20px; font-family:system-ui; color:#333; height:100%; display:flex; flex-direction:column; justify-content:center; }
        h2 { margin:0 0 16px; font-size:18px; }
        .pets { display:flex; gap:12px; flex-wrap:wrap; }
        .pet-opt { width:80px; height:100px; border:2px solid #e5e7eb; border-radius:12px;
          display:flex; flex-direction:column; align-items:center; justify-content:center;
          cursor:pointer; transition:all .2s; }
        .pet-opt:hover { border-color:#a78bfa; }
        .pet-opt.sel { border-color:#7c3aed; background:#f5f3ff; }
        .pet-opt svg { width:50px; height:50px; }
        .pet-opt span { font-size:12px; margin-top:4px; }
        .personalities { display:flex; gap:8px; flex-wrap:wrap; }
        .pers { padding:8px 16px; border:2px solid #e5e7eb; border-radius:20px;
          cursor:pointer; font-size:13px; transition:all .2s; }
        .pers:hover { border-color:#a78bfa; }
        .pers.sel { border-color:#7c3aed; background:#f5f3ff; }
        .tags { display:flex; gap:8px; flex-wrap:wrap; margin-top:8px; }
        .tag-opt { padding:4px 12px; cursor:pointer; font-size:11px; font-weight:600; transition:all .2s; opacity:.7; }
        .tag-opt:hover { opacity:1; }
        .tag-opt.sel { opacity:1; box-shadow:0 0 0 2px #7c3aed; }
        .t0 { background:#fff9e6; color:#d97706; border-radius:3px 8px 8px 3px; border:1.5px solid #fbbf24; border-left:3px solid #f59e0b; }
        .t1 { background:#e0f2fe; color:#0284c7; border-radius:10px; border:1.5px solid #7dd3fc; }
        .t2 { background:#fce7f3; color:#db2777; border-radius:0 8px 0 8px; border:1.5px solid #f9a8d4; }
        .t3 { background:#ecfccb; color:#65a30d; border-radius:8px 0 8px 0; border:1.5px solid #bef264; }
        .styles { display:flex; gap:12px; margin-bottom:16px; }
        .style-opt { padding:8px 20px; border:2px solid #e5e7eb; border-radius:12px; cursor:pointer; font-size:13px; transition:all .2s; }
        .style-opt:hover { border-color:#a78bfa; }
        .style-opt.sel { border-color:#7c3aed; background:#f5f3ff; }
        input { width:100%; padding:12px; border:2px solid #e5e7eb; border-radius:8px;
          font-size:16px; outline:none; }
        input:focus { border-color:#7c3aed; }
        .btns { display:flex; gap:12px; margin-top:24px; }
        .btn { flex:1; padding:12px; border:none; border-radius:8px; font-size:14px;
          cursor:pointer; transition:all .2s; }
        .btn-pri { background:#7c3aed; color:#fff; }
        .btn-pri:hover { background:#6d28d9; }
        .btn-sec { background:#e5e7eb; }
        .preview { text-align:center; margin:20px 0; }
        .preview svg { width:120px; height:120px; }
        .preview h3 { margin:12px 0 4px; font-size:20px; }
        .preview p { color:#6b7280; font-size:13px; }
      </style>
      <div class="wrap">
        ${this.step === 1 ? this.renderStep1() : this.step === 2 ? this.renderStep2() : this.renderStep3()}
      </div>
    `;
  }
  renderStep1() {
    return b`
      <h2>选择风格</h2>
      <div class="styles">
        <div class="style-opt ${this.petStyle === "cute" ? "sel" : ""}" @click=${() => this.petStyle = "cute"}>🎀 可爱风</div>
        <div class="style-opt ${this.petStyle === "pixel" ? "sel" : ""}" @click=${() => this.petStyle = "pixel"}>👾 像素风</div>
      </div>
      <h2>选择宠物</h2>
      <div class="pets">
        ${Object.entries(yt).map(([t, i]) => b`
          <div class="pet-opt ${this.petType === t ? "sel" : ""}" @click=${() => this.petType = t}>
            <div .innerHTML=${vt(t, "idle", 0, this.petStyle)}></div>
            <span>${i.name}</span>
          </div>
        `)}
      </div>
      <div class="btns"><button class="btn btn-pri" @click=${() => this.nextStep()}>下一步</button></div>
    `;
  }
  renderStep2() {
    var t;
    return b`
      <h2>给${((t = yt[this.petType]) == null ? void 0 : t.name) || "宠物"}起个名字</h2>
      <input type="text" placeholder="输入名字..." .value=${this.petName}
        @input=${(i) => this.petName = i.target.value} maxlength="8">
      <h2 style="margin-top:16px">选择性格</h2>
      <div class="personalities">
        ${Object.entries(Yt).map(([i, n]) => b`
          <div class="pers ${this.personality === i ? "sel" : ""}" @click=${() => this.personality = i}>${n.name}</div>
        `)}
      </div>
      <h2 style="margin-top:16px">选择铭牌</h2>
      <div class="tags">
        ${[0, 1, 2, 3].map((i) => b`
          <span class="tag-opt t${i} ${this.tagStyle === i ? "sel" : ""}" @click=${() => this.tagStyle = i}>示例名</span>
        `)}
      </div>
      <div class="btns">
        <button class="btn btn-sec" @click=${() => this.prevStep()}>上一步</button>
        <button class="btn btn-pri" @click=${() => this.nextStep()}>下一步</button>
      </div>
    `;
  }
  renderStep3() {
    var i;
    const t = Yt[this.personality];
    return b`
      <div class="preview">
        <div .innerHTML=${vt(this.petType, "happy", 0, this.petStyle)}></div>
        <h3>${this.petName || "未命名"}</h3>
        <p>${(i = yt[this.petType]) == null ? void 0 : i.name} · ${t == null ? void 0 : t.name}</p>
        <p style="font-style:italic">"${t == null ? void 0 : t.greeting}"</p>
      </div>
      <div class="btns">
        <button class="btn btn-sec" @click=${() => this.prevStep()}>修改</button>
        <button class="btn btn-pri" @click=${() => this.finish()}>完成</button>
      </div>
    `;
  }
}
at(me, "properties", {
  petType: { type: String },
  petName: { type: String },
  personality: { type: String },
  tagStyle: { type: Number },
  petStyle: { type: String },
  step: { type: Number }
});
const Jt = {
  author: "Madrays",
  microAppId: "madrays-pixel-pet",
  version: "1.0.0",
  entry: "main.js",
  icon: "logo.png",
  appInfo: {
    "zh-CN": {
      appName: "像素宠物",
      description: "可爱的像素宠物，需要你的照顾"
    }
  },
  permissions: ["dataNode"],
  dataNodes: {
    "pet-state": { scope: "app", isPublic: !0 }
  }
}, gs = {
  pages: {
    "pixel-pet-config": {
      component: me,
      background: "#f8fafc"
    }
  },
  widgets: {
    "pixel-pet-widget": {
      component: be,
      configComponentName: "pixel-pet-config",
      size: ["2x2", "2x4"],
      background: "",
      isModifyBackground: !0
    }
  }
}, bs = !1, Cs = {
  appConfig: {
    ...Jt,
    microAppId: Jt.microAppId,
    dev: bs
  },
  components: gs
};
export {
  Cs as default
};
