var xe = Object.defineProperty;
var we = (s, t, e) => t in s ? xe(s, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : s[t] = e;
var ot = (s, t, e) => we(s, typeof t != "symbol" ? t + "" : t, e);
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const X = globalThis, wt = X.ShadowRoot && (X.ShadyCSS === void 0 || X.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, te = Symbol(), Et = /* @__PURE__ */ new WeakMap();
let ve = class {
  constructor(t, e, i) {
    if (this._$cssResult$ = !0, i !== te) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if (wt && t === void 0) {
      const i = e !== void 0 && e.length === 1;
      i && (t = Et.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), i && Et.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const Ae = (s) => new ve(typeof s == "string" ? s : s + "", void 0, te), be = (s, t) => {
  if (wt) s.adoptedStyleSheets = t.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet);
  else for (const e of t) {
    const i = document.createElement("style"), n = X.litNonce;
    n !== void 0 && i.setAttribute("nonce", n), i.textContent = e.cssText, s.appendChild(i);
  }
}, St = wt ? (s) => s : (s) => s instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const i of t.cssRules) e += i.cssText;
  return Ae(e);
})(s) : s;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: Ce, defineProperty: Ee, getOwnPropertyDescriptor: Se, getOwnPropertyNames: ke, getOwnPropertySymbols: Me, getPrototypeOf: Pe } = Object, x = globalThis, kt = x.trustedTypes, De = kt ? kt.emptyScript : "", at = x.reactiveElementPolyfillSupport, j = (s, t) => s, $t = { toAttribute(s, t) {
  switch (t) {
    case Boolean:
      s = s ? De : null;
      break;
    case Object:
    case Array:
      s = s == null ? s : JSON.stringify(s);
  }
  return s;
}, fromAttribute(s, t) {
  let e = s;
  switch (t) {
    case Boolean:
      e = s !== null;
      break;
    case Number:
      e = s === null ? null : Number(s);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(s);
      } catch {
        e = null;
      }
  }
  return e;
} }, ee = (s, t) => !Ce(s, t), Mt = { attribute: !0, type: String, converter: $t, reflect: !1, useDefault: !1, hasChanged: ee };
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), x.litPropertyMetadata ?? (x.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let U = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ?? (this.l = [])).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = Mt) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const i = Symbol(), n = this.getPropertyDescriptor(t, i, e);
      n !== void 0 && Ee(this.prototype, t, n);
    }
  }
  static getPropertyDescriptor(t, e, i) {
    const { get: n, set: r } = Se(this.prototype, t) ?? { get() {
      return this[e];
    }, set(o) {
      this[e] = o;
    } };
    return { get: n, set(o) {
      const l = n == null ? void 0 : n.call(this);
      r == null || r.call(this, o), this.requestUpdate(t, l, i);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? Mt;
  }
  static _$Ei() {
    if (this.hasOwnProperty(j("elementProperties"))) return;
    const t = Pe(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(j("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(j("properties"))) {
      const e = this.properties, i = [...ke(e), ...Me(e)];
      for (const n of i) this.createProperty(n, e[n]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [i, n] of e) this.elementProperties.set(i, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, i] of this.elementProperties) {
      const n = this._$Eu(e, i);
      n !== void 0 && this._$Eh.set(n, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const i = new Set(t.flat(1 / 0).reverse());
      for (const n of i) e.unshift(St(n));
    } else t !== void 0 && e.push(St(t));
    return e;
  }
  static _$Eu(t, e) {
    const i = e.attribute;
    return i === !1 ? void 0 : typeof i == "string" ? i : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var t;
    this._$ES = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (t = this.constructor.l) == null || t.forEach((e) => e(this));
  }
  addController(t) {
    var e;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(t), this.renderRoot !== void 0 && this.isConnected && ((e = t.hostConnected) == null || e.call(t));
  }
  removeController(t) {
    var e;
    (e = this._$EO) == null || e.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const i of e.keys()) this.hasOwnProperty(i) && (t.set(i, this[i]), delete this[i]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return be(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    var t;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (t = this._$EO) == null || t.forEach((e) => {
      var i;
      return (i = e.hostConnected) == null ? void 0 : i.call(e);
    });
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    var t;
    (t = this._$EO) == null || t.forEach((e) => {
      var i;
      return (i = e.hostDisconnected) == null ? void 0 : i.call(e);
    });
  }
  attributeChangedCallback(t, e, i) {
    this._$AK(t, i);
  }
  _$ET(t, e) {
    var r;
    const i = this.constructor.elementProperties.get(t), n = this.constructor._$Eu(t, i);
    if (n !== void 0 && i.reflect === !0) {
      const o = (((r = i.converter) == null ? void 0 : r.toAttribute) !== void 0 ? i.converter : $t).toAttribute(e, i.type);
      this._$Em = t, o == null ? this.removeAttribute(n) : this.setAttribute(n, o), this._$Em = null;
    }
  }
  _$AK(t, e) {
    var r, o;
    const i = this.constructor, n = i._$Eh.get(t);
    if (n !== void 0 && this._$Em !== n) {
      const l = i.getPropertyOptions(n), a = typeof l.converter == "function" ? { fromAttribute: l.converter } : ((r = l.converter) == null ? void 0 : r.fromAttribute) !== void 0 ? l.converter : $t;
      this._$Em = n;
      const h = a.fromAttribute(e, l.type);
      this[n] = h ?? ((o = this._$Ej) == null ? void 0 : o.get(n)) ?? h, this._$Em = null;
    }
  }
  requestUpdate(t, e, i, n = !1, r) {
    var o;
    if (t !== void 0) {
      const l = this.constructor;
      if (n === !1 && (r = this[t]), i ?? (i = l.getPropertyOptions(t)), !((i.hasChanged ?? ee)(r, e) || i.useDefault && i.reflect && r === ((o = this._$Ej) == null ? void 0 : o.get(t)) && !this.hasAttribute(l._$Eu(t, i)))) return;
      this.C(t, e, i);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: i, reflect: n, wrapped: r }, o) {
    i && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(t) && (this._$Ej.set(t, o ?? e ?? this[t]), r !== !0 || o !== void 0) || (this._$AL.has(t) || (this.hasUpdated || i || (e = void 0), this._$AL.set(t, e)), n === !0 && this._$Em !== t && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var i;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [r, o] of this._$Ep) this[r] = o;
        this._$Ep = void 0;
      }
      const n = this.constructor.elementProperties;
      if (n.size > 0) for (const [r, o] of n) {
        const { wrapped: l } = o, a = this[r];
        l !== !0 || this._$AL.has(r) || a === void 0 || this.C(r, void 0, o, a);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), (i = this._$EO) == null || i.forEach((n) => {
        var r;
        return (r = n.hostUpdate) == null ? void 0 : r.call(n);
      }), this.update(e)) : this._$EM();
    } catch (n) {
      throw t = !1, this._$EM(), n;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    var e;
    (e = this._$EO) == null || e.forEach((i) => {
      var n;
      return (n = i.hostUpdated) == null ? void 0 : n.call(i);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((e) => this._$ET(e, this[e]))), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
U.elementStyles = [], U.shadowRootOptions = { mode: "open" }, U[j("elementProperties")] = /* @__PURE__ */ new Map(), U[j("finalized")] = /* @__PURE__ */ new Map(), at == null || at({ ReactiveElement: U }), (x.reactiveElementVersions ?? (x.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const R = globalThis, Pt = (s) => s, it = R.trustedTypes, Dt = it ? it.createPolicy("lit-html", { createHTML: (s) => s }) : void 0, ie = "$lit$", y = `lit$${Math.random().toFixed(9).slice(2)}$`, se = "?" + y, Te = `<${se}>`, k = document, V = () => k.createComment(""), W = (s) => s === null || typeof s != "object" && typeof s != "function", vt = Array.isArray, Ue = (s) => vt(s) || typeof (s == null ? void 0 : s[Symbol.iterator]) == "function", lt = `[ 	
\f\r]`, L = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Tt = /-->/g, Ut = />/g, v = RegExp(`>|${lt}(?:([^\\s"'>=/]+)(${lt}*=${lt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Bt = /'/g, Ot = /"/g, ne = /^(?:script|style|textarea|title)$/i, Be = (s) => (t, ...e) => ({ _$litType$: s, strings: t, values: e }), m = Be(1), O = Symbol.for("lit-noChange"), u = Symbol.for("lit-nothing"), Nt = /* @__PURE__ */ new WeakMap(), b = k.createTreeWalker(k, 129);
function re(s, t) {
  if (!vt(s) || !s.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Dt !== void 0 ? Dt.createHTML(t) : t;
}
const Oe = (s, t) => {
  const e = s.length - 1, i = [];
  let n, r = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", o = L;
  for (let l = 0; l < e; l++) {
    const a = s[l];
    let h, d, c = -1, p = 0;
    for (; p < a.length && (o.lastIndex = p, d = o.exec(a), d !== null); ) p = o.lastIndex, o === L ? d[1] === "!--" ? o = Tt : d[1] !== void 0 ? o = Ut : d[2] !== void 0 ? (ne.test(d[2]) && (n = RegExp("</" + d[2], "g")), o = v) : d[3] !== void 0 && (o = v) : o === v ? d[0] === ">" ? (o = n ?? L, c = -1) : d[1] === void 0 ? c = -2 : (c = o.lastIndex - d[2].length, h = d[1], o = d[3] === void 0 ? v : d[3] === '"' ? Ot : Bt) : o === Ot || o === Bt ? o = v : o === Tt || o === Ut ? o = L : (o = v, n = void 0);
    const g = o === v && s[l + 1].startsWith("/>") ? " " : "";
    r += o === L ? a + Te : c >= 0 ? (i.push(h), a.slice(0, c) + ie + a.slice(c) + y + g) : a + y + (c === -2 ? l : g);
  }
  return [re(s, r + (s[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), i];
};
let mt = class oe {
  constructor({ strings: t, _$litType$: e }, i) {
    let n;
    this.parts = [];
    let r = 0, o = 0;
    const l = t.length - 1, a = this.parts, [h, d] = Oe(t, e);
    if (this.el = oe.createElement(h, i), b.currentNode = this.el.content, e === 2 || e === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (n = b.nextNode()) !== null && a.length < l; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes()) for (const c of n.getAttributeNames()) if (c.endsWith(ie)) {
          const p = d[o++], g = n.getAttribute(c).split(y), $ = /([.?@])?(.*)/.exec(p);
          a.push({ type: 1, index: r, name: $[2], strings: g, ctor: $[1] === "." ? He : $[1] === "?" ? ze : $[1] === "@" ? Le : nt }), n.removeAttribute(c);
        } else c.startsWith(y) && (a.push({ type: 6, index: r }), n.removeAttribute(c));
        if (ne.test(n.tagName)) {
          const c = n.textContent.split(y), p = c.length - 1;
          if (p > 0) {
            n.textContent = it ? it.emptyScript : "";
            for (let g = 0; g < p; g++) n.append(c[g], V()), b.nextNode(), a.push({ type: 2, index: ++r });
            n.append(c[p], V());
          }
        }
      } else if (n.nodeType === 8) if (n.data === se) a.push({ type: 2, index: r });
      else {
        let c = -1;
        for (; (c = n.data.indexOf(y, c + 1)) !== -1; ) a.push({ type: 7, index: r }), c += y.length - 1;
      }
      r++;
    }
  }
  static createElement(t, e) {
    const i = k.createElement("template");
    return i.innerHTML = t, i;
  }
};
function N(s, t, e = s, i) {
  var o, l;
  if (t === O) return t;
  let n = i !== void 0 ? (o = e._$Co) == null ? void 0 : o[i] : e._$Cl;
  const r = W(t) ? void 0 : t._$litDirective$;
  return (n == null ? void 0 : n.constructor) !== r && ((l = n == null ? void 0 : n._$AO) == null || l.call(n, !1), r === void 0 ? n = void 0 : (n = new r(s), n._$AT(s, e, i)), i !== void 0 ? (e._$Co ?? (e._$Co = []))[i] = n : e._$Cl = n), n !== void 0 && (t = N(s, n._$AS(s, t.values), n, i)), t;
}
let Ne = class {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: i } = this._$AD, n = ((t == null ? void 0 : t.creationScope) ?? k).importNode(e, !0);
    b.currentNode = n;
    let r = b.nextNode(), o = 0, l = 0, a = i[0];
    for (; a !== void 0; ) {
      if (o === a.index) {
        let h;
        a.type === 2 ? h = new At(r, r.nextSibling, this, t) : a.type === 1 ? h = new a.ctor(r, a.name, a.strings, this, t) : a.type === 6 && (h = new Fe(r, this, t)), this._$AV.push(h), a = i[++l];
      }
      o !== (a == null ? void 0 : a.index) && (r = b.nextNode(), o++);
    }
    return b.currentNode = k, n;
  }
  p(t) {
    let e = 0;
    for (const i of this._$AV) i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, e), e += i.strings.length - 2) : i._$AI(t[e])), e++;
  }
}, At = class ae {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, e, i, n) {
    this.type = 2, this._$AH = u, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = i, this.options = n, this._$Cv = (n == null ? void 0 : n.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = N(this, t, e), W(t) ? t === u || t == null || t === "" ? (this._$AH !== u && this._$AR(), this._$AH = u) : t !== this._$AH && t !== O && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Ue(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== u && W(this._$AH) ? this._$AA.nextSibling.data = t : this.T(k.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var r;
    const { values: e, _$litType$: i } = t, n = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = mt.createElement(re(i.h, i.h[0]), this.options)), i);
    if (((r = this._$AH) == null ? void 0 : r._$AD) === n) this._$AH.p(e);
    else {
      const o = new Ne(n, this), l = o.u(this.options);
      o.p(e), this.T(l), this._$AH = o;
    }
  }
  _$AC(t) {
    let e = Nt.get(t.strings);
    return e === void 0 && Nt.set(t.strings, e = new mt(t)), e;
  }
  k(t) {
    vt(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, n = 0;
    for (const r of t) n === e.length ? e.push(i = new ae(this.O(V()), this.O(V()), this, this.options)) : i = e[n], i._$AI(r), n++;
    n < e.length && (this._$AR(i && i._$AB.nextSibling, n), e.length = n);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    var i;
    for ((i = this._$AP) == null ? void 0 : i.call(this, !1, !0, e); t !== this._$AB; ) {
      const n = Pt(t).nextSibling;
      Pt(t).remove(), t = n;
    }
  }
  setConnected(t) {
    var e;
    this._$AM === void 0 && (this._$Cv = t, (e = this._$AP) == null || e.call(this, t));
  }
}, nt = class {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, i, n, r) {
    this.type = 1, this._$AH = u, this._$AN = void 0, this.element = t, this.name = e, this._$AM = n, this.options = r, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = u;
  }
  _$AI(t, e = this, i, n) {
    const r = this.strings;
    let o = !1;
    if (r === void 0) t = N(this, t, e, 0), o = !W(t) || t !== this._$AH && t !== O, o && (this._$AH = t);
    else {
      const l = t;
      let a, h;
      for (t = r[0], a = 0; a < r.length - 1; a++) h = N(this, l[i + a], e, a), h === O && (h = this._$AH[a]), o || (o = !W(h) || h !== this._$AH[a]), h === u ? t = u : t !== u && (t += (h ?? "") + r[a + 1]), this._$AH[a] = h;
    }
    o && !n && this.j(t);
  }
  j(t) {
    t === u ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}, He = class extends nt {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === u ? void 0 : t;
  }
}, ze = class extends nt {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== u);
  }
}, Le = class extends nt {
  constructor(t, e, i, n, r) {
    super(t, e, i, n, r), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = N(this, t, e, 0) ?? u) === O) return;
    const i = this._$AH, n = t === u && i !== u || t.capture !== i.capture || t.once !== i.once || t.passive !== i.passive, r = t !== u && (i === u || n);
    n && this.element.removeEventListener(this.name, this, i), r && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var e;
    typeof this._$AH == "function" ? this._$AH.call(((e = this.options) == null ? void 0 : e.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}, Fe = class {
  constructor(t, e, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    N(this, t);
  }
};
const ht = R.litHtmlPolyfillSupport;
ht == null || ht(mt, At), (R.litHtmlVersions ?? (R.litHtmlVersions = [])).push("3.3.2");
const je = (s, t, e) => {
  const i = (e == null ? void 0 : e.renderBefore) ?? t;
  let n = i._$litPart$;
  if (n === void 0) {
    const r = (e == null ? void 0 : e.renderBefore) ?? null;
    i._$litPart$ = n = new At(t.insertBefore(V(), r), r, void 0, e ?? {});
  }
  return n._$AI(s), n;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const E = globalThis;
let tt = class extends U {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = je(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return O;
  }
};
var Gt;
tt._$litElement$ = !0, tt.finalized = !0, (Gt = E.litElementHydrateSupport) == null || Gt.call(E, { LitElement: tt });
const ct = E.litElementPolyfillSupport;
ct == null || ct({ LitElement: tt });
(E.litElementVersions ?? (E.litElementVersions = [])).push("4.2.2");
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const et = globalThis, bt = et.ShadowRoot && (et.ShadyCSS === void 0 || et.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, le = Symbol(), Ht = /* @__PURE__ */ new WeakMap();
let Re = class {
  constructor(s, t, e) {
    if (this._$cssResult$ = !0, e !== le) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = s, this.t = t;
  }
  get styleSheet() {
    let s = this.o;
    const t = this.t;
    if (bt && s === void 0) {
      const e = t !== void 0 && t.length === 1;
      e && (s = Ht.get(t)), s === void 0 && ((this.o = s = new CSSStyleSheet()).replaceSync(this.cssText), e && Ht.set(t, s));
    }
    return s;
  }
  toString() {
    return this.cssText;
  }
};
const zt = bt ? (s) => s : (s) => s instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const i of t.cssRules) e += i.cssText;
  return ((i) => new Re(typeof i == "string" ? i : i + "", void 0, le))(e);
})(s) : s, { is: Ie, defineProperty: qe, getOwnPropertyDescriptor: Qe, getOwnPropertyNames: Ve, getOwnPropertySymbols: We, getPrototypeOf: Ze } = Object, w = globalThis, Lt = w.trustedTypes, Ke = Lt ? Lt.emptyScript : "", dt = w.reactiveElementPolyfillSupport, I = (s, t) => s, yt = { toAttribute(s, t) {
  switch (t) {
    case Boolean:
      s = s ? Ke : null;
      break;
    case Object:
    case Array:
      s = s == null ? s : JSON.stringify(s);
  }
  return s;
}, fromAttribute(s, t) {
  let e = s;
  switch (t) {
    case Boolean:
      e = s !== null;
      break;
    case Number:
      e = s === null ? null : Number(s);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(s);
      } catch {
        e = null;
      }
  }
  return e;
} }, he = (s, t) => !Ie(s, t), Ft = { attribute: !0, type: String, converter: yt, reflect: !1, useDefault: !1, hasChanged: he };
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), w.litPropertyMetadata ?? (w.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let B = class extends HTMLElement {
  static addInitializer(s) {
    this._$Ei(), (this.l ?? (this.l = [])).push(s);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(s, t = Ft) {
    if (t.state && (t.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(s) && ((t = Object.create(t)).wrapped = !0), this.elementProperties.set(s, t), !t.noAccessor) {
      const e = Symbol(), i = this.getPropertyDescriptor(s, e, t);
      i !== void 0 && qe(this.prototype, s, i);
    }
  }
  static getPropertyDescriptor(s, t, e) {
    const { get: i, set: n } = Qe(this.prototype, s) ?? { get() {
      return this[t];
    }, set(r) {
      this[t] = r;
    } };
    return { get: i, set(r) {
      const o = i == null ? void 0 : i.call(this);
      n == null || n.call(this, r), this.requestUpdate(s, o, e);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(s) {
    return this.elementProperties.get(s) ?? Ft;
  }
  static _$Ei() {
    if (this.hasOwnProperty(I("elementProperties"))) return;
    const s = Ze(this);
    s.finalize(), s.l !== void 0 && (this.l = [...s.l]), this.elementProperties = new Map(s.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(I("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(I("properties"))) {
      const t = this.properties, e = [...Ve(t), ...We(t)];
      for (const i of e) this.createProperty(i, t[i]);
    }
    const s = this[Symbol.metadata];
    if (s !== null) {
      const t = litPropertyMetadata.get(s);
      if (t !== void 0) for (const [e, i] of t) this.elementProperties.set(e, i);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [t, e] of this.elementProperties) {
      const i = this._$Eu(t, e);
      i !== void 0 && this._$Eh.set(i, t);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(s) {
    const t = [];
    if (Array.isArray(s)) {
      const e = new Set(s.flat(1 / 0).reverse());
      for (const i of e) t.unshift(zt(i));
    } else s !== void 0 && t.push(zt(s));
    return t;
  }
  static _$Eu(s, t) {
    const e = t.attribute;
    return e === !1 ? void 0 : typeof e == "string" ? e : typeof s == "string" ? s.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var s;
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (s = this.constructor.l) == null || s.forEach((t) => t(this));
  }
  addController(s) {
    var t;
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(s), this.renderRoot !== void 0 && this.isConnected && ((t = s.hostConnected) == null || t.call(s));
  }
  removeController(s) {
    var t;
    (t = this._$EO) == null || t.delete(s);
  }
  _$E_() {
    const s = /* @__PURE__ */ new Map(), t = this.constructor.elementProperties;
    for (const e of t.keys()) this.hasOwnProperty(e) && (s.set(e, this[e]), delete this[e]);
    s.size > 0 && (this._$Ep = s);
  }
  createRenderRoot() {
    const s = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return ((t, e) => {
      if (bt) t.adoptedStyleSheets = e.map((i) => i instanceof CSSStyleSheet ? i : i.styleSheet);
      else for (const i of e) {
        const n = document.createElement("style"), r = et.litNonce;
        r !== void 0 && n.setAttribute("nonce", r), n.textContent = i.cssText, t.appendChild(n);
      }
    })(s, this.constructor.elementStyles), s;
  }
  connectedCallback() {
    var s;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (s = this._$EO) == null || s.forEach((t) => {
      var e;
      return (e = t.hostConnected) == null ? void 0 : e.call(t);
    });
  }
  enableUpdating(s) {
  }
  disconnectedCallback() {
    var s;
    (s = this._$EO) == null || s.forEach((t) => {
      var e;
      return (e = t.hostDisconnected) == null ? void 0 : e.call(t);
    });
  }
  attributeChangedCallback(s, t, e) {
    this._$AK(s, e);
  }
  _$ET(s, t) {
    var n;
    const e = this.constructor.elementProperties.get(s), i = this.constructor._$Eu(s, e);
    if (i !== void 0 && e.reflect === !0) {
      const r = (((n = e.converter) == null ? void 0 : n.toAttribute) !== void 0 ? e.converter : yt).toAttribute(t, e.type);
      this._$Em = s, r == null ? this.removeAttribute(i) : this.setAttribute(i, r), this._$Em = null;
    }
  }
  _$AK(s, t) {
    var n, r;
    const e = this.constructor, i = e._$Eh.get(s);
    if (i !== void 0 && this._$Em !== i) {
      const o = e.getPropertyOptions(i), l = typeof o.converter == "function" ? { fromAttribute: o.converter } : ((n = o.converter) == null ? void 0 : n.fromAttribute) !== void 0 ? o.converter : yt;
      this._$Em = i;
      const a = l.fromAttribute(t, o.type);
      this[i] = a ?? ((r = this._$Ej) == null ? void 0 : r.get(i)) ?? a, this._$Em = null;
    }
  }
  requestUpdate(s, t, e, i = !1, n) {
    var r;
    if (s !== void 0) {
      const o = this.constructor;
      if (i === !1 && (n = this[s]), e ?? (e = o.getPropertyOptions(s)), !((e.hasChanged ?? he)(n, t) || e.useDefault && e.reflect && n === ((r = this._$Ej) == null ? void 0 : r.get(s)) && !this.hasAttribute(o._$Eu(s, e)))) return;
      this.C(s, t, e);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(s, t, { useDefault: e, reflect: i, wrapped: n }, r) {
    e && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(s) && (this._$Ej.set(s, r ?? t ?? this[s]), n !== !0 || r !== void 0) || (this._$AL.has(s) || (this.hasUpdated || e || (t = void 0), this._$AL.set(s, t)), i === !0 && this._$Em !== s && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(s));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (t) {
      Promise.reject(t);
    }
    const s = this.scheduleUpdate();
    return s != null && await s, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var e;
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [n, r] of this._$Ep) this[n] = r;
        this._$Ep = void 0;
      }
      const i = this.constructor.elementProperties;
      if (i.size > 0) for (const [n, r] of i) {
        const { wrapped: o } = r, l = this[n];
        o !== !0 || this._$AL.has(n) || l === void 0 || this.C(n, void 0, r, l);
      }
    }
    let s = !1;
    const t = this._$AL;
    try {
      s = this.shouldUpdate(t), s ? (this.willUpdate(t), (e = this._$EO) == null || e.forEach((i) => {
        var n;
        return (n = i.hostUpdate) == null ? void 0 : n.call(i);
      }), this.update(t)) : this._$EM();
    } catch (i) {
      throw s = !1, this._$EM(), i;
    }
    s && this._$AE(t);
  }
  willUpdate(s) {
  }
  _$AE(s) {
    var t;
    (t = this._$EO) == null || t.forEach((e) => {
      var i;
      return (i = e.hostUpdated) == null ? void 0 : i.call(e);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(s)), this.updated(s);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(s) {
    return !0;
  }
  update(s) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((t) => this._$ET(t, this[t]))), this._$EM();
  }
  updated(s) {
  }
  firstUpdated(s) {
  }
};
B.elementStyles = [], B.shadowRootOptions = { mode: "open" }, B[I("elementProperties")] = /* @__PURE__ */ new Map(), B[I("finalized")] = /* @__PURE__ */ new Map(), dt == null || dt({ ReactiveElement: B }), (w.reactiveElementVersions ?? (w.reactiveElementVersions = [])).push("2.1.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const q = globalThis, jt = (s) => s, st = q.trustedTypes, Rt = st ? st.createPolicy("lit-html", { createHTML: (s) => s }) : void 0, ce = "$lit$", _ = `lit$${Math.random().toFixed(9).slice(2)}$`, de = "?" + _, Ye = `<${de}>`, M = document, Z = () => M.createComment(""), K = (s) => s === null || typeof s != "object" && typeof s != "function", _t = Array.isArray, pt = `[ 	
\f\r]`, F = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, It = /-->/g, qt = />/g, A = RegExp(`>|${pt}(?:([^\\s"'>=/]+)(${pt}*=${pt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Qt = /'/g, Vt = /"/g, pe = /^(?:script|style|textarea|title)$/i, Ct = /* @__PURE__ */ ((s) => (t, ...e) => ({ _$litType$: s, strings: t, values: e }))(1), H = Symbol.for("lit-noChange"), f = Symbol.for("lit-nothing"), Wt = /* @__PURE__ */ new WeakMap(), C = M.createTreeWalker(M, 129);
function ue(s, t) {
  if (!_t(s) || !s.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return Rt !== void 0 ? Rt.createHTML(t) : t;
}
const Je = (s, t) => {
  const e = s.length - 1, i = [];
  let n, r = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", o = F;
  for (let l = 0; l < e; l++) {
    const a = s[l];
    let h, d, c = -1, p = 0;
    for (; p < a.length && (o.lastIndex = p, d = o.exec(a), d !== null); ) p = o.lastIndex, o === F ? d[1] === "!--" ? o = It : d[1] !== void 0 ? o = qt : d[2] !== void 0 ? (pe.test(d[2]) && (n = RegExp("</" + d[2], "g")), o = A) : d[3] !== void 0 && (o = A) : o === A ? d[0] === ">" ? (o = n ?? F, c = -1) : d[1] === void 0 ? c = -2 : (c = o.lastIndex - d[2].length, h = d[1], o = d[3] === void 0 ? A : d[3] === '"' ? Vt : Qt) : o === Vt || o === Qt ? o = A : o === It || o === qt ? o = F : (o = A, n = void 0);
    const g = o === A && s[l + 1].startsWith("/>") ? " " : "";
    r += o === F ? a + Ye : c >= 0 ? (i.push(h), a.slice(0, c) + ce + a.slice(c) + _ + g) : a + _ + (c === -2 ? l : g);
  }
  return [ue(s, r + (s[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), i];
};
class Y {
  constructor({ strings: t, _$litType$: e }, i) {
    let n;
    this.parts = [];
    let r = 0, o = 0;
    const l = t.length - 1, a = this.parts, [h, d] = Je(t, e);
    if (this.el = Y.createElement(h, i), C.currentNode = this.el.content, e === 2 || e === 3) {
      const c = this.el.content.firstChild;
      c.replaceWith(...c.childNodes);
    }
    for (; (n = C.nextNode()) !== null && a.length < l; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes()) for (const c of n.getAttributeNames()) if (c.endsWith(ce)) {
          const p = d[o++], g = n.getAttribute(c).split(_), $ = /([.?@])?(.*)/.exec(p);
          a.push({ type: 1, index: r, name: $[2], strings: g, ctor: $[1] === "." ? Xe : $[1] === "?" ? ti : $[1] === "@" ? ei : rt }), n.removeAttribute(c);
        } else c.startsWith(_) && (a.push({ type: 6, index: r }), n.removeAttribute(c));
        if (pe.test(n.tagName)) {
          const c = n.textContent.split(_), p = c.length - 1;
          if (p > 0) {
            n.textContent = st ? st.emptyScript : "";
            for (let g = 0; g < p; g++) n.append(c[g], Z()), C.nextNode(), a.push({ type: 2, index: ++r });
            n.append(c[p], Z());
          }
        }
      } else if (n.nodeType === 8) if (n.data === de) a.push({ type: 2, index: r });
      else {
        let c = -1;
        for (; (c = n.data.indexOf(_, c + 1)) !== -1; ) a.push({ type: 7, index: r }), c += _.length - 1;
      }
      r++;
    }
  }
  static createElement(t, e) {
    const i = M.createElement("template");
    return i.innerHTML = t, i;
  }
}
function z(s, t, e = s, i) {
  var o, l;
  if (t === H) return t;
  let n = i !== void 0 ? (o = e._$Co) == null ? void 0 : o[i] : e._$Cl;
  const r = K(t) ? void 0 : t._$litDirective$;
  return (n == null ? void 0 : n.constructor) !== r && ((l = n == null ? void 0 : n._$AO) == null || l.call(n, !1), r === void 0 ? n = void 0 : (n = new r(s), n._$AT(s, e, i)), i !== void 0 ? (e._$Co ?? (e._$Co = []))[i] = n : e._$Cl = n), n !== void 0 && (t = z(s, n._$AS(s, t.values), n, i)), t;
}
class Ge {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: i } = this._$AD, n = ((t == null ? void 0 : t.creationScope) ?? M).importNode(e, !0);
    C.currentNode = n;
    let r = C.nextNode(), o = 0, l = 0, a = i[0];
    for (; a !== void 0; ) {
      if (o === a.index) {
        let h;
        a.type === 2 ? h = new J(r, r.nextSibling, this, t) : a.type === 1 ? h = new a.ctor(r, a.name, a.strings, this, t) : a.type === 6 && (h = new ii(r, this, t)), this._$AV.push(h), a = i[++l];
      }
      o !== (a == null ? void 0 : a.index) && (r = C.nextNode(), o++);
    }
    return C.currentNode = M, n;
  }
  p(t) {
    let e = 0;
    for (const i of this._$AV) i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, e), e += i.strings.length - 2) : i._$AI(t[e])), e++;
  }
}
class J {
  get _$AU() {
    var t;
    return ((t = this._$AM) == null ? void 0 : t._$AU) ?? this._$Cv;
  }
  constructor(t, e, i, n) {
    this.type = 2, this._$AH = f, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = i, this.options = n, this._$Cv = (n == null ? void 0 : n.isConnected) ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && (t == null ? void 0 : t.nodeType) === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = z(this, t, e), K(t) ? t === f || t == null || t === "" ? (this._$AH !== f && this._$AR(), this._$AH = f) : t !== this._$AH && t !== H && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : ((i) => _t(i) || typeof (i == null ? void 0 : i[Symbol.iterator]) == "function")(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== f && K(this._$AH) ? this._$AA.nextSibling.data = t : this.T(M.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var r;
    const { values: e, _$litType$: i } = t, n = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = Y.createElement(ue(i.h, i.h[0]), this.options)), i);
    if (((r = this._$AH) == null ? void 0 : r._$AD) === n) this._$AH.p(e);
    else {
      const o = new Ge(n, this), l = o.u(this.options);
      o.p(e), this.T(l), this._$AH = o;
    }
  }
  _$AC(t) {
    let e = Wt.get(t.strings);
    return e === void 0 && Wt.set(t.strings, e = new Y(t)), e;
  }
  k(t) {
    _t(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, n = 0;
    for (const r of t) n === e.length ? e.push(i = new J(this.O(Z()), this.O(Z()), this, this.options)) : i = e[n], i._$AI(r), n++;
    n < e.length && (this._$AR(i && i._$AB.nextSibling, n), e.length = n);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    var i;
    for ((i = this._$AP) == null ? void 0 : i.call(this, !1, !0, e); t !== this._$AB; ) {
      const n = jt(t).nextSibling;
      jt(t).remove(), t = n;
    }
  }
  setConnected(t) {
    var e;
    this._$AM === void 0 && (this._$Cv = t, (e = this._$AP) == null || e.call(this, t));
  }
}
class rt {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, i, n, r) {
    this.type = 1, this._$AH = f, this._$AN = void 0, this.element = t, this.name = e, this._$AM = n, this.options = r, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = f;
  }
  _$AI(t, e = this, i, n) {
    const r = this.strings;
    let o = !1;
    if (r === void 0) t = z(this, t, e, 0), o = !K(t) || t !== this._$AH && t !== H, o && (this._$AH = t);
    else {
      const l = t;
      let a, h;
      for (t = r[0], a = 0; a < r.length - 1; a++) h = z(this, l[i + a], e, a), h === H && (h = this._$AH[a]), o || (o = !K(h) || h !== this._$AH[a]), h === f ? t = f : t !== f && (t += (h ?? "") + r[a + 1]), this._$AH[a] = h;
    }
    o && !n && this.j(t);
  }
  j(t) {
    t === f ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Xe extends rt {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === f ? void 0 : t;
  }
}
class ti extends rt {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== f);
  }
}
class ei extends rt {
  constructor(t, e, i, n, r) {
    super(t, e, i, n, r), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = z(this, t, e, 0) ?? f) === H) return;
    const i = this._$AH, n = t === f && i !== f || t.capture !== i.capture || t.once !== i.once || t.passive !== i.passive, r = t !== f && (i === f || n);
    n && this.element.removeEventListener(this.name, this, i), r && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var e;
    typeof this._$AH == "function" ? this._$AH.call(((e = this.options) == null ? void 0 : e.host) ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class ii {
  constructor(t, e, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    z(this, t);
  }
}
const ut = q.litHtmlPolyfillSupport;
ut == null || ut(Y, J), (q.litHtmlVersions ?? (q.litHtmlVersions = [])).push("3.3.2");
const S = globalThis;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class Q extends B {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = ((i, n, r) => {
      const o = (r == null ? void 0 : r.renderBefore) ?? n;
      let l = o._$litPart$;
      if (l === void 0) {
        const a = (r == null ? void 0 : r.renderBefore) ?? null;
        o._$litPart$ = l = new J(n.insertBefore(Z(), a), a, void 0, r ?? {});
      }
      return l._$AI(i), l;
    })(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) == null || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) == null || t.setConnected(!1);
  }
  render() {
    return H;
  }
}
var Xt;
Q._$litElement$ = !0, Q.finalized = !0, (Xt = S.litElementHydrateSupport) == null || Xt.call(S, { LitElement: Q });
const ft = S.litElementPolyfillSupport;
ft == null || ft({ LitElement: Q }), (S.litElementVersions ?? (S.litElementVersions = [])).push("4.2.2");
class fe extends Q {
  constructor() {
    super(), this._initialized = !1, this._eventListeners = /* @__PURE__ */ new Map();
  }
  initializeMicroApp() {
    this._initialized || (this._setupEventListeners(), this._initialized = !0);
  }
  connectedCallback() {
    super.connectedCallback(), this.initializeMicroApp(), this.onConnected();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupEventListeners(), this.onDisconnected();
  }
  attributeChangedCallback(t, e, i) {
    super.attributeChangedCallback(t, e, i), this.onAttributeChanged(t, e, i);
  }
  _setupEventListeners() {
  }
  _cleanupEventListeners() {
    const t = Array.from(this._eventListeners.entries());
    for (const [e, i] of t) i.forEach((n) => {
      window.removeEventListener(e, n);
    });
    this._eventListeners.clear();
  }
  addEventListener(t, e, i) {
    super.addEventListener(t, e, i);
  }
  dispatchCustomEvent(t, e) {
    const i = new CustomEvent(t, { bubbles: !0, composed: !0, detail: e });
    this.dispatchEvent(i);
  }
  onConnected() {
  }
  onDisconnected() {
  }
  onAttributeChanged(t, e, i) {
  }
  render() {
    return Ct``;
  }
}
class ge extends fe {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, widgetInfo: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([i, n]) => n !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    var e;
    (e = super.firstUpdated) == null || e.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, i = this.spCtx;
      i.widgetInfo !== e.widgetInfo && this.onWidgetInfoChanged(i.widgetInfo, e.widgetInfo), i.darkMode !== e.darkMode && this.onDarkModeChanged(i.darkMode, e.darkMode), i.language !== e.language && this.onLanguageChanged(i.language, e.language), i.networkMode !== e.networkMode && this.onNetworkModeChanged(i.networkMode, e.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized();
  }
  onInitialized() {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
  }
  onNetworkModeChanged(t, e) {
  }
  onWidgetInfoChanged(t, e) {
  }
  render() {
    return Ct``;
  }
}
ge.properties = { spCtx: { type: Object, attribute: !1 } };
class $e extends fe {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "zh-CN", networkMode: "wan", staticPath: "", role: 0, background: "", widgetInfo: {}, customParam: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([i, n]) => n !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    var e;
    (e = super.firstUpdated) == null || e.call(this, t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, i = this.spCtx;
      i.darkMode !== e.darkMode && this.onDarkModeChanged(i.darkMode, e.darkMode), i.language !== e.language && this.onLanguageChanged(i.language, e.language), i.networkMode !== e.networkMode && this.onNetworkModeChanged(i.networkMode, e.networkMode);
    }
  }
  onConnected() {
    super.onConnected(), this.onInitialized({ widgetInfo: this.spCtx.widgetInfo, customParam: this.spCtx.customParam });
  }
  onInitialized(t) {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
  }
  onNetworkModeChanged(t, e) {
  }
  render() {
    return Ct``;
  }
}
$e.properties = { spCtx: { type: Object, attribute: !1 } };
const me = 24 * 60 * 60 * 1e3;
function Zt(s) {
  return String(s).padStart(2, "0");
}
function xt(s) {
  return new Date(s.getFullYear(), s.getMonth(), s.getDate());
}
function Kt(s) {
  return s < 2e3 || s > 2099 ? 4 : Math.floor(s % 100 * 0.2422 + 4.81) - Math.floor((s % 100 - 1) / 4);
}
function T(s, t, e) {
  var i, n;
  try {
    const r = new Intl.DateTimeFormat("zh-CN-u-ca-chinese", {
      month: "long",
      day: "numeric"
    }), o = new Date(s, 0, 1), l = new Date(s, 11, 31);
    for (let a = new Date(o); a <= l; a = new Date(a.getTime() + me)) {
      const h = r.formatToParts(a), d = (i = h.find((p) => p.type === "month")) == null ? void 0 : i.value, c = Number(((n = h.find((p) => p.type === "day")) == null ? void 0 : n.value) || 0);
      if (d === t && c === e)
        return new Date(a.getFullYear(), a.getMonth(), a.getDate());
    }
  } catch {
    return null;
  }
  return null;
}
function si(s, t) {
  const e = xt(t).getTime() - xt(s).getTime();
  return Math.round(e / me);
}
function gt(s) {
  const t = s.getFullYear(), e = Zt(s.getMonth() + 1), i = Zt(s.getDate());
  return `${t}-${e}-${i}`;
}
function ni(s = "") {
  const t = String(s).replace(/（[^）]*）/g, "").replace(/\([^)]*\)/g, "").trim();
  return t.includes("元旦") ? "元旦节" : t.includes("春节") ? "春节" : t.includes("清明") ? "清明节" : t.includes("劳动") ? "劳动节" : t.includes("端午") ? "端午节" : t.includes("中秋") ? "中秋节" : t.includes("国庆") ? "国庆节" : t || "节假日";
}
function ri(s = /* @__PURE__ */ new Date()) {
  const t = xt(s), e = t.getFullYear(), i = e + 1, n = (o, l) => {
    const a = o && o >= t ? o : null, h = l && l >= t ? l : null;
    return a && h ? a <= h ? a : h : a || h || null;
  }, r = [
    { name: "元旦节", date: n(new Date(e, 0, 1), new Date(i, 0, 1)) },
    { name: "春节", date: n(T(e, "正月", 1), T(i, "正月", 1)) },
    { name: "清明节", date: n(new Date(e, 3, Kt(e)), new Date(i, 3, Kt(i))) },
    { name: "劳动节", date: n(new Date(e, 4, 1), new Date(i, 4, 1)) },
    { name: "端午节", date: n(T(e, "五月", 5), T(i, "五月", 5)) },
    { name: "中秋节", date: n(T(e, "八月", 15), T(i, "八月", 15)) },
    { name: "国庆节", date: n(new Date(e, 9, 1), new Date(i, 9, 1)) }
  ].filter((o) => o.date);
  return r.sort((o, l) => o.date.getTime() - l.date.getTime()), r[0] || null;
}
const P = (s) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 340 220">${s}</svg>`, D = (s, t, e) => `
    <defs>
      <linearGradient id="bg-${s.replace("#", "")}" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${s}" />
        <stop offset="100%" stop-color="${t}" />
      </linearGradient>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="2" dy="4" stdDeviation="4" flood-opacity="0.1"/>
      </filter>
    </defs>
    <rect x="10" y="10" width="320" height="200" rx="24" fill="url(#bg-${s.replace("#", "")})" opacity="0.15" />
    <rect x="10" y="10" width="320" height="200" rx="24" fill="none" stroke="rgba(15,23,42,0.08)" stroke-width="1.5"/>
    ${e}
  `, Yt = () => P(D("#8B5CF6", "#EC4899", `
    <g transform="translate(170,110)">
      <!-- 烟花绽放 1 -->
      <g transform="translate(-60, -40) scale(0.8)">
        <circle r="4" fill="#F472B6" />
        <path d="M0,-20 L0,-35 M14,-14 L24,-24 M20,0 L35,0 M14,14 L24,24 M0,20 L0,35 M-14,14 L-24,24 M-20,0 L-35,0 M-14,-14 L-24,-24" stroke="#F472B6" stroke-width="2" stroke-linecap="round" />
      </g>
      <!-- 烟花绽放 2 -->
      <g transform="translate(60, -20) scale(0.6)">
        <circle r="4" fill="#A78BFA" />
        <path d="M0,-20 L0,-35 M14,-14 L24,-24 M20,0 L35,0 M14,14 L24,24 M0,20 L0,35 M-14,14 L-24,24 M-20,0 L-35,0 M-14,-14 L-24,-24" stroke="#A78BFA" stroke-width="2" stroke-linecap="round" />
      </g>
      <!-- 主烟花 -->
      <g transform="scale(1.2)">
         <circle r="6" fill="#FBBF24" />
         <path d="M0,-24 L0,-40 M17,-17 L28,-28 M24,0 L40,0 M17,17 L28,28 M0,24 L0,40 M-17,17 L-28,28 M-24,0 L-40,0 M-17,-17 L-28,-28" stroke="#F59E0B" stroke-width="2.5" stroke-linecap="round" />
      </g>
      <!-- 飘带 -->
      <path d="M-100,60 Q-50,20 0,60 T100,60" fill="none" stroke="#F472B6" stroke-width="2" stroke-dasharray="8,8" opacity="0.6"/>
    </g>
`)), oi = () => P(D("#EF4444", "#F59E0B", `
    <!-- 左灯笼 -->
    <g transform="translate(70, 40)">
      <rect x="-2" y="0" width="4" height="20" fill="#B91C1C" />
      <path d="M-20,20 Q-28,45 -20,70 L20,70 Q28,45 20,20 Z" fill="#DC2626" />
      <path d="M-20,20 Q0,5 20,20" fill="#B91C1C" /> <!-- Top cap -->
      <rect x="-2" y="70" width="4" height="6" fill="#F59E0B" />
      <g stroke="#B91C1C" stroke-width="1.5" fill="none">
         <path d="M-10,20 Q-14,45 -10,70 M0,20 V70 M10,20 Q14,45 10,70" opacity="0.3"/>
      </g>
      <!-- 穗 -->
      <path d="M0,76 V100" stroke="#B91C1C" stroke-width="2" />
      <path d="M-4,78 V95 M4,78 V95" stroke="#B91C1C" stroke-width="1.5" />
    </g>

    <!-- 右灯笼 (小) -->
    <g transform="translate(260, 30) scale(0.8)">
      <rect x="-2" y="0" width="4" height="20" fill="#B91C1C" />
      <path d="M-20,20 Q-28,45 -20,70 L20,70 Q28,45 20,20 Z" fill="#DC2626" />
      <path d="M-20,20 Q0,5 20,20" fill="#B91C1C" />
      <rect x="-2" y="70" width="4" height="6" fill="#F59E0B" />
      <g stroke="#B91C1C" stroke-width="1.5" fill="none">
         <path d="M-10,20 Q-14,45 -10,70 M0,20 V70 M10,20 Q14,45 10,70" opacity="0.3"/>
      </g>
      <path d="M0,76 V100" stroke="#B91C1C" stroke-width="2" />
    </g>

    <!-- 底部祥云 -->
    <path d="M40,180 Q60,160 80,180 T120,180 T160,180 T200,180" fill="none" stroke="#FCA5A5" stroke-width="3" stroke-linecap="round" opacity="0.6" />
    <path d="M140,195 Q160,175 180,195 T220,195 T260,195 T300,195" fill="none" stroke="#FECACA" stroke-width="3" stroke-linecap="round" opacity="0.4" />
`)), ai = () => P(D("#10B981", "#34D399", `
    <!-- 远山 -->
    <path d="M40,160 Q90,100 140,160 T240,160" fill="none" stroke="#6EE7B7" stroke-width="2" />
    <path d="M180,160 Q230,80 280,160" fill="none" stroke="#34D399" stroke-width="2" opacity="0.8"/>
    
    <!-- 柳枝 -->
    <g transform="translate(300, -10) rotate(15)">
      <path d="M0,0 Q-30,60 -10,120" stroke="#059669" stroke-width="2" fill="none" />
      <g fill="#34D399">
        <ellipse cx="-10" cy="30" rx="3" ry="6" transform="rotate(-15)" />
        <ellipse cx="-18" cy="50" rx="3" ry="6" transform="rotate(-10)" />
        <ellipse cx="-20" cy="70" rx="3" ry="6" transform="rotate(-5)" />
        <ellipse cx="-15" cy="90" rx="3" ry="6" transform="rotate(0)" />
        <ellipse cx="-10" cy="110" rx="3" ry="6" transform="rotate(5)" />
      </g>
    </g>
     <g transform="translate(40, -10) rotate(-10)">
      <path d="M10,0 Q30,50 10,100" stroke="#059669" stroke-width="2" fill="none" />
       <g fill="#6EE7B7">
        <ellipse cx="15" cy="30" rx="2" ry="5" transform="rotate(15)" />
        <ellipse cx="20" cy="50" rx="2" ry="5" transform="rotate(10)" />
        <ellipse cx="18" cy="70" rx="2" ry="5" transform="rotate(5)" />
      </g>
    </g>
    
    <!-- 细雨 -->
    <g stroke="#A7F3D0" stroke-width="1.5" stroke-linecap="round">
       <line x1="100" y1="50" x2="95" y2="60" />
       <line x1="150" y1="70" x2="145" y2="80" />
       <line x1="200" y1="40" x2="195" y2="50" />
       <line x1="120" y1="100" x2="115" y2="110" />
       <line x1="230" y1="90" x2="225" y2="100" />
    </g>
`)), li = () => P(D("#F59E0B", "#F97316", `
    <g transform="translate(170, 110)">
      <!-- 齿轮 (简化) -->
      <path d="M-35,-35 h20 l5,-10 h20 l5,10 h20 v20 l10,5 v20 l-10,5 v20 h-20 l-5,10 h-20 l-5,-10 h-20 v-20 l-10,-5 v-20 l10,-5 Z" 
            fill="none" stroke="#B45309" stroke-width="3" opacity="0.2" transform="rotate(15)"/>
            
      <!-- 麦穗 (左) -->
      <g transform="stroke:#F59E0B; stroke-width:2; fill:#FCD34D" >
         <ellipse cx="-20" cy="10" rx="4" ry="8" transform="rotate(-30, -20, 10)" />
         <ellipse cx="-20" cy="-5" rx="4" ry="8" transform="rotate(-30, -20, -5)" />
         <ellipse cx="-20" cy="-20" rx="4" ry="8" transform="rotate(-30, -20, -20)" />
         <path d="M-20,40 Q-20,0 -20,-30" stroke="#D97706" fill="none" />
      </g>
      <!-- 麦穗 (右) -->
      <g transform="scale(-1, 1) stroke:#F59E0B; stroke-width:2; fill:#FCD34D" >
         <ellipse cx="-20" cy="10" rx="4" ry="8" transform="rotate(-30, -20, 10)" />
         <ellipse cx="-20" cy="-5" rx="4" ry="8" transform="rotate(-30, -20, -5)" />
         <ellipse cx="-20" cy="-20" rx="4" ry="8" transform="rotate(-30, -20, -20)" />
         <path d="M-20,40 Q-20,0 -20,-30" stroke="#D97706" fill="none" />
      </g>
      
      <!-- 太阳/勋章核心 -->
      <circle r="18" fill="#FBBF24" stroke="#D97706" stroke-width="2" />
      <g stroke="#FBBF24" stroke-width="2" stroke-linecap="round">
         <line y1="-26" y2="-22" />
         <line y1="26" y2="22" />
         <line x1="-26" x2="-22" />
         <line x1="26" x2="22" />
         <line x1="18" y1="18" x2="15" y2="15" />
         <line x1="-18" y1="-18" x2="-15" y2="-15" />
         <line x1="18" y1="-18" x2="15" y2="-15" />
         <line x1="-18" y1="18" x2="-15" y2="15" />
      </g>
    </g>
`)), hi = () => P(D("#06B6D4", "#3B82F6", `
    <!-- 波浪背景 -->
    <path d="M20,160 Q50,140 80,160 T140,160 T200,160 T260,160 T320,160" fill="none" stroke="#93C5FD" stroke-width="2" stroke-opacity="0.6"/>
    <path d="M30,175 Q60,155 90,175 T150,175 T210,175 T270,175 T330,175" fill="none" stroke="#60A5FA" stroke-width="2" stroke-opacity="0.8"/>
    
    <!-- 龙舟简笔 -->
    <g transform="translate(140, 130)">
       <!-- 舟身 -->
       <path d="M-60,10 Q0,35 100,10 L90,-5 Q0,20 -60,-5 Z" fill="#0E7490" />
       <!-- 龙头 -->
        <g transform="translate(-60, -5)">
            <path d="M0,0 Q-10,-20 10,-30 Q25,-35 30,-20 Q35,-10 20,5 Z" fill="#EAB308" /> <!-- 头 -->
            <circle cx="15" cy="-20" r="2.5" fill="white"/> <!-- 眼 -->
            <circle cx="16" cy="-20" r="1" fill="black"/>
            <path d="M5,-30 Q0,-45 15,-40" stroke="#EAB308" stroke-width="3" fill="none" stroke-linecap="round" /> <!-- 角 -->
            <path d="M30,-20 Q40,-15 35,-5" stroke="#EAB308" stroke-width="3" fill="none" stroke-linecap="round"/> <!-- 须 -->
        </g>
       <!-- 鼓槌 -->
       <line x1="0" y1="-10" x2="10" y2="5" stroke="#94A3B8" stroke-width="3" stroke-linecap="round" />
       <circle cx="0" cy="-12" r="3" fill="#CBD5E1" />
    </g>
`)), ci = () => P(D("#6366F1", "#8B5CF6", `
    <!-- 月亮 -->
    <circle cx="170" cy="100" r="50" fill="#FEF3C7" filter="url(#shadow)" opacity="0.9"/>
    <circle cx="150" cy="85" r="6" fill="#FDE68A" opacity="0.6"/>
    <circle cx="190" cy="95" r="4" fill="#FDE68A" opacity="0.6"/>
    <circle cx="175" cy="120" r="8" fill="#FDE68A" opacity="0.6"/>
    
    <!-- 玉兔背影/剪影 -->
    <g transform="translate(170, 140)">
      <ellipse cx="0" cy="0" rx="12" ry="8" fill="white" /> <!-- 身体 -->
      <circle cx="-8" cy="-8" r="7" fill="white" /> <!-- 头 -->
      <ellipse cx="-6" cy="-18" rx="2.5" ry="8" fill="white" transform="rotate(-15, -6, -18)" /> <!-- 耳 -->
      <ellipse cx="-12" cy="-16" rx="2.5" ry="8" fill="white" transform="rotate(-30, -12, -16)" /> <!-- 耳 -->
      <circle cx="-16" cy="-4" r="1.5" fill="#FDA4AF" opacity="0.6"/> <!-- 腮红 -->
    </g>
    
    <!-- 云彩 -->
    <g fill="#A5B4FC" opacity="0.4">
       <circle cx="100" cy="150" r="20" />
       <circle cx="130" cy="160" r="25" />
       <circle cx="210" cy="155" r="22" />
       <circle cx="240" cy="145" r="18" />
    </g>
`)), di = () => P(D("#EF4444", "#F472B6", `
    <!-- 飘带 -->
    <path d="M40,160 Q100,100 170,160 T300,160" fill="none" stroke="#FBBF24" stroke-width="3" opacity="0.6" />
    <path d="M60,170 Q120,120 190,170 T320,170" fill="none" stroke="#FBBF24" stroke-width="2" opacity="0.4" />

    <!-- 红旗 -->
    <g transform="translate(130, 60)">
       <path d="M0,0 L0,100" stroke="#7F1D1D" stroke-width="4" stroke-linecap="round" />
       <!-- 旗面 (飘动) -->
       <path d="M2,2 Q40,-10 80,10 Q60,30 80,60 Q40,40 2,60 Z" fill="#DC2626" />
       <!-- 大星 -->
       <g transform="translate(15, 15) scale(0.6)">
         <polygon points="10,1 12,7 19,7 13,11 15,17 10,13 5,17 7,11 1,7 8,7" fill="#FBBF24"/>
       </g>
       <!-- 小星 -->
       <g transform="translate(30, 8) scale(0.3)">
         <polygon points="10,1 12,7 19,7 13,11 15,17 10,13 5,17 7,11 1,7 8,7" fill="#FBBF24"/>
       </g>
       <g transform="translate(36, 14) scale(0.3) rotate(20)">
         <polygon points="10,1 12,7 19,7 13,11 15,17 10,13 5,17 7,11 1,7 8,7" fill="#FBBF24"/>
       </g>
        <g transform="translate(36, 22) scale(0.3) rotate(40)">
         <polygon points="10,1 12,7 19,7 13,11 15,17 10,13 5,17 7,11 1,7 8,7" fill="#FBBF24"/>
       </g>
    </g>
    
    <!-- 气球 -->
    <circle cx="90" cy="80" r="12" fill="#FCA5A5" opacity="0.8"/>
    <line x1="90" y1="92" x2="90" y2="120" stroke="#999" stroke-width="1"/>
    
    <circle cx="250" cy="100" r="10" fill="#FBBF24" opacity="0.8"/>
    <line x1="250" y1="110" x2="250" y2="130" stroke="#999" stroke-width="1"/>
`)), pi = (s) => {
  switch (s) {
    case "元旦节":
      return Yt();
    case "春节":
      return oi();
    case "清明节":
      return ai();
    case "劳动节":
      return li();
    case "端午节":
      return hi();
    case "中秋节":
      return ci();
    case "国庆节":
      return di();
    default:
      return Yt();
  }
}, G = (s) => {
  const t = pi(s);
  return `data:image/svg+xml;utf8,${encodeURIComponent(t)}`;
};
function ui(s = /* @__PURE__ */ new Date()) {
  const t = s.getFullYear(), e = String(s.getMonth() + 1).padStart(2, "0"), i = String(s.getDate()).padStart(2, "0");
  return `${t}-${e}-${i}`;
}
class ye extends ge {
  constructor() {
    super(), this.snapshot = null, this.loading = !0, this.error = "", this.config = {}, this._timer = null, this._computePromise = null, this._lastComputeAt = 0;
  }
  async onInitialized() {
    this.loadConfig(), await this.compute({ force: !0 }), this.startTimer();
  }
  async onWidgetInfoChanged(t, e) {
    this.requestUpdate();
    const i = (t == null ? void 0 : t.config) || {}, n = (e == null ? void 0 : e.config) || {};
    this.config = i, JSON.stringify(i) !== JSON.stringify(n) && await this.compute({ force: !0 });
  }
  onDisconnected() {
    this._timer && (clearInterval(this._timer), this._timer = null);
  }
  loadConfig() {
    var t;
    this.config = ((t = this.spCtx.widgetInfo) == null ? void 0 : t.config) || {};
  }
  startTimer() {
    this._timer && clearInterval(this._timer), this._timer = setInterval(() => this.compute({ force: !0 }), 60 * 60 * 1e3);
  }
  async _computeCore() {
    this.loading = !0, this.error = "";
    try {
      const t = /* @__PURE__ */ new Date(), e = ui(t), i = ri(t);
      if (!i)
        throw new Error("未获取到下一个节假日");
      const n = si(t, i.date), r = {
        name: i.name,
        normalizedName: i.name,
        dateObj: i.date,
        date: gt(i.date),
        daysLeft: n,
        isToday: n === 0
      };
      this.snapshot = {
        today: e,
        next: r
      };
    } catch (t) {
      this.error = (t == null ? void 0 : t.message) || "节假日计算失败", this.snapshot = null;
    } finally {
      this.loading = !1;
    }
  }
  async compute({ force: t = !1 } = {}) {
    const e = Date.now();
    if (!(!t && e - this._lastComputeAt < 10 * 1e3)) {
      if (this._computePromise) return this._computePromise;
      this._lastComputeAt = e, this._computePromise = this._computeCore();
      try {
        await this._computePromise;
      } finally {
        this._computePromise = null;
      }
    }
  }
  get nextHoliday() {
    var t;
    return ((t = this.snapshot) == null ? void 0 : t.next) || null;
  }
  get displayHolidayName() {
    const t = this.nextHoliday;
    return t ? ni(t.name) : "";
  }
  get textColor() {
    var t;
    return ((t = this.config) == null ? void 0 : t.textMode) === "dark" ? "#0f172a" : "#ffffff";
  }
  get subTextColor() {
    var t;
    return ((t = this.config) == null ? void 0 : t.textMode) === "dark" ? "rgba(15,23,42,.72)" : "rgba(255,255,255,.84)";
  }
  get baseStyle() {
    return `
      :host { display:block; width:100%; height:100%; overflow:hidden; }
      * { box-sizing:border-box; }
      .wrap {
        position: relative;
        width:100%;
        height:100%;
        display:grid;
        container-type: size;
        color: ${this.textColor};
        font-family: "STKaiti", "KaiTi", "Noto Serif SC", serif;
        background: transparent;
        overflow:hidden;
        align-items: center;
        justify-items: center;
      }
      /* Default layout structure (can be overridden by specific sizes) */
      .info {
        grid-area: info;
        min-width: 0;
        max-width: 100%;
        height: 100%;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: flex-start;
      }
      .art-box {
        grid-area: art;
        width: 100%;
        height: 100%;
        min-width: 0;
        min-height: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
      }
      .content {
        width: 100%;
        min-width: 0;
        max-width: 100%;
        height: 100%;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        justify-content: center;
      }
      .sub { margin: 0 0 2%; font-size: var(--fs-sub, 3cqw); color: ${this.subTextColor}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 1.2; }
      .title { margin: 0; font-size: var(--fs-title, 6cqw); line-height: 1.1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 700; text-align: center; }
      .num-line { margin: 0; white-space: nowrap; display:flex; align-items:baseline; justify-content: center; min-width:0; overflow:hidden; line-height: 1; }
      .num { font-size: var(--fs-num, 14cqw); font-weight: 700; letter-spacing: -0.02em; }
      .unit { font-size: var(--fs-unit, 4cqw); margin-left: 0.2em; }
      .date { margin-top: 2%; font-size: var(--fs-date, 3cqw); color: ${this.subTextColor}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 1.2; }
      
      .hide-sub .sub { display:none !important; }
      .hide-date .date { display:none !important; }
      
      .art { width: 100%; height: 100%; min-height: 0; opacity: 1; display:block; }
      .art-img { width:100%; height:100%; display:block; object-fit: contain; object-position: center center; }
      .state { width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size: 13px; color:${this.subTextColor}; }
    `;
  }
  renderState(t) {
    return m`<style>${this.baseStyle}</style><div class="state">${t}</div>`;
  }
  renderBySize(t) {
    const e = this.nextHoliday;
    if (!e) return this.renderState("暂无节假日数据");
    const i = this.displayHolidayName, n = Number.isFinite(e.daysLeft) ? e.daysLeft : "--", r = e.isToday ? "今天就是节日" : "距离下个节日还有", o = ["1x1", "1x2", "2x1"].includes(t), l = ["1x1", "1x2", "2x1"].includes(t), a = `wrap${o ? " hide-sub" : ""}${l ? " hide-date" : ""}`, h = {
      // 1x1: 方形小卡片 - 字大
      "1x1": `
        .wrap {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 8%;
          gap: 4%;
        }
        .title { font-size: 24cqmin; font-weight: 700; text-align: center; }
        .num-line { display: flex; align-items: baseline; justify-content: center; }
        .num { font-size: 30cqmin; font-weight: 800; }
        .unit { font-size: 20cqmin; font-weight: 600; margin-left: 0.1em; }
      `,
      // 1x2: 横向三分格 30%+30%+30%，两侧留白5%
      "1x2": `
        .wrap {
          display: grid;
          grid-template-columns: 30% 30% 30%;
          column-gap: 5%;
          padding: 0 5%;
          height: 100%;
          align-items: center;
          justify-items: center;
        }
        .title { font-size: 20cqh; font-weight: 700; text-align: center; }
        .num-line { display: flex; align-items: baseline; justify-content: center; }
        .num { font-size: 26cqh; font-weight: 800; }
        .unit { font-size: 16cqh; font-weight: 600; margin-left: 0.1em; }
        .art-box { grid-area: auto; width: 100%; height: 80%; display: flex; align-items: center; justify-content: center; }
        .art-img { width: 100%; height: 100%; object-fit: contain; }
      `,
      // 2x1: 竖向三分格
      "2x1": `
        .wrap {
          display: grid;
          grid-template-rows: 30% 30% 30%;
          row-gap: 5%;
          padding: 5% 0;
          width: 100%;
          align-items: center;
          justify-items: center;
        }
        .title { font-size: 20cqw; font-weight: 700; text-align: center; }
        .num-line { display: flex; align-items: baseline; justify-content: center; }
        .num { font-size: 26cqw; font-weight: 800; }
        .unit { font-size: 16cqw; font-weight: 600; margin-left: 0.1em; }
        .art-box { grid-area: auto; width: 80%; height: 100%; display: flex; align-items: center; justify-content: center; }
        .art-img { width: 100%; height: 100%; object-fit: contain; }
      `,
      // 2x2: 第一行副标题，第二行左边天数+日期，右边SVG
      "2x2": `
        .wrap {
          display: grid;
          grid-template-areas:
            "sub sub"
            "info art";
          grid-template-rows: 22% 78%;
          grid-template-columns: 45% 55%;
          padding: 5%;
          gap: 2%;
        }
        .sub-row { grid-area: sub; display: flex; align-items: center; justify-content: center; font-size: 10cqw; font-weight: 700; }
        .info { grid-area: info; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6%; }
        .title { font-size: 9cqw; font-weight: 700; }
        .num-line { display: flex; align-items: baseline; justify-content: center; }
        .num { font-size: 16cqw; font-weight: 800; }
        .unit { font-size: 9cqw; font-weight: 600; margin-left: 0.05em; }
        .date { font-size: 8cqw; opacity: 0.85; }
        .art-box { grid-area: art; width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; }
        .art-img { width: 100%; height: 100%; object-fit: contain; }
      `,
      // 2x4: 横向大卡片
      "2x4": `
        .wrap {
          display: grid;
          grid-template-areas: "info art";
          grid-template-columns: 35% 65%;
          padding: 4%;
          gap: 2%;
          align-items: center;
        }
        .info { display: flex; align-items: center; justify-content: center; height: 100%; }
        .content { display: flex; flex-direction: column; align-items: center; gap: 4%; text-align: center; }
        .sub { font-size: 3.5cqw; opacity: 0.85; }
        .title { font-size: 9cqw; font-weight: 700; }
        .num-line { display: flex; align-items: baseline; }
        .num { font-size: 16cqw; font-weight: 800; }
        .unit { font-size: 10cqw; font-weight: 600; margin-left: 0.05em; }
        .date { font-size: 3.5cqw; opacity: 0.8; }
        .art-box { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; }
        .art-img { width: 100%; height: 100%; object-fit: contain; }
      `
    };
    return m`
      <style>
        ${this.baseStyle}
        ${h[t] || h["2x2"]}
      </style>
      <div class="${a}">
        ${t === "1x1" ? m`
              <h2 class="title">${i}</h2>
              <div class="num-line"><span class="num">${n}</span><span class="unit">天</span></div>
            ` : t === "1x2" ? m`
              <h2 class="title">${i}</h2>
              <div class="num-line"><span class="num">${n}</span><span class="unit">天</span></div>
              <div class="art-box"><img class="art-img" src="${G(i)}" alt="${i}" /></div>
            ` : t === "2x1" ? m`
              <h2 class="title">${i}</h2>
              <div class="num-line"><span class="num">${n}</span><span class="unit">天</span></div>
              <div class="art-box"><img class="art-img" src="${G(i)}" alt="${i}" /></div>
            ` : t === "2x2" ? m`
              <div class="sub-row">${r}</div>
              <div class="info">
                <h2 class="title">${i}</h2>
                <div class="num-line"><span class="num">${n}</span><span class="unit">天</span></div>
                <div class="date">${gt(e.dateObj)}</div>
              </div>
              <div class="art-box"><img class="art-img" src="${G(i)}" alt="${i}" /></div>
            ` : m`
              <div class="info">
                <div class="content">
                  <p class="sub">${r}</p>
                  <h2 class="title">${i}</h2>
                  <div class="num-line"><span class="num">${n}</span><span class="unit">天</span></div>
                  <div class="date">${gt(e.dateObj)}</div>
                </div>
              </div>
              <div class="art-box"><img class="art-img" src="${G(i)}" alt="${i}" /></div>
            `}
      </div>
    `;
  }
  render() {
    var e;
    if (this.loading) return this.renderState("加载中...");
    if (this.error && !this.snapshot) return this.renderState(this.error);
    const t = ((e = this.spCtx.widgetInfo) == null ? void 0 : e.gridSize) || "2x2";
    return this.renderBySize(t);
  }
}
ot(ye, "properties", {
  snapshot: { type: Object },
  loading: { type: Boolean },
  error: { type: String },
  config: { type: Object }
});
class _e extends $e {
  constructor() {
    super(), this.widgetInfo = {}, this.textMode = "light", this.saving = !1;
  }
  async onInitialized({ widgetInfo: t }) {
    this.widgetInfo = t || {};
    const e = (t == null ? void 0 : t.config) || {};
    this.textMode = e.textMode || "light", this.requestUpdate();
  }
  async handleSaveOrCreateWidget() {
    this.saving = !0;
    try {
      await this.spCtx.api.widget.save({
        ...this.widgetInfo,
        config: {
          textMode: this.textMode
        }
      });
    } finally {
      this.saving = !1;
    }
  }
  getButtonTitle() {
    var t;
    return ((t = this.widgetInfo) == null ? void 0 : t.id) !== 0 ? "保存" : "创建";
  }
  render() {
    var i;
    const t = ((i = this.spCtx) == null ? void 0 : i.darkMode) ?? !1, e = {
      bg: t ? "#1a1a1a" : "#ffffff",
      cardBg: t ? "#242424" : "#f8f9fa",
      border: t ? "#333" : "#e5e7eb",
      text: t ? "#e5e5e5" : "#1f2937",
      textSecondary: t ? "#a0a0a0" : "#6b7280",
      accent: "#3b82f6"
    };
    return m`
      <style>
        :host { display:block; height:100%; width:100%; }
        * { box-sizing:border-box; }
        .container {
          height:100%;
          padding: 20px;
          display:flex;
          flex-direction:column;
          background:${e.bg};
          color:${e.text};
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        .header { margin-bottom: 16px; }
        .title { margin: 0 0 4px; font-size: 18px; font-weight: 600; }
        .sub { margin: 0; font-size: 13px; color: ${e.textSecondary}; }

        .section {
          background:${e.cardBg};
          border:1px solid ${e.border};
          border-radius: 10px;
          padding: 14px;
          margin-bottom: 14px;
        }

        .label { font-size: 14px; }
        .hint { font-size: 12px; color: ${e.textSecondary}; margin-top: 2px; }

        .footer { margin-top:auto; }
        .radio-group { display:flex; gap: 10px; margin-top: 4px; }
        .radio-item {
          flex:1;
          display:flex;
          align-items:center;
          justify-content:center;
          padding: 10px 8px;
          border-radius: 8px;
          border: 1px solid ${e.border};
          cursor: pointer;
          font-size: 13px;
          background: ${t ? "#1a1a1a" : "#fff"};
        }
        .radio-item.active {
          border-color: ${e.accent};
          color: ${e.accent};
          background: ${t ? "rgba(59,130,246,.12)" : "rgba(59,130,246,.08)"};
        }
        .btn {
          width:100%;
          padding: 12px;
          border: 0;
          border-radius: 8px;
          color: #fff;
          font-size: 14px;
          font-weight: 500;
          background: ${e.accent};
        }
        .btn:disabled { opacity: .6; }
      </style>

      <div class="container">
        <div class="header">
          <h1 class="title">节假日倒计时</h1>
          <p class="sub">仅展示下一个节日，布局会按尺寸自动优化。</p>
        </div>

        <div class="section">
          <div>
            <div class="label">文字颜色</div>
            <div class="hint">深色背景选浅色文字，浅色背景选深色文字</div>
            <div class="radio-group">
              <div class="radio-item ${this.textMode === "light" ? "active" : ""}" @click="${() => this.textMode = "light"}">浅色</div>
              <div class="radio-item ${this.textMode === "dark" ? "active" : ""}" @click="${() => this.textMode = "dark"}">深色</div>
            </div>
          </div>
          <div class="hint" style="margin-top:10px;">1x1 会自动仅显示节日名与天数；1x2、2x1 会显示节日名、天数和插画。</div>
        </div>

        <div class="footer">
          <button class="btn" ?disabled="${this.saving}" @click="${this.handleSaveOrCreateWidget}">
            ${this.saving ? "保存中..." : this.getButtonTitle()}
          </button>
        </div>
      </div>
    `;
  }
}
ot(_e, "properties", {
  widgetInfo: { type: Object },
  textMode: { type: String },
  saving: { type: Boolean }
});
const Jt = {
  author: "Madrays",
  microAppId: "madrays-holiday-countdown",
  version: "1.0.0",
  entry: "main.js",
  icon: "logo.png",
  appInfo: {
    "zh-CN": {
      appName: "节假日倒计时",
      description: "自动计算当前日期到中国节假日的倒计时，并按节日主题展示漫画 SVG",
      networkDescription: "用于调用 holiday.ailcc.com 获取节假日与调休数据"
    },
    "en-US": {
      appName: "Holiday Countdown",
      description: "Auto countdown to Chinese holidays with themed SVG illustrations",
      networkDescription: "Used to request holiday and adjusted workday data from holiday.ailcc.com"
    }
  },
  permissions: ["network"],
  networkDomains: ["holiday.ailcc.com"],
  dataNodes: {}
}, fi = {
  pages: {
    "holiday-countdown-config": {
      component: _e,
      background: "rgba(255, 255, 255, 0.9)",
      headerTextColor: "#0f172a"
    }
  },
  widgets: {
    "holiday-countdown-widget": {
      component: ye,
      configComponentName: "holiday-countdown-config",
      size: ["1x1", "1x2", "2x1", "2x2", "2x4"],
      background: "transparent",
      isModifyBackground: !0
    }
  }
}, gi = !1, $i = (s) => s.microAppId, Si = {
  appConfig: {
    ...Jt,
    microAppId: $i(Jt),
    dev: gi
  },
  components: fi
};
export {
  Si as default
};
